module.exports = {
  name: 'Camunda Russian Spell Checker',
  script: './spellchecker.js',
  style: './style.css',
  menu: './menu.js'
};
