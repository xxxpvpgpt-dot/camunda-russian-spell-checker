'use strict';

const fs = require('fs');
const path = require('path');
const { shell } = require('electron');

const PROTOCOL = 'camunda-rsc://terminology/';
const README_PROTOCOL = 'camunda-rsc://readme';

function safeSlug(name) {
  const translit = String(name || '').trim().toLocaleLowerCase('ru-RU')
    .replace(/ё/g, 'е')
    .replace(/[^a-zа-я0-9]+/giu, '-')
    .replace(/^-+|-+$/gu, '');
  return translit || `terminology-${Date.now()}`;
}

function readJson(filePath, fallback) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch (_) { return fallback; }
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + '\n', 'utf8');
}

function readIndex(indexPath) {
  const data = readJson(indexPath, { version: 1, terminologies: [] });
  if (Array.isArray(data.terminologies)) return data;
  return { version: 1, terminologies: [] };
}

function normalizeTerms(terms) {
  return Array.from(new Set((Array.isArray(terms) ? terms : [])
    .map(x => String(x || '').trim())
    .filter(Boolean)));
}

function sendResult(win, result) {
  const js = `window.dispatchEvent(new CustomEvent('crsc-terminology-result', { detail: ${JSON.stringify(result)} }));`;
  win.webContents.executeJavaScript(js).catch(() => {});
}

function registerTerminologyHandler(electronApp) {
  const win = electronApp.mainWindow;
  if (!win || win.isDestroyed() || win.__crscTerminologyHandlerRegistered) return;
  win.__crscTerminologyHandlerRegistered = true;

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url === README_PROTOCOL || url.startsWith(README_PROTOCOL + '/')) {
      const readmePath = path.join(__dirname, 'README.md');
      shell.openPath(readmePath).catch(() => {});
      return { action: 'deny' };
    }
    if (!url.startsWith(PROTOCOL)) return { action: 'allow' };

    let result;
    try {
      const payload = JSON.parse(decodeURIComponent(url.slice(PROTOCOL.length)));
      const op = String(payload.op || 'add');
      const dictionaryDir = path.join(__dirname, 'dictionary');
      const indexPath = path.join(dictionaryDir, 'index.json');
      const index = readIndex(indexPath);

      if (op === 'add' || op === 'update') {
        const name = String(payload.name || '').trim();
        const category = String(payload.category || 'Прочее').trim();
        const terms = normalizeTerms(payload.terms);
        const id = safeSlug(payload.id || name);

        if (!name) throw new Error('Не указано наименование терминологии.');
        if (!terms.length) throw new Error('Не указаны термины.');
        if (!['Справочник', 'Документы', 'Прочее'].includes(category)) throw new Error('Недопустимая категория.');
        if (!id || id === '.' || id === '..' || id.includes(path.sep)) throw new Error('Недопустимое имя терминологии.');

        const folderPath = path.join(dictionaryDir, id);
        const existing = index.terminologies.find(x => x && x.id === id);

        if (op === 'add') {
          if (existing || fs.existsSync(folderPath)) throw new Error(`Терминология «${name}» уже существует.`);
          fs.mkdirSync(folderPath, { recursive: true });
          writeJson(path.join(folderPath, 'terminology.json'), { version: 1, id, name, category, terms });
          index.terminologies = index.terminologies.filter(x => x && x.id !== id);
          index.terminologies.push({ id, name, folder: id, category, builtIn: false, files: ['terminology.json'] });
          index.terminologies.sort((a, b) => String(a.name).localeCompare(String(b.name), 'ru'));
          writeJson(indexPath, index);
          result = { ok: true, op, id, name, category, termsCount: terms.length };
        } else {
          if (!existing || existing.id === 'erp26') throw new Error('Эту системную терминологию нельзя изменить.');
          fs.mkdirSync(folderPath, { recursive: true });
          writeJson(path.join(folderPath, 'terminology.json'), { version: 1, id, name, category, terms });
          existing.name = name;
          existing.category = category;
          existing.folder = id;
          existing.builtIn = false;
          existing.files = ['terminology.json'];
          index.terminologies.sort((a, b) => String(a.name).localeCompare(String(b.name), 'ru'));
          writeJson(indexPath, index);
          result = { ok: true, op, id, name, category, termsCount: terms.length };
        }
      } else if (op === 'delete') {
        const id = String(payload.id || '').trim();
        if (!id || id === 'erp26') throw new Error('Эту системную терминологию удалить нельзя.');
        const existing = index.terminologies.find(x => x && x.id === id);
        if (!existing) throw new Error('Терминология не найдена.');
        if (existing.builtIn) throw new Error('Системную терминологию удалить нельзя.');

        const folderPath = path.join(dictionaryDir, existing.folder || id);
        if (fs.existsSync(folderPath)) fs.rmSync(folderPath, { recursive: true, force: true });
        index.terminologies = index.terminologies.filter(x => x && x.id !== id);
        writeJson(indexPath, index);
        result = { ok: true, op, id, name: existing.name };
      } else if (op === 'update-user-custom') {
        const terms = normalizeTerms(payload.terms);
        if (!terms.length) throw new Error('Добавьте хотя бы один пользовательский термин.');
        const filePath = path.join(dictionaryDir, 'User-custom-terms.json');
        const existing = readJson(filePath, { version: 1 });
        existing.version = existing.version || 1;
        existing.description = existing.description || 'Пользовательские термины, которые не следует считать ошибками.';
        existing.terms = terms;
        writeJson(filePath, existing);
        result = { ok: true, op, termsCount: terms.length };
      } else {
        throw new Error('Неизвестная операция терминологии.');
      }
    } catch (error) {
      result = { ok: false, message: error && error.message ? error.message : 'Операция с терминологией не выполнена.' };
    }

    sendResult(win, result);
    return { action: 'deny' };
  });
}

module.exports = function(electronApp, menuState) {
  registerTerminologyHandler(electronApp);

  function send(action) {
    const win = electronApp.mainWindow;
    if (!win || win.isDestroyed()) return;
    win.webContents.executeJavaScript(
      "window.postMessage({ source: 'camunda-russian-spell-checker', action: '" + action + "' }, '*')"
    ).catch(function() {});
  }

  return [
    { label: 'Russian Spell Checker — включить/выключить', accelerator: 'CommandOrControl+Shift+L', action: function() { send('toggle'); } },
    { label: 'Russian Spell Checker — проверить текущее поле', action: function() { send('check-selected'); } },
    { label: 'Russian Spell Checker — проверить все видимые поля', action: function() { send('check-all'); } },
    { label: 'Russian Spell Checker — авто-нумерация шагов', accelerator: 'CommandOrControl+Alt+N', action: function() { send('number-steps'); } },
    { label: 'Russian Spell Checker — выровнять размер задач', action: function() { send('align-task-sizes'); } },
    { label: 'Russian Spell Checker — настройки', action: function() { send('settings'); } },
    { label: 'Russian Spell Checker — справка', action: function() { send('help'); } }
  ];
};
