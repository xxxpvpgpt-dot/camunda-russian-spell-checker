(function() {
  'use strict';

  const SOURCE = 'camunda-russian-spell-checker';
  const STORAGE = 'camunda-russian-spell-checker.settings';
  const DEFAULTS = {
    enabled: true,
    language: 'ru-RU',
    useLanguageTool: false,
    languageToolSource: 'external',
    localEndpoint: 'http://127.0.0.1:8081/v2/check',
    externalEndpoint: 'https://api.languagetool.org/v2/check',
    endpoint: 'https://api.languagetool.org/v2/check',
    delay: 700,
    autoQuotes: true,
    autoSpaces: true,
    ignoreTechnical: true,
    useErp26Terminology: true,
    checkErp26Documents: true,
    checkErp26Catalogs: true,
    oneNumberForIdenticalActions: false,
    alignTaskMinGap: 40,
    enabledTerminologies: { erp26: true },
    dictionary: [
      // 1С / ERP / УХ / НСИ / МДМ
      '1С','1С:ERP','1С:УХ','1С:ERP УХ','1С:ЗУП','1С:ДО','1С:УПП','1С:Бухгалтерия',
      'ERP','ERP 2.5','ERP 2','УХ','ЗУП','ДО','БП','УПП','ИТ','ИТ-директор','ИТ-служба',
      'НСИ','МДМ','MDM','ЕПС','Единая система','нормализация','классификатор','классификаторы',
      'НСИиП','НСИ и НП','мастер-данные','мастер данные','master data','справочник','справочники',
      'элемент НСИ','объект НСИ','нормативно-справочная информация','эталонная запись','дубликаты',

      // Бизнес-термины 1С
      'контрагент','контрагенты','партнёр','партнер','партнёры','партнеры','организация','организации',
      'обособленное подразделение','ЮЛ','физлицо','ФЛ','ИП','КПП','ИНН','ОГРН','ОКПО','ОКВЭД',
      'номенклатура','номенклатурная позиция','характеристика','характеристики','серия','серии',
      'вид номенклатуры','группа номенклатуры','комплект','комплектация','разукомплектация',
      'спецификация','спецификации','рецептура','техпроцесс','технологическая операция','технология',
      'склад','склады','кладовщик','ячейка','адресное хранение','зона хранения','топология склада',
      'ордер','ордера','приходный ордер','расходный ордер','ордер на отражение','перемещение',
      'перемещения','приемка','отгрузка','отбор','размещение','пересортица','инвентаризация',
      'недостача','излишек','излишки','брак','порча','серийный номер','штрихкод','штрихкоды',
      'упаковка','упаковки','палета','паллеты','тара','транспортная упаковка','место','места',
      'заказ клиента','заказы клиентов','заказ поставщику','заказы поставщикам','заказ на перемещение',
      'обеспечение','обеспеченность','потребность','планирование','план закупок','план продаж',
      'закупка','закупки','снабжение','поступление','реализация','отгрузка','возврат','возвраты',
      'соглашение','соглашения','договор','договоры','документ','документы','основание','основания',
      'заказ-наряд','наряд','ремонт','ремонты','объект ремонта','ресурс','ресурсы','ремонтный фонд',
      'рабочий центр','рабочие центры','производство','производственный заказ','этап производства',
      'передел','переделы','операция','операции','материалы','комплектующие','полуфабрикат','продукция',
      'выпуск','выпуск продукции','незавершённое производство','НЗП','себестоимость','расчёт себестоимости',
      'распределение','распределения','резервирование','резервы','обособление','обособленный запас',
      'обеспечение заказов','схема обеспечения','способ обеспечения','потребность в материалах',
      'доставка','маршрут','маршрутизация','маршрутный лист','рейс','транспорт','перевозчик',
      'экспедитор','складская операция','оперативный учёт','управленческий учёт','регламентированный учёт',
      'проведение','перепроведение','отмена проведения','пометка удаления','ссылка','объект',

      // Финансы / НФО / холдинг
      'казначейство','банк','банковский счёт','банковские счета','платёж','платежи','платёжное поручение',
      'платежный календарь','платёжный календарь','заявка на расходование','заявки на расходование',
      'лимит','лимиты','бюджет','бюджетирование','бюджетный сценарий','ЦФО','ЦФУ','ЦФИ','финансовый результат',
      'управленческий баланс','ДДС','БДДС','БДР','дебиторская задолженность','кредиторская задолженность',
      'взаиморасчёты','взаиморасчеты','авансы','задолженность','закрытие месяца','регламентная операция',
      'МСФО','РСБУ','НФО','УХ','холдинг','дочернее общество','внутригрупповой','консолидация',

      // Интеграции / архитектура / данные
      'интеграция','интеграции','информационная система','система-источник','система-приёмник',
      'система-получатель','обмен','обмен данными','выгрузка','загрузка','миграция','миграция данных',
      'конвертация','конвертация данных','сопоставление','маппинг','mapping','ETL','API','REST','SOAP',
      'HTTP','JSON','XML','CSV','SFTP','FTP','Kafka','очередь','очереди','шина данных','ESB','endpoint',
      'webhook','сервис','сервисы','микросервис','микросервисы','контур','контуры','интерфейс','интерфейсы',
      'регламентное задание','фоновое задание','план обмена','план обменов','узел обмена','сообщение',
      'сообщения','очередь сообщений','транзакция','транзакции','идемпотентность','повторная загрузка',
      'дельта','полная загрузка','инкрементальная загрузка','пакетная загрузка','пакет','пакеты',
      'сопоставитель','правило сопоставления','правила сопоставления','идентификатор','GUID','UID',
      'НСИ','MDM','master-data','data governance','Data Governance','Data Quality','качество данных',

      // Camunda / BPMN
      'Camunda','Camunda Modeler','BPMN','BPMN 2.0','DMN','CMMN','процесс','процессы','бизнес-процесс',
      'бизнес-процессы','бизнес процесс','бизнес процессы','подпроцесс','подпроцессы','задача','задачи',
      'пользовательская задача','сервисная задача','скриптовая задача','ручная задача','получение сообщения',
      'отправка сообщения','событие','события','таймер','таймерное событие','шлюз','шлюзы',
      'эксклюзивный шлюз','параллельный шлюз','условие','условия','ветка','ветвление','согласование',
      'согласования','утверждение','маршрут согласования','роль','роли','исполнитель','исполнители',
      'инициатор','наблюдатель','делегирование','эскалация','компенсация','корреляция','correlation',
      'message event','message task','user task','service task','script task','exclusive gateway','parallel gateway',
      'boundary event','start event','end event','intermediate event','subprocess','call activity',
      'business rule task','receive task','send task','manual task','event subprocess',

      // SAP / Teamcenter / смежные системы
      'SAP','SAP PP','SAP MM','SAP FI','SAP CO','SAP HCM','SAP S/4HANA','S/4HANA','Teamcenter','TeamCentre',
      'Team Center','PLM','PDM','MES','WMS','TMS','CRM','DWH','BI','Qlik','Power BI','SQL','SQL Server',
      'Oracle','PostgreSQL','Linux','Windows','Active Directory','LDAP','VPN','SSL','TLS','OAuth','JWT',

      // Технические и проектные термины
      'релиз','релизы','версия','версии','релизная версия','обновление','обновления','патч','патчи',
      'тестовый контур','продуктивный контур','промышленный контур','опытно-промышленная эксплуатация',
      'предварительные испытания','промышленные испытания','пилот','пилотирование','приёмка','приемка',
      'тестирование','тест-кейс','тест-кейсы','регресс','регрессионное тестирование','ошибка','ошибки',
      'инцидент','инциденты','дефект','дефекты','доработка','доработки','расширение','расширения',
      'обработка','обработки','форма','формы','отчёт','отчеты','отчёты','отчётность','отчетность',
      'регистр сведений','регистры сведений','регистр накопления','регистры накопления','регистр бухгалтерии',
      'регистр расчёта','регистр расчета','константа','константы','перечисление','перечисления',
      'план видов характеристик','план счетов','план обмена','план счетов','субконто','проводка','проводки',
      'оперативная память','CPU','RAM','SSD','HDD','кластер','кластеры','сервер','серверы','сервер приложений',
      'рабочая база','копия базы','резервная копия','архив','архивация','лог','логи','журнал регистрации',
      'мониторинг','метрика','метрики','нагрузочное тестирование','производительность','масштабирование',
      'отказоустойчивость','резервирование','высокая доступность','HA','SLA','SLO','RPO','RTO',

      // Часто используемые бизнес-формулировки
      'связанный документ','связанные документы','исходный документ','целевой документ','родительский документ',
      'дочерний документ','табличная часть','табличные части','шапка документа','строка документа','строки документа',
      'вид операции','вид операции документа','организация-отправитель','организация-получатель',
      'склад-отправитель','склад-получатель','место хранения','места хранения','ответственное лицо',
      'материально ответственное лицо','МОЛ','параметр','параметры','реквизит','реквизиты','значение',
      'значения','показатель','показатели','аналитика','аналитики','отбор','отборы','сортировка',
      'фильтр','фильтры','расшифровка','расшифровки','подбор','подборы','подстановка','подстановки',
      'автозаполнение','автозаполнения','автонумерация','нумерация','печатная форма','печатные формы',
      'макет','макеты','шаблон','шаблоны','печатный документ','печатные документы','электронный документ',
      'электронная подпись','ЭП','КЭП','сертификат','сертификаты','подпись','подписи'
    ]
  };

  // Capture the plugin script URL while document.currentScript is available.
  // Later, asynchronous functions cannot reliably use document.currentScript.
  const PLUGIN_BASE_URL = (() => {
    try {
      const src = document.currentScript && document.currentScript.src;
      if (src) return new URL('./', src).href;
    } catch (_) {}
    return null;
  })();

  let settings = loadSettings();
  let correctionRules = [];
  let correctionsLoaded = false;
  let erp26Documents = [];
  let erp26Catalogs = [];
  let erp26Index = new Map();
  let erp26Loaded = false;
  let userCustomTerms = [];
  let userCustomLoaded = false;
  let terminologyIndex = [];
  let terminologyIndexLoaded = false;
  let terminologyTerms = new Map();

  async function loadCorrections() {
    if (correctionsLoaded) return correctionRules;

    const candidates = [];
    try {
      const pluginDir = typeof getPluginsDirectory === 'function' ? getPluginsDirectory() : getPluginsDirectory;
      if (pluginDir) candidates.push(String(pluginDir).replace(/\/$/, '') + '/camunda-russian-spell-checker/corrections.json');
    } catch (_) {}
    candidates.push('./corrections.json');

    for (const url of candidates) {
      try {
        const response = await fetch(url);
        if (!response.ok) continue;
        const json = await response.json();
        correctionRules = compileCorrectionRules(json && Array.isArray(json.rules) ? json.rules : []);
        correctionsLoaded = true;
        return correctionRules;
      } catch (_) {}
    }

    // Минимальный резервный набор, если corrections.json временно недоступен.
    correctionRules = compileCorrectionRules([
      { id: '1c-ut-basic', category: '1С', variants: ['1CУТ', '1СУТ', '1C УТ', '1С УТ'], replacement: '1С:УТ', message: 'Рекомендуемое написание продукта 1С:Управление торговлей' },
      { id: '1c-erp-basic', category: '1С', variants: ['1C ERP', '1С ERP', '1C:ERP'], replacement: '1С:ERP', message: 'Рекомендуемое написание продукта 1С:ERP' },
      { id: '1c-ukh-basic', category: '1С', variants: ['1C УХ', '1С УХ', '1C:УХ'], replacement: '1С:УХ', message: 'Рекомендуемое написание продукта 1С:Управление холдингом' }
    ]);
    correctionsLoaded = true;
    return correctionRules;
  }

  async function loadTerminologyIndex() {
    if (terminologyIndexLoaded) return terminologyIndex;
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');

    for (const base of Array.from(new Set(bases))) {
      try {
        const response = await fetch(base + 'index.json', { cache: 'no-store' });
        if (!response.ok) continue;
        const json = await response.json();
        if (Array.isArray(json?.terminologies)) {
          terminologyIndex = json.terminologies.filter(x => x && x.id && x.name && x.folder);
          break;
        }
      } catch (_) {}
    }

    // Compatibility fallback for versions where the index is unavailable.
    if (!terminologyIndex.some(x => x.id === 'erp26')) {
      terminologyIndex.unshift({
        id: 'erp26', name: '1С:ERP 2.6', folder: 'erp26', builtIn: true,
        category: 'системная', files: ['erp26-documents.json', 'erp26-catalogs.json']
      });
    }

    terminologyIndexLoaded = true;
    return terminologyIndex;
  }

  function terminologyEnabled(id) {
    if (id === 'erp26') return settings.enabledTerminologies?.erp26 !== false;
    return settings.enabledTerminologies?.[id] !== false;
  }

  async function loadErp26Dictionary() {
    if (erp26Loaded) return;

    // Important: spellchecker.js is loaded by Camunda as a plugin resource.
    // Relative fetch('./dictionary/...') resolves against the Modeler page,
    // not necessarily against the plugin folder. Use the captured script URL
    // first, then a few compatibility fallbacks.
    const baseCandidates = [];
    if (PLUGIN_BASE_URL) baseCandidates.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);

    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) baseCandidates.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}

    baseCandidates.push('./dictionary/');
    baseCandidates.push('../dictionary/');

    async function loadFile(fileName) {
      const tried = new Set();
      for (const base of baseCandidates) {
        if (!base || tried.has(base)) continue;
        tried.add(base);
        try {
          const response = await fetch(base + fileName, { cache: 'no-store' });
          if (!response.ok) continue;
          const json = await response.json();
          if (Array.isArray(json?.objects)) return json.objects;
        } catch (_) {}
      }
      return [];
    }

    const erp26BaseCandidates = baseCandidates.map(base => base.endsWith('/') ? base + 'erp26/' : base + '/erp26/');
    async function loadFileFromBases(bases, fileName) {
      const tried = new Set();
      for (const base of bases) {
        if (!base || tried.has(base)) continue;
        tried.add(base);
        try {
          const response = await fetch(base + fileName, { cache: 'no-store' });
          if (!response.ok) continue;
          const json = await response.json();
          if (Array.isArray(json?.objects)) return json.objects;
        } catch (_) {}
      }
      return [];
    }
    erp26Documents = await loadFileFromBases(erp26BaseCandidates, 'erp26-documents.json');
    erp26Catalogs = await loadFileFromBases(erp26BaseCandidates, 'erp26-catalogs.json');
    await loadTerminologyIndex();
    await loadAdditionalTerminologies();
    buildErp26Index();
    erp26Loaded = true;

    // Expose a tiny diagnostic for the settings dialog / troubleshooting.
    window.__crscErp26Stats = {
      documents: erp26Documents.length,
      catalogs: erp26Catalogs.length,
      total: erp26Documents.length + erp26Catalogs.length,
      loaded: erp26Documents.length > 0 || erp26Catalogs.length > 0
    };
  }

  async function loadAdditionalTerminologies() {
    terminologyTerms = new Map();
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');

    const unique = Array.from(new Map(terminologyIndex.map(x => [x.id, x])).values());
    for (const entry of unique) {
      if (entry.id === 'erp26' || !terminologyEnabled(entry.id)) continue;
      for (const base of Array.from(new Set(bases))) {
        try {
          const response = await fetch(base + `${entry.folder}/terminology.json`, { cache: 'no-store' });
          if (!response.ok) continue;
          const json = await response.json();
          const terms = Array.isArray(json?.terms) ? json.terms.filter(Boolean).map(String) : [];
          terminologyTerms.set(entry.id, {
            ...entry,
            category: json.category || entry.category || 'прочее',
            terms
          });
          break;
        } catch (_) {}
      }
    }
  }

  async function loadUserCustomTerms() {
    if (userCustomLoaded) return userCustomTerms;
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');
    for (const base of bases) {
      try {
        const response = await fetch(base + 'User-custom-terms.json', { cache: 'no-store' });
        if (!response.ok) continue;
        const json = await response.json();
        if (Array.isArray(json?.terms)) { userCustomTerms = json.terms.filter(Boolean).map(String); break; }
      } catch (_) {}
    }
    userCustomLoaded = true;
    return userCustomTerms;
  }

  function erpObjects() {
    if (!terminologyEnabled('erp26')) return [];
    const result = [];
    if (settings.checkErp26Documents) result.push(...erp26Documents.map(x => ({ ...x, objectType: 'Документ' })));
    if (settings.checkErp26Catalogs) result.push(...erp26Catalogs.map(x => ({ ...x, objectType: 'Справочник' })));
    return result;
  }

  function erpTokens(value) {
    return String(value || '')
      .toLocaleLowerCase('ru-RU')
      .replace(/[«»"“”„’'()\[\]{}:;,!?]/gu, ' ')
      .split(/\s+/u)
      .filter(Boolean);
  }

  function editDistance(a, b) {
    const x = String(a), y = String(b);
    if (x === y) return 0;
    if (!x.length) return y.length;
    if (!y.length) return x.length;
    const prev = Array.from({ length: y.length + 1 }, (_, i) => i);
    for (let i = 1; i <= x.length; i++) {
      const cur = [i];
      for (let j = 1; j <= y.length; j++) {
        cur[j] = Math.min(
          cur[j - 1] + 1,
          prev[j] + 1,
          prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1)
        );
      }
      for (let j = 0; j <= y.length; j++) prev[j] = cur[j];
    }
    return prev[y.length];
  }

  function buildErp26Index() {
    erp26Index = new Map();
    for (const obj of [...erp26Documents.map(x => ({ ...x, objectType: 'Документ' })), ...erp26Catalogs.map(x => ({ ...x, objectType: 'Справочник' }))]) {
      const tokens = erpTokens(obj.name);
      if (tokens.length < 2) continue;
      const key = tokens[0];
      if (!erp26Index.has(key)) erp26Index.set(key, []);
      erp26Index.get(key).push({ ...obj, tokens });
    }
  }

  function normalizeErpDocumentTitle(value) {
    return String(value || '')
      .replace(/[\u00A0\t\r\n]+/gu, ' ')
      .replace(/ +/gu, ' ')
      .trim()
      .toLocaleLowerCase('ru-RU');
  }

  // Return all balanced «...» spans. Nested guillemets are supported,
  // e.g. «Заказ на перемещение ... «Солнцерево»».
  function guillemetSpans(text) {
    const source = String(text || '');
    const stack = [];
    const spans = [];
    for (let i = 0; i < source.length; i++) {
      if (source[i] === '«') {
        stack.push(i);
      } else if (source[i] === '»' && stack.length) {
        const start = stack.pop();
        if (i > start + 1) {
          spans.push({ start, end: i + 1, contentStart: start + 1, contentEnd: i });
        }
      }
    }
    return spans.sort((a, b) => a.start - b.start || b.end - a.end);
  }

  function erp26DocumentCandidates(content) {
    const tokens = erpTokens(content);
    if (!tokens.length) return [];
    const first = tokens[0];
    return (erp26Index.get(first) || [])
      .filter(candidate => candidate.objectType === 'Документ')
      .filter(candidate => settings.checkErp26Documents)
      .sort((a, b) => b.tokens.length - a.tokens.length);
  }

  function exactErp26DocumentInQuote(content) {
    const normalized = normalizeErpDocumentTitle(content);
    if (!normalized) return null;

    const candidates = erp26DocumentCandidates(content);
    if (!candidates.length) return null;

    // 1) Полное совпадение всего текста внутри «ёлочек».
    const exact = candidates.find(candidate => normalizeErpDocumentTitle(candidate.name) === normalized);
    if (exact) return { candidate: exact, mode: 'exact' };

    // 2) Точное название документа в начале кавычек.
    // Разрешаем продолжение после названия: например,
    // «Заказ на перемещение со склада филиала ...».
    // В этом случае не пытаемся сопоставлять кусок «перемещение со»
    // с другим документом вроде «Перемещение ОС».
    const prefix = candidates.find(candidate => {
      const title = normalizeErpDocumentTitle(candidate.name);
      return title && normalized.startsWith(title + ' ');
    });
    if (prefix) return { candidate: prefix, mode: 'prefix' };

    return null;
  }

  function fuzzyQuotedDocumentMatches(content, absoluteOffset) {
    const actualTokens = erpTokens(content);
    if (actualTokens.length < 2) return [];

    const candidates = erp26DocumentCandidates(content);
    const matches = [];
    let best = null;

    for (const candidate of candidates) {
      // We intentionally compare the whole quoted phrase with the whole
      // document title. No arbitrary middle windows are used here.
      if (candidate.tokens.length !== actualTokens.length) continue;

      const tokenDistances = actualTokens.map((value, idx) => editDistance(value, candidate.tokens[idx]));
      const total = tokenDistances.reduce((sum, d) => sum + d, 0);
      const changed = tokenDistances.filter(d => d !== 0).length;
      const exactTokens = actualTokens.length - changed;

      // Keep fuzzy matching useful (including two simultaneous typos), but
      // require a meaningful amount of the document to match. Two-token names
      // need one exact token plus a one-edit difference; for longer names at
      // least half of the tokens must match exactly and total token distance
      // may be up to two. This avoids the old false positive where
      // «перемещение со» was suggested as «Перемещение ОС».
      let acceptable = false;
      if (candidate.tokens.length === 2) {
        acceptable = changed === 1 && total === 1;
      } else {
        acceptable = changed >= 1 && changed <= 2 && total <= 2 &&
          exactTokens >= Math.ceil(candidate.tokens.length / 2);
      }
      if (!acceptable) continue;

      const score = (exactTokens * 100) - (total * 10) - Math.abs(candidate.tokens.length - actualTokens.length);
      if (!best || score > best.score) {
        best = { candidate, score };
      }
    }

    if (!best) return [];

    const candidate = best.candidate;
    return [{
      offset: absoluteOffset,
      length: String(content || '').length,
      message: `Похоже на документ 1С: «${candidate.name}». Рекомендуется точное название объекта.`,
      replacements: [{ value: candidate.name }],
      rule: { issueType: 'misspelling', category: { id: 'ERP26_DOCUMENT' } },
      _localCorrection: true,
      _erp26: true,
      _erpObjectType: 'Документ',
      _erpInternalName: candidate.internalName,
      _category: '1С:ERP 2.6'
    }];
  }

  function erp26DocumentMatchesInQuotes(text) {
    if (!settings.useErp26Terminology || !settings.checkErp26Documents) return [];
    const source = String(text || '');
    const spans = guillemetSpans(source);
    const matches = [];
    const seen = new Set();

    for (const span of spans) {
      const content = source.slice(span.contentStart, span.contentEnd);
      const recognized = exactErp26DocumentInQuote(content);
      if (recognized) continue;

      const fuzzy = fuzzyQuotedDocumentMatches(content, span.contentStart);
      for (const match of fuzzy) {
        const signature = `${match.offset}:${match.length}:${match._erpInternalName}`;
        if (seen.has(signature)) continue;
        seen.add(signature);
        matches.push(match);
      }
    }

    return matches.sort((a, b) => a.offset - b.offset);
  }

  function erp26CatalogMatches(text) {
    if (!settings.useErp26Terminology || !settings.checkErp26Catalogs) return [];
    const source = String(text || '');
    const words = [];
    const re = /[\p{L}\p{N}][\p{L}\p{N}_-]*/gu;
    let m;
    while ((m = re.exec(source))) words.push({ value: m[0], index: m.index });
    const matches = [];
    const seen = new Set();

    // Catalogs keep the previous token-window behavior. Document matching is
    // deliberately handled separately and only for the complete quoted phrase.
    for (let i = 0; i < words.length; i++) {
      const key = words[i].value.toLocaleLowerCase('ru-RU');
      const candidates = (erp26Index.get(key) || []).filter(candidate => candidate.objectType === 'Справочник');
      if (!candidates.length) continue;
      for (const candidate of candidates) {
        const n = candidate.tokens.length;
        if (i + n > words.length) continue;
        const windowWords = words.slice(i, i + n);
        const actualTokens = windowWords.map(w => w.value.toLocaleLowerCase('ru-RU'));
        if (actualTokens.every((v, idx) => v === candidate.tokens[idx])) continue;
        const tokenDistances = actualTokens.map((v, idx) => editDistance(v, candidate.tokens[idx]));
        const total = tokenDistances.reduce((sum, d) => sum + d, 0);
        const changed = tokenDistances.filter(d => d !== 0).length;
        if (changed !== 1 || total !== 1) continue;

        const start = windowWords[0].index;
        const end = windowWords[windowWords.length - 1].index + windowWords[windowWords.length - 1].value.length;
        const length = end - start;
        const signature = `${start}:${length}:${candidate.internalName}`;
        if (seen.has(signature)) continue;
        seen.add(signature);
        matches.push({
          offset: start,
          length,
          message: `Похоже на справочник 1С: «${candidate.name}». Рекомендуется точное название объекта.`,
          replacements: [{ value: candidate.name }],
          rule: { issueType: 'misspelling', category: { id: 'ERP26_CATALOG' } },
          _localCorrection: true,
          _erp26: true,
          _erpObjectType: candidate.objectType,
          _erpInternalName: candidate.internalName,
          _category: '1С:ERP 2.6'
        });
      }
    }
    return matches.sort((a, b) => a.offset - b.offset);
  }

  function additionalTerminologyMatches(text) {
    const source = String(text || '');
    const results = [];
    const spans = guillemetSpans(source);
    const all = Array.from(terminologyTerms.values()).filter(x => terminologyEnabled(x.id));

    // Documents: validate the complete quoted name and use the same tolerant
    // whole-phrase comparison as ERP 2.6 documents.
    for (const entry of all.filter(x => String(x.category).toLocaleLowerCase('ru-RU') === 'документы')) {
      const docs = entry.terms;
      for (const span of spans) {
        const content = source.slice(span.contentStart, span.contentEnd);
        const normalized = normalizeErpDocumentTitle(content);
        if (!normalized) continue;
        if (docs.some(t => normalizeErpDocumentTitle(t) === normalized)) continue;
        let best = null;
        const actualTokens = erpTokens(content);
        for (const title of docs) {
          const candidateTokens = erpTokens(title);
          if (candidateTokens.length !== actualTokens.length || !candidateTokens.length) continue;
          const ds = actualTokens.map((v, i) => editDistance(v, candidateTokens[i]));
          const total = ds.reduce((a,b) => a+b, 0);
          const changed = ds.filter(d => d !== 0).length;
          const exact = actualTokens.length - changed;
          const acceptable = candidateTokens.length === 2
            ? changed === 1 && total === 1
            : changed >= 1 && changed <= 2 && total <= 2 && exact >= Math.ceil(candidateTokens.length / 2);
          if (!acceptable) continue;
          const score = exact * 100 - total * 10;
          if (!best || score > best.score) best = { title, score };
        }
        if (best) {
          results.push({
            offset: span.contentStart,
            length: content.length,
            message: `Похоже на термин из набора «${entry.name}»: «${best.title}». Рекомендуется точное название.`,
            replacements: [{ value: best.title }],
            rule: { issueType: 'misspelling', category: { id: 'CUSTOM_TERMINOLOGY_DOCUMENT' } },
            _localCorrection: true, _terminology: true,
            _terminologyId: entry.id, _category: entry.name
          });
        }
      }
    }

    return results;
  }

  function erp26Matches(text) {
    if (!terminologyEnabled('erp26')) return [];
    return [
      ...erp26DocumentMatchesInQuotes(text),
      ...erp26CatalogMatches(text)
    ].sort((a, b) => a.offset - b.offset);
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function compileCorrectionRules(rules) {
    return rules
      .filter(rule => rule && rule.replacement && Array.isArray(rule.variants) && rule.variants.length)
      .flatMap(rule => rule.variants.map(variant => {
        const flags = rule.caseSensitive ? 'gu' : 'giu';
        const pattern = new RegExp('(?<![\\p{L}\\p{N}_])' + escapeRegExp(variant) + '(?![\\p{L}\\p{N}_])', flags);
        return {
          id: rule.id || variant,
          category: rule.category || 'Прочее',
          pattern,
          replacement: rule.replacement,
          message: rule.message || 'Рекомендуемое написание',
          priority: Number(rule.priority) || 100
        };
      }))
      .sort((a, b) => a.priority - b.priority);
  }

  // BPMN naming recommendations. These are deliberately conservative: we only
  // suggest a more action-oriented perfective infinitive for a known set of
  // common imperfective verbs. This is a style recommendation, not a grammar error.
  const BPMN_VERB_RECOMMENDATIONS = Object.freeze({
    'открывать': 'Открыть',
    'закрывать': 'Закрыть',
    'создавать': 'Создать',
    'изменять': 'Изменить',
    'редактировать': 'Отредактировать',
    'заполнять': 'Заполнить',
    'проверять': 'Проверить',
    'согласовывать': 'Согласовать',
    'утверждать': 'Утвердить',
    'отправлять': 'Отправить',
    'получать': 'Получить',
    'формировать': 'Сформировать',
    'создавать': 'Создать',
    'загружать': 'Загрузить',
    'выгружать': 'Выгрузить',
    'вводить': 'Ввести',
    'выводить': 'Вывести',
    'добавлять': 'Добавить',
    'удалять': 'Удалить',
    'выбирать': 'Выбрать',
    'назначать': 'Назначить',
    'устанавливать': 'Установить',
    'снимать': 'Снять',
    'создавать': 'Создать',
    'перемещать': 'Переместить',
    'проводить': 'Провести',
    'выполнять': 'Выполнить',
    'запускать': 'Запустить',
    'останавливать': 'Остановить',
    'рассчитывать': 'Рассчитать',
    'рассматривать': 'Рассмотреть',
    'подтверждать': 'Подтвердить',
    'отменять': 'Отменить',
    'назначать': 'Назначить',
    'регистрировать': 'Зарегистрировать',
    'созванивать': 'Созвонить',
    'обрабатывать': 'Обработать',
    'передавать': 'Передать',
    'принимать': 'Принять',
    'возвращать': 'Вернуть',
    'сохранять': 'Сохранить',
    'печатать': 'Напечатать',
    'архивировать': 'Архивировать',
    'пересчитывать': 'Пересчитать',
    'распределять': 'Распределить',
    'резервировать': 'Зарезервировать',
    'освобождать': 'Освободить',
    'пересматривать': 'Пересмотреть',
    'подготавливать': 'Подготовить'
  });

  function bpmnNamingMatches(text) {
    const source = String(text || '');
    const match = source.match(/^\s*([А-Яа-яЁёA-Za-z-]+)(?=\s|$)/u);
    if (!match) return [];
    const verb = match[1].toLocaleLowerCase('ru-RU');
    const replacement = BPMN_VERB_RECOMMENDATIONS[verb];
    if (!replacement) return [];
    const original = match[1];
    const replacementCased = /^[А-ЯЁ]/u.test(original) ? replacement : replacement.toLocaleLowerCase('ru-RU');
    if (original === replacementCased) return [];
    return [{
      offset: 0,
      length: original.length,
      message: `Для названия действия BPMN рекомендуется более конкретная форма: «${replacementCased}».`,
      replacements: [{ value: replacementCased }],
      rule: { issueType: 'style', category: { id: 'BPMN_NAMING' } },
      _localCorrection: true,
      _bpmnNaming: true,
      _category: 'BPMN'
    }];
  }

  const states = new WeakMap();
  const timers = new WeakMap();
  let popup = null;
  let popupTarget = null;
  let observer = null;

  function loadSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE) || '{}');
      return Object.assign({}, DEFAULTS, saved, {
        enabledTerminologies: Object.assign({}, DEFAULTS.enabledTerminologies, saved.enabledTerminologies || {}, {
          erp26: saved.enabledTerminologies?.erp26 ?? (saved.useErp26Terminology !== false)
        }),
        dictionary: Array.isArray(saved.dictionary) ? saved.dictionary : DEFAULTS.dictionary.slice()
      });
    } catch (_) {
      return Object.assign({}, DEFAULTS, {
        dictionary: DEFAULTS.dictionary.slice()
      });
    }
  }

  function saveSettings() { localStorage.setItem(STORAGE, JSON.stringify(settings)); }

  function positionStatus() {
    const bar = document.querySelector('#crsc-toolbar');
    const el = document.querySelector('#crsc-status');
    if (!bar || !el) return;

    // Keep the status notification directly to the right of the toolbar.
    // If there is not enough room, place it to the left instead.
    const gap = 8;
    const rect = bar.getBoundingClientRect();
    const width = el.offsetWidth || 220;
    const height = el.offsetHeight || 30;
    let left = rect.right + gap;
    if (left + width > window.innerWidth - 8) {
      left = rect.left - width - gap;
    }
    left = Math.max(8, Math.min(left, window.innerWidth - width - 8));

    // Align approximately to the vertical center of the toolbar.
    let top = rect.top + (rect.height - height) / 2;
    top = Math.max(8, Math.min(top, window.innerHeight - height - 8));

    el.style.left = `${Math.round(left)}px`;
    el.style.top = `${Math.round(top)}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
  }

  function postStatus(text) {
    ensureStatus();
    const el = document.querySelector('#crsc-status');
    if (!el) return;
    const message = String(text || '').trim();
    el.textContent = message;
    el.classList.toggle('crsc-hidden', !message);
    if (!message) return;
    positionStatus();
    clearTimeout(postStatus.timer);
    postStatus.timer = setTimeout(() => { el.textContent = ''; el.classList.add('crsc-hidden'); }, 3500);
  }

  function panelRoot() {
    return document.querySelector('.bio-properties-panel') ||
      document.querySelector('.bio-properties-panel-container') ||
      document.querySelector('[class*="properties-panel"]');
  }

  function isInEditableCanvas(field) {
    return !!field.closest('.djs-direct-editing, .djs-direct-editing-content, .djs-overlay-container');
  }

  function isTechnicalField(field) {
    if (!settings.ignoreTechnical) return false;
    if (isInEditableCanvas(field)) return false;
    const text = [
      field.getAttribute('name'), field.getAttribute('id'), field.getAttribute('placeholder'),
      field.getAttribute('aria-label'),
      field.closest('.bio-properties-panel-group-entry, .bio-properties-panel-entry')?.textContent || ''
    ].join(' ').toLowerCase();
    const technical = [
      'job type','element id','message id','process id','version tag',
      'input mapping','output mapping','expression','feel','condition expression',
      'script format','script type','implementation','binding','task definition','connector id'
    ];
    return technical.some(x => text.includes(x)) || /(^|\s)id(\s|$)/i.test(text);
  }

  function textOfField(field) {
    if (field.isContentEditable) return field.innerText || field.textContent || '';
    return field.value || '';
  }

  function selectionOffsets(field) {
    if (!field.isContentEditable) {
      return { start: field.selectionStart ?? 0, end: field.selectionEnd ?? 0 };
    }
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount || !field.contains(sel.anchorNode)) return { start: textOfField(field).length, end: textOfField(field).length };
    const range = sel.getRangeAt(0);
    const pre = range.cloneRange();
    pre.selectNodeContents(field);
    pre.setEnd(range.startContainer, range.startOffset);
    const start = pre.toString().length;
    const preEnd = range.cloneRange();
    preEnd.selectNodeContents(field);
    preEnd.setEnd(range.endContainer, range.endOffset);
    return { start, end: preEnd.toString().length };
  }

  function restoreSelectionOffsets(field, start, end) {
    if (!field.isContentEditable) {
      try { field.setSelectionRange(start, end); } catch (_) {}
      return;
    }
    const sel = window.getSelection();
    if (!sel) return;
    const walker = document.createTreeWalker(field, NodeFilter.SHOW_TEXT);
    let node;
    let pos = 0;
    let startNode = null, endNode = null, startOffset = 0, endOffset = 0;
    while ((node = walker.nextNode())) {
      const next = pos + node.nodeValue.length;
      if (!startNode && start <= next) { startNode = node; startOffset = Math.max(0, start - pos); }
      if (!endNode && end <= next) { endNode = node; endOffset = Math.max(0, end - pos); break; }
      pos = next;
    }
    if (!startNode) { startNode = field; startOffset = field.childNodes.length; }
    if (!endNode) { endNode = startNode; endOffset = startOffset; }
    const range = document.createRange();
    range.setStart(startNode, Math.min(startOffset, startNode.nodeType === 3 ? startNode.nodeValue.length : startNode.childNodes.length));
    range.setEnd(endNode, Math.min(endOffset, endNode.nodeType === 3 ? endNode.nodeValue.length : endNode.childNodes.length));
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function setText(field, value, preserveSelection = true, selectionOverride = null) {
    const selection = selectionOverride || (preserveSelection ? selectionOffsets(field) : null);
    field.focus();
    if (field.isContentEditable) {
      field.textContent = value;
      field.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: null }));
      if (selection) restoreSelectionOffsets(field, selection.start, selection.end);
      return;
    }
    const proto = field instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(field, value);
    else field.value = value;
    field.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    field.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    if (selection) {
      try { field.setSelectionRange(selection.start, selection.end); } catch (_) {}
    }
  }

  function normalizeQuotes(text) {
    // Только парные кавычки. Незакрытую кавычку не трогаем, чтобы не мешать вводу.
    let result = String(text || '');
    result = result.replace(/"([^"\r\n]{1,1000})"/g, (_, inner) => `«${String(inner).trim()}»`);
    result = result.replace(/[“„]([^”\r\n]{1,1000})”/g, (_, inner) => `«${String(inner).trim()}»`);
    result = result.replace(/«([^»\r\n]{1,1000})»/g, (_, inner) => `«${String(inner).trim()}»`);
    // Убираем пробелы непосредственно внутри кавычек независимо от их типа.
    result = result.replace(/«[ \t\u00A0]+/gu, '«');
    result = result.replace(/[ \t\u00A0]+»/gu, '»');
    return result;
  }

  function normalizeSpaces(text) {
    // Полная нормализация для ручной проверки/потери фокуса:
    // один пробел между словами, без пробелов в начале/конце.
    return String(text || '')
      .replace(/[ \t\u00A0]+/gu, ' ')
      .replace(/[ \t]+\n/gu, '\n')
      .replace(/\n[ \t]+/gu, '\n')
      .trim();
  }

  function normalizeSpacesWhileTyping(text) {
    // Во время ввода не трогаем пробелы в конце строки: пользователь мог
    // только что поставить пробел и ещё не начал следующее слово.
    // Схлопываем только лишние пробелы между уже введёнными фрагментами,
    // то есть перед ними справа уже должен находиться непробельный символ.
    // Пример: "Создать  документ" -> "Создать документ", но
    // "Создать  " остаётся как есть до ввода следующего слова.
    return String(text || '')
      .replace(/[ \t\u00A0]{2,}(?=\S)/gu, ' ');
  }

  function mapTypingSelection(originalText, normalizedText, position) {
    const text = String(originalText || '');
    const pos = Math.max(0, Math.min(Number(position) || 0, text.length));

    // Build an exact caret mapping instead of normalizing only the prefix.
    // When a run of spaces is collapsed (e.g. "Создать  документ" ->
    // "Создать документ"), every caret position inside that collapsed run
    // maps to the single remaining space. This prevents the caret from
    // jumping one character into the next word.
    let i = 0;
    let out = 0;
    while (i < text.length) {
      const ch = text[i];
      if (/^[ \t\u00A0]$/u.test(ch)) {
        let j = i + 1;
        while (j < text.length && /^[ \t\u00A0]$/u.test(text[j])) j++;
        const runLength = j - i;
        const followedByNonSpace = j < text.length && !/^[ \t\u00A0]$/u.test(text[j]);
        const normalizedRunLength = followedByNonSpace ? 1 : runLength;

        if (pos >= i && pos <= j) {
          // If the caret is in a collapsible run, place it after the single
          // retained space (or at the end of the trailing run).
          return out + normalizedRunLength;
        }

        out += normalizedRunLength;
        i = j;
        continue;
      }

      if (pos === i) return out;
      out += 1;
      i += 1;
    }

    // If position is at/past the end.
    return normalizedText.length;
  }

  function selectionAfterSpaceNormalization(field, originalText, normalizedText) {
    const selection = selectionOffsets(field);
    return {
      start: mapTypingSelection(originalText, normalizedText, selection.start),
      end: mapTypingSelection(originalText, normalizedText, selection.end)
    };
  }

  const quoteNormalizingFields = new WeakSet();
  const spaceNormalizingFields = new WeakSet();

  function mapCaretThroughDiff(originalText, normalizedText, position) {
    const a = String(originalText || '');
    const b = String(normalizedText || '');
    const pos = Math.max(0, Math.min(Number(position) || 0, a.length));
    if (a === b) return pos;

    // Fast path: unchanged prefix/suffix. This covers the common BPMN case
    // where a user inserts a forbidden space next to a quote or at a word
    // boundary. The caret stays at the logical insertion point instead of
    // being restored by the old character index.
    let prefix = 0;
    const maxPrefix = Math.min(a.length, b.length);
    while (prefix < maxPrefix && a[prefix] === b[prefix]) prefix++;
    let suffix = 0;
    while (suffix < a.length - prefix && suffix < b.length - prefix &&
           a[a.length - 1 - suffix] === b[b.length - 1 - suffix]) suffix++;

    const oldChangedEnd = a.length - suffix;
    const newChangedEnd = b.length - suffix;
    if (pos <= prefix) return pos;
    if (pos >= oldChangedEnd) return newChangedEnd + (pos - oldChangedEnd);

    // For a caret inside a changed region, use a small edit-distance alignment
    // so deletions (such as the extra space in `« text`) map to the nearest
    // logical position in the normalized text. BPMN labels are short, so the
    // bounded matrix is inexpensive and avoids cursor jumps.
    const oldPart = a.slice(prefix, oldChangedEnd);
    const newPart = b.slice(prefix, newChangedEnd);
    const n = oldPart.length, m = newPart.length;
    if (n > 400 || m > 400) {
      return prefix;
    }

    const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = 0; i <= n; i++) dp[i][0] = i;
    for (let j = 0; j <= m; j++) dp[0][j] = j;
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        const cost = oldPart[i - 1] === newPart[j - 1] ? 0 : 1;
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost
        );
      }
    }

    const targetI = Math.max(0, Math.min(n, pos - prefix));
    let i = n, j = m;
    const boundaryMap = new Array(n + 1);
    boundaryMap[n] = m;
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0) {
        const cost = oldPart[i - 1] === newPart[j - 1] ? 0 : 1;
        if (dp[i][j] === dp[i - 1][j - 1] + cost) {
          if (boundaryMap[i - 1] == null) boundaryMap[i - 1] = j - 1;
          i--; j--; continue;
        }
      }
      if (i > 0 && dp[i][j] === dp[i - 1][j] + 1) {
        if (boundaryMap[i - 1] == null) boundaryMap[i - 1] = j;
        i--; continue;
      }
      if (j > 0) {
        j--;
        continue;
      }
      break;
    }

    let mapped = boundaryMap[targetI];
    if (mapped == null) {
      mapped = targetI;
      for (let k = targetI - 1; k >= 0; k--) {
        if (boundaryMap[k] != null) { mapped = boundaryMap[k]; break; }
      }
    }
    return prefix + Math.max(0, Math.min(m, mapped));
  }

  function selectionAfterQuoteNormalization(field, originalText, normalizedText) {
    const selection = selectionOffsets(field);
    return {
      start: mapCaretThroughDiff(originalText, normalizedText, selection.start),
      end: mapCaretThroughDiff(originalText, normalizedText, selection.end)
    };
  }

  function autoNormalizeQuotes(field, preserveSelection = true) {
    if (!settings.autoQuotes || quoteNormalizingFields.has(field)) return false;
    const current = textOfField(field);
    const normalized = normalizeQuotes(current);
    if (normalized === current) return false;
    quoteNormalizingFields.add(field);
    try {
      const selection = preserveSelection ? selectionAfterQuoteNormalization(field, current, normalized) : null;
      setText(field, normalized, !!selection, selection);
    } finally {
      quoteNormalizingFields.delete(field);
    }
    return true;
  }

  function autoNormalizeSpaces(field, whileTyping = false) {
    if (!settings.autoSpaces || spaceNormalizingFields.has(field)) return false;
    const current = textOfField(field);
    const normalized = whileTyping ? normalizeSpacesWhileTyping(current) : normalizeSpaces(current);
    if (normalized === current) return false;
    spaceNormalizingFields.add(field);
    try {
      const selection = whileTyping ? selectionAfterSpaceNormalization(field, current, normalized) : null;
      setText(field, normalized, !whileTyping, selection);
    } finally {
      spaceNormalizingFields.delete(field);
    }
    return true;
  }

  function autoNormalizeText(field, whileTyping = false) {
    const spacesChanged = autoNormalizeSpaces(field, whileTyping);
    const quotesChanged = autoNormalizeQuotes(field, whileTyping);
    return spacesChanged || quotesChanged;
  }

  function normalizeBeforeCheck(field) {
    if (!settings.autoSpaces && !settings.autoQuotes) return false;
    const spacesChanged = settings.autoSpaces ? autoNormalizeSpaces(field, false) : false;
    const quotesChanged = settings.autoQuotes ? autoNormalizeQuotes(field) : false;
    return spacesChanged || quotesChanged;
  }

  function isTextInput(field) {
    if (field.disabled || field.readOnly) return false;
    if (field.isContentEditable) return true;
    if (field.tagName === 'TEXTAREA') return true;
    if (field.tagName !== 'INPUT') return false;
    return ['text', 'search', 'url', ''].includes((field.type || 'text').toLowerCase());
  }

  function discoverFields() {
    const fields = [];
    const panel = panelRoot();
    if (panel) fields.push(...panel.querySelectorAll('input, textarea, [contenteditable="true"]'));

    // bpmn-js direct editing overlay used when editing a label directly on the canvas.
    fields.push(...document.querySelectorAll(
      '.djs-direct-editing input, .djs-direct-editing textarea, .djs-direct-editing [contenteditable="true"], ' +
      'input.djs-direct-editing-content, textarea.djs-direct-editing-content, [contenteditable="true"].djs-direct-editing-content'
    ));

    return Array.from(new Set(fields)).filter(field => isTextInput(field) && !isTechnicalField(field));
  }

  function debounceCheck(field) {
    clearTimeout(timers.get(field));
    const timer = setTimeout(() => checkField(field), Number(settings.delay) || 700);
    timers.set(field, timer);
  }

  function localCorrectionMatches(text) {
    const result = [];
    for (const rule of correctionRules) {
      rule.pattern.lastIndex = 0;
      let match;
      while ((match = rule.pattern.exec(text))) {
        result.push({
          offset: match.index,
          length: match[0].length,
          message: rule.message,
          replacements: [{ value: rule.replacement }],
          rule: { issueType: 'misspelling', category: { id: 'CASING' } },
          _localCorrection: true,
          _correctionId: rule.id,
          _category: rule.category
        });
        if (match[0].length === 0) rule.pattern.lastIndex++;
      }
    }
    return result;
  }
  function mergeMatches(localMatches, languageToolMatches, text) {
    const result = [...localMatches];
    for (const m of languageToolMatches) {
      const overlaps = result.some(existing =>
        m.offset < existing.offset + existing.length &&
        existing.offset < m.offset + m.length
      );
      if (!overlaps) result.push(m);
    }
    return result.sort((a, b) => a.offset - b.offset);
  }

  let currentFieldForCheck = null;

  async function getMatches(text) {
    await loadCorrections();
    await loadTerminologyIndex();
    await loadErp26Dictionary();
    await loadAdditionalTerminologies();
    await loadUserCustomTerms();
    if (userCustomTerms.length) {
      settings.dictionary = Array.from(new Set([...(settings.dictionary || []), ...userCustomTerms]));
    }
    const localMatches = [...localCorrectionMatches(text), ...erp26Matches(text), ...additionalTerminologyMatches(text), ...(isCanvasTextContext(currentFieldForCheck) ? bpmnNamingMatches(text) : [])];
    if (!settings.useLanguageTool) return localMatches;
    try {
      const languageToolMatches = filterMatches(await checkLanguageTool(text), text);
      return mergeMatches(localMatches, languageToolMatches, text);
    } catch (error) {
      if (localMatches.length) return localMatches;
      throw error;
    }
  }

  function isCanvasTextContext(field) {
    return !!field && isInEditableCanvas(field);
  }

  async function checkField(field, force) {
    currentFieldForCheck = field;
    if (!settings.enabled) return;
    const text = textOfField(field).trim();
    if (!text || text.length < 2) {
      clearError(field);
      hidePopupFor(field);
      return;
    }
    if (text.length > 60000) return;

    const requestText = text;
    states.set(field, { text: requestText, checking: true });
    if (force) showWorking(field);

    try {
      const matches = await getMatches(requestText);
      if (textOfField(field).trim() !== requestText) return;
      states.set(field, { text: requestText, matches, checking: false });
      setError(field, matches.length > 0);
      if (matches.length) showMatches(field, matches, requestText);
      else if (popupTarget === field) hidePopupFor(field);
    } catch (error) {
      states.set(field, { text: requestText, matches: [], checking: false, error });
      setError(field, false);
      if (force && settings.useLanguageTool) postStatus('Не удалось подключиться к LanguageTool');
      if (force) hidePopupFor(field);
    }
  }

  async function checkAll() {
    const fields = discoverFields();
    if (!fields.length) {
      postStatus('Нет видимых текстовых полей для проверки.');
      return;
    }
    let errors = 0;
    postStatus('Проверка видимых полей…');
    for (const field of fields) {
      try {
        currentFieldForCheck = field;
        normalizeBeforeCheck(field);
        const text = textOfField(field).trim();
        if (!text) continue;
        const matches = await getMatches(text);
        states.set(field, { text, matches, checking: false });
        setError(field, matches.length > 0);
        errors += matches.length;
      } catch (_) {}
    }
    postStatus(errors ? `Найдено ошибок/замечаний: ${errors}` : 'Ошибок не найдено');
  }

  function effectiveDictionary() {
    const terms = new Set((settings.dictionary || []).map(String));
    for (const entry of terminologyTerms.values()) {
      if (terminologyEnabled(entry.id)) {
        for (const term of entry.terms || []) terms.add(String(term));
      }
    }
    return Array.from(terms);
  }

  function languageToolEndpoint() {
    if (settings.languageToolSource === 'local') return settings.localEndpoint || DEFAULTS.localEndpoint;
    return settings.externalEndpoint || settings.endpoint || DEFAULTS.externalEndpoint;
  }

  async function checkLanguageTool(text) {
    if (!settings.useLanguageTool) return [];
    const params = new URLSearchParams();
    params.set('text', text);
    params.set('language', settings.language || 'ru-RU');
    params.set('enabledOnly', 'false');
    const dictionary = effectiveDictionary();
    if (dictionary.length) params.set('ignore', dictionary.join(', '));

    const response = await fetch(languageToolEndpoint(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    return Array.isArray(json.matches) ? json.matches : [];
  }

  function filterMatches(matches, text) {
    const dict = new Set(effectiveDictionary().map(x => x.toLowerCase()));
    return matches.filter(m => {
      const bad = text.slice(m.offset, m.offset + m.length);
      if (!bad || dict.has(bad.toLowerCase())) return false;
      const replacements = Array.from(new Set((m.replacements || []).map(r => (r.value || '').trim()).filter(Boolean)));
      const issueType = m.rule?.issueType || '';
      const category = m.rule?.category?.id || '';
      if (!replacements.length) return false;
      return issueType !== 'style' || category === 'CASING';
    });
  }

  function createPopup() {
    if (popup) return popup;
    popup = document.createElement('div');
    popup.id = 'crsc-popup';
    popup.addEventListener('mousedown', e => e.preventDefault());
    document.body.appendChild(popup);
    return popup;
  }

  function positionPopup(field) {
    const rect = field.getBoundingClientRect();
    const p = createPopup();
    const width = Math.min(390, Math.max(280, window.innerWidth - 16));
    const maxLeft = Math.max(8, window.innerWidth - width - 8);
    p.style.width = `${Math.min(390, width)}px`;
    p.style.left = `${Math.min(Math.max(8, rect.left), maxLeft)}px`;
    const height = p.offsetHeight || 120;
    const below = rect.bottom + 6;
    const top = below + height < window.innerHeight ? below : rect.top - height - 6;
    p.style.top = `${Math.max(8, top)}px`;
  }

  function showWorking(field) {
    popupTarget = field;
    const p = createPopup();
    p.innerHTML = '<div class="crsc-title">Проверка…</div>';
    p.classList.add('crsc-visible');
    positionPopup(field);
  }

  function showMatches(field, matches, text) {
    popupTarget = field;
    const p = createPopup();
    p.innerHTML = '';

    const title = document.createElement('div');
    title.className = 'crsc-title';
    title.textContent = `Найдено: ${matches.length}`;
    p.appendChild(title);

    matches.slice(0, 10).forEach(m => {
      const row = document.createElement('div');
      row.className = 'crsc-match';

      const bad = text.slice(m.offset, m.offset + m.length);
      const msg = document.createElement('div');
      msg.className = 'crsc-message';
      msg.innerHTML = '';
      const wrong = document.createElement('span');
      wrong.className = 'crsc-wrong';
      wrong.textContent = bad;
      msg.appendChild(wrong);
      const explanation = document.createElement('span');
      explanation.textContent = ` — ${m.message || 'возможная ошибка'}`;
      msg.appendChild(explanation);
      row.appendChild(msg);

      const reps = document.createElement('div');
      reps.className = 'crsc-replacements';
      (m.replacements || []).slice(0, 6).forEach(rep => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'crsc-replace';
        b.textContent = rep.value;
        b.title = 'Заменить';
        b.addEventListener('click', () => applyReplacement(field, m, rep.value));
        reps.appendChild(b);
      });
      row.appendChild(reps);

      const ignore = document.createElement('button');
      ignore.type = 'button';
      ignore.className = 'crsc-ignore';
      ignore.textContent = 'Игнорировать слово';
      ignore.addEventListener('click', () => addToDictionary(bad, field));
      row.appendChild(ignore);

      p.appendChild(row);
    });

    if (matches.length > 10) {
      const more = document.createElement('div');
      more.className = 'crsc-more';
      more.textContent = `и ещё ${matches.length - 10}…`;
      p.appendChild(more);
    }

    p.classList.add('crsc-visible');
    positionPopup(field);
  }

  function applyReplacement(field, match, replacement) {
    const current = textOfField(field);
    // Ignore stale popup entries if the field changed.
    if (match.offset < 0 || match.offset + match.length > current.length) return;
    const before = current.slice(0, match.offset);
    const after = current.slice(match.offset + match.length);
    setText(field, before + replacement + after);
    clearError(field);
    hidePopupFor(field);
    debounceCheck(field);
  }

  function addToDictionary(word, field) {
    const clean = String(word || '').trim();
    if (!clean) return;
    loadUserCustomTerms().then(() => {
      userCustomTerms = Array.from(new Set([...(userCustomTerms || []), clean]));
      sendTerminologyOperation({ op: 'update-user-custom', terms: userCustomTerms });
    });
    postStatus(`Добавлено в пользовательские исключения: ${clean}`);
    checkField(field, true);
  }

  function setError(field, hasError) {
    field.classList.toggle('crsc-field-error', hasError);
    field.classList.toggle('crsc-field-ok', !hasError && !!textOfField(field).trim());
    if (hasError) field.setAttribute('data-crsc-error', 'true');
    else field.removeAttribute('data-crsc-error');
  }

  function clearError(field) {
    field.classList.remove('crsc-field-error', 'crsc-field-ok');
    field.removeAttribute('data-crsc-error');
    states.delete(field);
  }

  function hidePopupFor(field) {
    if (!popup || (field && popupTarget !== field)) return;
    popup.classList.remove('crsc-visible');
    popupTarget = null;
  }

  function bindField(field) {
    if (field.dataset.crscBound === '1') return;
    field.dataset.crscBound = '1';

    field.addEventListener('input', () => {
      // Кавычки можно нормализовать сразу. Пробелы во время ввода схлопываем
      // без удаления одиночного пробела в конце, чтобы курсор не перескакивал.
      autoNormalizeText(field, true);
      clearError(field);
      hidePopupFor(field);
      debounceCheck(field);
    });

    field.addEventListener('focus', () => {
      const state = states.get(field);
      if (state?.matches?.length) showMatches(field, state.matches, state.text);
      else debounceCheck(field);
    });

    field.addEventListener('contextmenu', () => {
      const state = states.get(field);
      if (state?.matches?.length) {
        setTimeout(() => showMatches(field, state.matches, state.text), 0);
      }
    });

    field.addEventListener('blur', () => {
      if (settings.autoSpaces || settings.autoQuotes) normalizeBeforeCheck(field);
      setTimeout(() => hidePopupFor(field), 220);
    });
    field.addEventListener('keydown', e => {
      if (e.key === 'Escape') hidePopupFor(field);
    });
  }

  function scanFields() {
    discoverFields().forEach(bindField);
  }

  function checkSelected() {
    const fields = discoverFields();
    const focused = document.activeElement;
    if (focused && fields.includes(focused)) {
      normalizeBeforeCheck(focused);
      checkField(focused, true);
      return;
    }
    if (fields.length) {
      normalizeBeforeCheck(fields[0]);
      checkField(fields[0], true);
    } else postStatus('Выберите элемент BPMN или начните редактирование подписи на canvas.');
  }

  function toggle() {
    settings.enabled = !settings.enabled;
    saveSettings();
    updateToolbar();
    document.documentElement.classList.toggle('crsc-disabled', !settings.enabled);
    if (!settings.enabled) {
      discoverFields().forEach(clearError);
      hidePopupFor();
    }
    postStatus(settings.enabled ? 'Проверка орфографии включена' : 'Проверка орфографии выключена');
  }

  function updateToolbar() {
    const btn = document.querySelector('#crsc-toggle');
    if (btn) {
      btn.classList.toggle('crsc-on', !!settings.enabled);
      btn.classList.toggle('crsc-off', !settings.enabled);
      btn.textContent = settings.enabled ? 'А✓' : 'А×';
    }
  }

  function ensureToolbar() {
    if (document.querySelector('#crsc-toolbar')) return;
    const bar = document.createElement('div');
    bar.id = 'crsc-toolbar';
    const btn = document.createElement('button');
    btn.type = 'button'; btn.id = 'crsc-toggle'; btn.title = 'Включить/выключить (Ctrl+Shift+L)';
    btn.addEventListener('click', toggle);
    const check = document.createElement('button');
    check.type = 'button'; check.id = 'crsc-check'; check.textContent = 'Проверить';
    check.title = 'Проверить текущее поле'; check.addEventListener('click', checkSelected);
    const all = document.createElement('button');
    all.type = 'button'; all.id = 'crsc-all'; all.textContent = 'Все';
    all.title = 'Проверить все видимые поля'; all.addEventListener('click', checkAll);
    const numberBtn = document.createElement('button');
    numberBtn.type = 'button'; numberBtn.id = 'crsc-number'; numberBtn.textContent = 'Нумеровать';
    numberBtn.title = 'Автоматически пронумеровать шаги BPMN'; numberBtn.addEventListener('click', numberDiagram);
    const alignBtn = document.createElement('button');
    alignBtn.type = 'button'; alignBtn.id = 'crsc-resize'; alignBtn.textContent = '↔';
    alignBtn.title = 'Выровнять размер задач'; alignBtn.addEventListener('click', alignTaskSizes);
    const settingsBtn = document.createElement('button');
    settingsBtn.type = 'button'; settingsBtn.id = 'crsc-settings'; settingsBtn.textContent = '⚙';
    settingsBtn.title = 'Настройки'; settingsBtn.addEventListener('click', showSettings);
    bar.append(btn, check, all, numberBtn, alignBtn, settingsBtn);
    document.body.appendChild(bar);
    updateToolbar();
  }

  function ensureStatus() {
    if (document.querySelector('#crsc-status')) return;
    const el = document.createElement('div'); el.id = 'crsc-status'; el.classList.add('crsc-hidden'); document.body.appendChild(el);
  }

  // ---- BPMN auto numbering -------------------------------------------------
  // Register a lightweight bpmn-js module without requiring a bundled helper.
  // Camunda Modeler plugin helpers use the same window.plugins registration shape.
  let numberingRegistrationDone = false;

  // Group complex plugin operations into a single diagram-js CommandStack
  // logical unit. Commands executed from preExecute inherit the outer command
  // id, so one Ctrl+Z / Ctrl+Shift+Z reverts / reapplies the whole operation.
  function registerAtomicPluginCommands(commandStack) {
    if (!commandStack || commandStack.__crscAtomicCommandsRegistered) return;

    const atomicHandler = {
      preExecute(context) {
        if (context && typeof context.run === 'function') {
          context.result = context.run();
        }
      },
      execute() { return []; },
      revert() { return []; }
    };

    try {
      commandStack.register('crsc.numberDiagram', atomicHandler);
      commandStack.register('crsc.alignTaskSizes', atomicHandler);
      commandStack.__crscAtomicCommandsRegistered = true;
    } catch (error) {
      // Registration may already exist on this editor instance after a plugin
      // reload. Keep the service usable and fall back to normal execution.
      console.warn('[Camunda Russian Spell Checker] atomic command registration failed', error);
    }
  }

  function executeAtomicPluginCommand(service, command, run) {
    const commandStack = service && service.commandStack;
    if (!commandStack || typeof commandStack.execute !== 'function' || !commandStack.__crscAtomicCommandsRegistered) {
      return run();
    }

    const context = { run, result: undefined };
    commandStack.execute(command, context);
    return context.result;
  }

  function registerNumberingModule() {
    if (numberingRegistrationDone) return;
    numberingRegistrationDone = true;

    try {
      window.plugins = window.plugins || [];
      window.plugins.push({
        plugin: {
          __init__: [ 'crscNumberingService' ],
          crscNumberingService: [ 'type', function(eventBus, elementRegistry, modeling, canvas, commandStack) {
            registerAtomicPluginCommands(commandStack);

            const service = {
              elementRegistry,
              modeling,
              canvas,
              commandStack,
              numberDiagram,
              currentSelection: []
            };

            window.__crscNumberingServices = window.__crscNumberingServices || [];
            window.__crscNumberingServices.push(service);

            function isVisible() {
              const container = canvas && canvas.getContainer && canvas.getContainer();
              if (!container) return false;
              const rect = container.getBoundingClientRect();
              return rect.width > 0 && rect.height > 0 && getComputedStyle(container).display !== 'none';
            }

            service.isVisible = isVisible;
            if (eventBus) {
              eventBus.on('selection.changed', function(event) {
                service.currentSelection = Array.isArray(event?.newSelection) ? event.newSelection.slice() : [];
              });
            }

            function cleanup() {
              const list = window.__crscNumberingServices || [];
              const i = list.indexOf(service);
              if (i >= 0) list.splice(i, 1);
            }

            if (eventBus) eventBus.on('diagram.destroy', cleanup);
          } ]
        },
        type: 'bpmn.modeler.additionalModules'
      });
    } catch (_) {}
  }

  function getNumberingService() {
    const list = window.__crscNumberingServices || [];
    const visible = list.filter(x => x && typeof x.isVisible === 'function' && x.isVisible());
    return visible[visible.length - 1] || list[list.length - 1] || null;
  }

  function isNumberedStep(element) {
    const bo = element && element.businessObject;
    if (!bo || !bo.$type) return false;

    // The sizing helper uses a special Task named `ШАБЛОН` as the reference
    // element. It must never participate in automatic step numbering, even
    // if it already has a generated number from an older plugin version.
    const rawName = typeof bo.name === 'string' ? bo.name : '';
    const normalizedName = rawName
      .replace(/^[\s\d. :]+/u, '')
      .replace(/[ \t\u00A0]+/gu, ' ')
      .trim()
      .toLocaleUpperCase('ru-RU');
    if (normalizedName === 'ШАБЛОН') return false;

    const type = bo.$type;
    return type === 'bpmn:Task' ||
      type === 'bpmn:UserTask' ||
      type === 'bpmn:ServiceTask' ||
      type === 'bpmn:SendTask' ||
      type === 'bpmn:ReceiveTask' ||
      type === 'bpmn:ManualTask' ||
      type === 'bpmn:BusinessRuleTask' ||
      type === 'bpmn:ScriptTask' ||
      type === 'bpmn:CallActivity' ||
      type === 'bpmn:SubProcess' ||
      type === 'bpmn:Transaction' ||
      type === 'bpmn:AdHocSubProcess';
  }

  function hasLabel(element) {
    const name = element?.businessObject?.name;
    return typeof name === 'string' && name.trim().length > 0;
  }

  function parseNumberingPrefix(name) {
    const text = String(name || '').trim();

    // Stable form for subprocesses that have both a generated step number
    // and their own methodological number, e.g.
    // `08: 01.05.07 Автоматическое создание перемещения`.
    const generatedOwn = text.match(/^(\d+(?:\.\d+)*)\s*:\s*(\d+(?:\.\d+)*)\s*(.*)$/u);
    if (generatedOwn) {
      return {
        outer: generatedOwn[1],
        number: generatedOwn[2],
        label: (generatedOwn[3] || '').trim(),
        generatedOwn: true,
        methodological: true
      };
    }

    // Methodological number without a generated prefix, e.g.
    // `01.05.07 Автоматическое создание перемещения`. Check this before
    // the generated `NN.NN.` form because a methodological number also
    // starts with a dotted numeric sequence.
    const own = text.match(/^(\d+(?:\.\d+){2,})\s+(.+)$/u);
    if (own) {
      return {
        outer: null,
        number: own[1],
        label: (own[2] || '').trim(),
        generatedOwn: false,
        methodological: true
      };
    }

    // Current generated step number, e.g. `08: Создать документ` or
    // `08.01: Проверить документ`. All generated step numbers use a colon.
    const generatedColon = text.match(/^(\d+(?:\.\d+)*)\s*:\s*(.*)$/u);
    if (generatedColon) {
      return {
        outer: null,
        number: generatedColon[1],
        label: (generatedColon[2] || '').trim(),
        generatedOwn: false,
        methodological: false
      };
    }

    // Legacy generated step number from releases before v0.6.26, e.g.
    // `08. Создать документ` or `02.01. Проверить документ`. Keep parsing it
    // so the next numbering run migrates old diagrams to the unified colon
    // format instead of accumulating a second prefix.
    const generatedLegacyDot = text.match(/^(\d+(?:\.\d+)*)\.\s*(.*)$/u);
    if (generatedLegacyDot) {
      return {
        outer: null,
        number: generatedLegacyDot[1],
        label: (generatedLegacyDot[2] || '').trim(),
        generatedOwn: false,
        methodological: false
      };
    }

    return null;
  }

  function stripStepPrefix(name) {
    let text = String(name || '').trim();

    // Remove one or more generated `NN:` prefixes. This is intentionally
    // repeated so even names produced by older buggy versions are recovered
    // instead of accumulating prefixes on every subsequent numbering run.
    let previous;
    do {
      previous = text;
      text = text.replace(/^\s*\d+(?:\.\d+)*\s*:\s*/u, '').trim();
    } while (text !== previous);

    // Remove a legacy generated dotted step prefix, such as `02.01.` or
    // `01.05.07.01.`. Current versions generate `NN:` / `NN.NN:` instead, but
    // old prefixes are still recognized so existing diagrams are migrated on
    // the next numbering run. Do this after colon-prefix cleanup so a bare
    // methodological number like `01.05.07` is preserved until extracted.
    return text.replace(/^\s*\d+(?:\.\d+)*\.\s*/u, '').trim();
  }

  function padStep(n) {
    return String(n).padStart(2, '0');
  }

  function extractPreservedOwnNumber(name) {
    const parsed = parseNumberingPrefix(name);
    if (!parsed?.methodological || !parsed?.number || !parsed.number.includes('.')) return null;
    return parsed.number;
  }

  function stepLabel(prefix, n, original, preserveOwnNumber = false) {
    const originalText = String(original || '').trim();
    let clean = stripStepPrefix(originalText);
    let ownNumber = null;

    if (preserveOwnNumber) {
      // A subprocess may carry its own methodology number. It can appear
      // either on its own (`01.05.07 Label`) or after our generated step
      // number (`08: 01.05.07 Label`). Preserve it verbatim.
      const parsed = parseNumberingPrefix(originalText);
      if (parsed?.methodological && parsed?.number && parsed.number.includes('.')) {
        ownNumber = parsed.number;
        clean = parsed.label || clean;
      }
    }

    if (!clean) return null;
    const number = prefix ? `${prefix}.${padStep(n)}` : padStep(n);
    if (preserveOwnNumber && ownNumber) {
      return `${number}: ${ownNumber} ${clean}`;
    }
    return `${number}: ${clean}`;
  }

  function isFlowNode(element) {
    return !!(element && element.businessObject && typeof element.businessObject.$type === 'string' && element.businessObject.$type.startsWith('bpmn:'));
  }

  function isContainer(element) {
    const type = element?.businessObject?.$type;
    return type === 'bpmn:Process' || type === 'bpmn:SubProcess' || type === 'bpmn:Transaction' || type === 'bpmn:AdHocSubProcess';
  }

  function directChildren(elementRegistry, container) {
    const all = elementRegistry.filter(e => e && e.parent === container);
    return all.filter(isFlowNode);
  }

  function sequenceFlowTargets(node) {
    const outgoing = node?.outgoing || node?.businessObject?.outgoing || [];
    return outgoing
      .map(flow => flow && (flow.target || flow.businessObject?.target))
      .filter(Boolean);
  }

  function sequenceFlowSources(node) {
    const incoming = node?.incoming || node?.businessObject?.incoming || [];
    return incoming
      .map(flow => flow && (flow.source || flow.businessObject?.source))
      .filter(Boolean);
  }

  // Build a scope-local graph between numbered activities, walking through
  // gateways/events/other non-numbered nodes. This preserves the BPMN flow
  // order instead of relying on the element's X/Y position.
  function buildStepGraph(nodes) {
    const nodeSet = new Set(nodes);
    const numbered = nodes.filter(isNumberedStep);
    const numberedSet = new Set(numbered);
    const next = new Map(numbered.map(n => [n, new Set()]));
    const prevCount = new Map(numbered.map(n => [n, 0]));

    function walk(startStep, current, visited) {
      if (!current || visited.has(current.id)) return;
      visited.add(current.id);
      if (numberedSet.has(current)) {
        if (current !== startStep && !next.get(startStep).has(current)) {
          next.get(startStep).add(current);
          prevCount.set(current, (prevCount.get(current) || 0) + 1);
        }
        return;
      }
      for (const target of sequenceFlowTargets(current)) {
        if (nodeSet.has(target)) walk(startStep, target, visited);
      }
    }

    for (const step of numbered) {
      for (const target of sequenceFlowTargets(step)) walk(step, target, new Set());
    }

    return { numbered, next, prevCount };
  }

  function fallbackSort(nodes) {
    return nodes.slice().sort((a, b) => {
      const ay = Number(a.y) || 0;
      const by = Number(b.y) || 0;
      if (Math.abs(ay - by) > 10) return ay - by;
      const ax = Number(a.x) || 0;
      const bx = Number(b.x) || 0;
      return ax - bx;
    });
  }

  function orderedSteps(nodes) {
    const { numbered, next, prevCount } = buildStepGraph(nodes);
    if (!numbered.length) return [];

    const rank = new Map();
    const queue = numbered.filter(n => (prevCount.get(n) || 0) === 0);
    const starts = queue.length ? queue : fallbackSort(numbered).slice(0, 1);
    const working = starts.slice();
    const used = new Set();

    while (working.length) {
      const node = working.shift();
      if (used.has(node)) continue;
      used.add(node);
      rank.set(node, rank.size);
      const successors = Array.from(next.get(node) || []).sort((a, b) => {
        const ax = Number(a.x) || 0;
        const bx = Number(b.x) || 0;
        if (ax !== bx) return ax - bx;
        return (Number(a.y) || 0) - (Number(b.y) || 0);
      });
      for (const successor of successors) {
        if (!used.has(successor)) working.push(successor);
      }
    }

    // Add disconnected branches/components deterministically.
    for (const node of fallbackSort(numbered)) {
      if (!used.has(node)) {
        rank.set(node, rank.size);
        used.add(node);
      }
    }

    return numbered.slice().sort((a, b) => rank.get(a) - rank.get(b));
  }

  function containerForElement(element) {
    let parent = element?.parent;
    while (parent) {
      if (isContainer(parent)) return parent;
      parent = parent.parent;
    }
    return null;
  }

  function childScopes(container, elementRegistry) {
    return directChildren(elementRegistry, container)
      .filter(isNumberedStep)
      .filter(e => {
        const type = e.businessObject?.$type;
        return type === 'bpmn:SubProcess' || type === 'bpmn:Transaction' || type === 'bpmn:AdHocSubProcess';
      });
  }

  function isSubProcessLike(element) {
    const type = element?.businessObject?.$type;
    return type === 'bpmn:SubProcess' || type === 'bpmn:Transaction' || type === 'bpmn:AdHocSubProcess';
  }

  function getOwnProcessNumber(element) {
    if (!isSubProcessLike(element)) return null;
    return extractPreservedOwnNumber(element?.businessObject?.name);
  }

  function numberScope(container, service, prefix, changes) {
    const children = directChildren(service.elementRegistry, container);
    const ordered = orderedSteps(children).filter(hasLabel);
    const numberingMap = new Map();
    const actionNumberByKey = new Map();
    let nextActionNumber = 1;

    // When enabled, identical actions on the same level share one generated
    // step number. Example: A, A, B -> 01: A, 01: A, 02: B. We compare the
    // actual action text after removing generated prefixes (and, for
    // subprocesses, preserving only the human-readable action text).
    function actionKey(element) {
      const name = element?.businessObject?.name || '';
      let key = stripStepPrefix(name);
      if (isSubProcessLike(element)) {
        const parsed = parseNumberingPrefix(name);
        if (parsed?.number && parsed.number.includes('.')) key = parsed.label || key;
      }
      return key
        .replace(/[ \t\u00A0]+/gu, ' ')
        .trim()
        .toLocaleLowerCase('ru-RU');
    }

    const generatedNumbers = new Map();
    ordered.forEach((element, index) => {
      let stepNo;
      if (settings.oneNumberForIdenticalActions) {
        const key = actionKey(element);
        if (actionNumberByKey.has(key)) {
          stepNo = actionNumberByKey.get(key);
        } else {
          stepNo = nextActionNumber++;
          actionNumberByKey.set(key, stepNo);
        }
      } else {
        stepNo = index + 1;
      }
      generatedNumbers.set(element.id, stepNo);

      const newName = stepLabel(
        prefix,
        stepNo,
        element.businessObject.name,
        isSubProcessLike(element)
      );
      if (!newName || newName === element.businessObject.name) {
        if (newName) numberingMap.set(element.id, newName.split(/[.:]/u)[0]);
        return;
      }
      numberingMap.set(element.id, prefix ? `${prefix}.${padStep(stepNo)}` : padStep(stepNo));
    });

    for (const element of ordered) {
      const stepNo = generatedNumbers.get(element.id) || (ordered.indexOf(element) + 1);
      const newName = stepLabel(
        prefix,
        stepNo,
        element.businessObject.name,
        isSubProcessLike(element)
      );
      if (newName && newName !== element.businessObject.name) {
        const oldName = element.businessObject.name;
        service.modeling.updateLabel(element, newName);
        changes.push({ element, oldName, newName });
      }
    }

    // Recursively number child scopes. For a subprocess with an existing
    // methodology number (e.g. 01.05.07), preserve that number for its own
    // identity and use it as the prefix for child steps. Every generated step
    // number uses the same `number:` separator; the subprocess methodology
    // number remains separate: `08: 01.05.07 Название` or
    // `08.01: 01.05.07 Название` on a nested level.
    for (const element of ordered) {
      if (!isSubProcessLike(element)) continue;

      const ownIndex = ordered.indexOf(element) + 1;
      const generatedStepNumber = prefix ? `${prefix}.${padStep(ownIndex)}` : padStep(ownIndex);
      const preservedOwnNumber = getOwnProcessNumber(element);
      const childPrefix = preservedOwnNumber || generatedStepNumber;
      numberScope(element, service, childPrefix, changes);
    }
  }

  function isParticipant(element) {
    return element?.businessObject?.$type === 'bpmn:Participant';
  }

  function isTaskElement(element) {
    const type = element?.businessObject?.$type;
    return type === 'bpmn:Task' ||
      type === 'bpmn:UserTask' ||
      type === 'bpmn:ServiceTask' ||
      type === 'bpmn:SendTask' ||
      type === 'bpmn:ReceiveTask' ||
      type === 'bpmn:ManualTask' ||
      type === 'bpmn:BusinessRuleTask' ||
      type === 'bpmn:ScriptTask';
  }

  function participantAncestor(element) {
    let current = element;
    while (current) {
      if (isParticipant(current)) return current;
      current = current.parent;
    }
    return null;
  }

  function processAncestor(element) {
    let current = element;
    let process = null;
    while (current) {
      if (current?.businessObject?.$type === 'bpmn:Process') process = current;
      current = current.parent;
    }
    return process;
  }

  function isDescendantOf(element, ancestor) {
    let current = element;
    while (current) {
      if (current === ancestor) return true;
      current = current.parent;
    }
    return false;
  }

  function normalizedExactTaskName(element) {
    return String(element?.businessObject?.name || '')
      .replace(/[ \t\u00A0]+/gu, ' ')
      .trim()
      .toLocaleLowerCase('ru-RU');
  }

  function findTemplateTasks(elementRegistry, scope = null) {
    return elementRegistry.filter(element => {
      if (!isTaskElement(element)) return false;
      if (scope && !isDescendantOf(element, scope)) return false;
      return normalizedExactTaskName(element) === 'шаблон';
    });
  }

  function taskScopeForTemplate(template) {
    return participantAncestor(template) || processAncestor(template);
  }

  function isSequenceFlow(connection) {
    return connection?.businessObject?.$type === 'bpmn:SequenceFlow';
  }

  function isAssociationLikeConnection(connection) {
    const type = String(connection?.businessObject?.$type || '');
    return type === 'bpmn:Association' ||
      type === 'bpmn:DataInputAssociation' ||
      type === 'bpmn:DataOutputAssociation';
  }

  function isAuxiliaryAssociatedShape(element) {
    const type = String(element?.businessObject?.$type || '');
    return type === 'bpmn:TextAnnotation' ||
      type === 'bpmn:DataObjectReference' ||
      type === 'bpmn:DataStoreReference' ||
      type === 'bpmn:DataInput' ||
      type === 'bpmn:DataOutput';
  }

  function isMovableFlowShape(element) {
    if (!element || element.labelTarget || element.waypoints) return false;
    return Number.isFinite(Number(element.x)) && Number.isFinite(Number(element.y)) &&
      Number.isFinite(Number(element.width)) && Number.isFinite(Number(element.height));
  }

  function elementCenterX(element) {
    return (Number(element?.x) || 0) + (Number(element?.width) || 0) / 2;
  }

  function elementCenterY(element) {
    return (Number(element?.y) || 0) + (Number(element?.height) || 0) / 2;
  }

  function elementRight(element) {
    return (Number(element?.x) || 0) + (Number(element?.width) || 0);
  }

  function elementDepth(element) {
    let depth = 0;
    let current = element;
    while (current) {
      depth += 1;
      current = current.parent;
    }
    return depth;
  }

  function isLane(element) {
    return element?.businessObject?.$type === 'bpmn:Lane';
  }

  function forwardSequenceFlowsForParent(elementRegistry, parent, template) {
    return elementRegistry.filter(connection => {
      if (!isSequenceFlow(connection)) return false;
      const source = connection.source;
      const target = connection.target;
      if (!isMovableFlowShape(source) || !isMovableFlowShape(target)) return false;
      if (source === template || target === template) return false;
      if (source.parent !== parent || target.parent !== parent) return false;

      // Only left-to-right flows participate in horizontal spacing. Vertical
      // and return flows keep the author's layout and are not used as a reason
      // to shift elements horizontally.
      return elementCenterX(target) > elementCenterX(source) + 0.5;
    });
  }

  function collectForwardReachable(roots, edges) {
    const outgoing = new Map();
    for (const edge of edges) {
      const list = outgoing.get(edge.source) || [];
      list.push(edge.target);
      outgoing.set(edge.source, list);
    }

    const active = new Set();
    const queue = Array.from(roots || []);
    while (queue.length) {
      const current = queue.shift();
      if (!current || active.has(current)) continue;
      active.add(current);
      for (const target of outgoing.get(current) || []) {
        if (!active.has(target)) queue.push(target);
      }
    }
    return active;
  }

  function calculateHorizontalShifts(active, edges, minGap) {
    const originalX = new Map();
    const shifts = new Map();
    for (const element of active) {
      originalX.set(element, Number(element.x) || 0);
      shifts.set(element, 0);
    }

    const activeEdges = edges
      .filter(edge => active.has(edge.source) && active.has(edge.target))
      .sort((a, b) => elementCenterX(a.source) - elementCenterX(b.source) || elementCenterX(a.target) - elementCenterX(b.target));

    // Forward edges strictly increase X, therefore the graph is acyclic for
    // the purpose of this calculation. A few relaxation passes make the code
    // robust even if several branches converge on the same element.
    const maxPasses = Math.max(1, active.size + 2);
    for (let pass = 0; pass < maxPasses; pass += 1) {
      let changed = false;
      for (const edge of activeEdges) {
        const source = edge.source;
        const target = edge.target;
        const sourceShift = shifts.get(source) || 0;
        const sourceX = (originalX.get(source) || 0) + sourceShift;
        const requiredTargetX = sourceX + (Number(source.width) || 0) + minGap;
        const requiredTargetShift = Math.max(0, requiredTargetX - (originalX.get(target) || 0));
        if (requiredTargetShift > (shifts.get(target) || 0) + 0.01) {
          shifts.set(target, requiredTargetShift);
          changed = true;
        }
      }
      if (!changed) break;
    }

    return { shifts, activeEdges };
  }

  function moveShapesByShift(modeling, shifts) {
    const entries = Array.from(shifts.entries())
      .filter(([, dx]) => Number(dx) > 0.01)
      // Move downstream elements first. Connections are re-laid out after all
      // geometry changes, so this ordering primarily avoids transient overlap.
      .sort((a, b) => elementCenterX(b[0]) - elementCenterX(a[0]));

    let moved = 0;
    const movedElements = new Set();
    for (const [element, deltaX] of entries) {
      if (typeof modeling.moveShape !== 'function') continue;
      modeling.moveShape(element, { x: deltaX, y: 0 }, element.parent || null);
      moved += 1;
      movedElements.add(element);
    }
    return { moved, movedElements };
  }

  function snapshotShapePositions(elementRegistry, scope) {
    const snapshot = new Map();
    for (const element of elementRegistry.filter(e =>
      isMovableFlowShape(e) && isDescendantOf(e, scope)
    )) {
      snapshot.set(element, {
        x: Number(element.x) || 0,
        y: Number(element.y) || 0
      });
    }
    return snapshot;
  }

  function shapeDeltaFromSnapshot(element, snapshot) {
    const before = snapshot.get(element);
    if (!before) return { x: 0, y: 0 };
    return {
      x: (Number(element.x) || 0) - before.x,
      y: (Number(element.y) || 0) - before.y
    };
  }

  function sameDelta(a, b, tolerance = 0.5) {
    return Math.abs((a?.x || 0) - (b?.x || 0)) <= tolerance &&
      Math.abs((a?.y || 0) - (b?.y || 0)) <= tolerance;
  }

  function associationGraphForScope(elementRegistry, scope) {
    const connections = elementRegistry.filter(connection => {
      if (!isAssociationLikeConnection(connection)) return false;
      if (!connection.source || !connection.target) return false;
      return isDescendantOf(connection.source, scope) && isDescendantOf(connection.target, scope);
    });

    const adjacency = new Map();
    for (const connection of connections) {
      for (const [from, to] of [[connection.source, connection.target], [connection.target, connection.source]]) {
        const list = adjacency.get(from) || [];
        list.push({ element: to, connection });
        adjacency.set(from, list);
      }
    }

    return { connections, adjacency };
  }

  function associatedProcessOwners(auxiliary, adjacency, scope) {
    const owners = new Set();
    const visitedAux = new Set();
    const queue = [auxiliary];

    while (queue.length) {
      const current = queue.shift();
      if (!current || visitedAux.has(current)) continue;
      visitedAux.add(current);

      for (const link of adjacency.get(current) || []) {
        const other = link.element;
        if (!other || !isMovableFlowShape(other) || !isDescendantOf(other, scope)) continue;

        if (isAuxiliaryAssociatedShape(other)) {
          if (!visitedAux.has(other)) queue.push(other);
          continue;
        }

        // Pool/Lane are layout containers, not semantic owners of an
        // annotation/data object. Everything else is treated as a process
        // shape whose movement can own the visual block.
        if (!isParticipant(other) && !isLane(other)) owners.add(other);
      }
    }

    return owners;
  }

  function moveAssociatedVisualBlocks(service, scope, positionSnapshot) {
    const { connections, adjacency } = associationGraphForScope(service.elementRegistry, scope);
    if (!connections.length) return { moved: 0, movedElements: new Set(), sharedSkipped: 0, affectedConnections: new Set() };

    const auxiliaries = service.elementRegistry.filter(element =>
      isAuxiliaryAssociatedShape(element) &&
      isMovableFlowShape(element) &&
      isDescendantOf(element, scope)
    );

    let moved = 0;
    let sharedSkipped = 0;
    const movedElements = new Set();
    const affectedConnections = new Set();

    for (const auxiliary of auxiliaries) {
      const owners = Array.from(associatedProcessOwners(auxiliary, adjacency, scope));
      if (!owners.length) continue;

      const ownerDeltas = owners.map(owner => shapeDeltaFromSnapshot(owner, positionSnapshot));
      const desired = ownerDeltas[0];
      const compatible = ownerDeltas.every(delta => sameDelta(delta, desired));

      // A shared artifact tied to process elements that moved differently has
      // no unambiguous owner. Keep it where the analyst placed it and only let
      // its dotted links stretch/re-route.
      if (!compatible) {
        sharedSkipped += 1;
        continue;
      }

      const currentDelta = shapeDeltaFromSnapshot(auxiliary, positionSnapshot);
      const residual = {
        x: (desired?.x || 0) - currentDelta.x,
        y: (desired?.y || 0) - currentDelta.y
      };

      if (Math.abs(residual.x) <= 0.01 && Math.abs(residual.y) <= 0.01) continue;
      if (typeof service.modeling.moveShape !== 'function') continue;

      service.modeling.moveShape(auxiliary, residual, auxiliary.parent || null);
      moved += 1;
      movedElements.add(auxiliary);

      for (const link of adjacency.get(auxiliary) || []) {
        if (link.connection) affectedConnections.add(link.connection);
      }
    }

    return { moved, movedElements, sharedSkipped, affectedConnections };
  }

  function clamp01(value) {
    return Math.max(0, Math.min(1, Number(value) || 0));
  }

  function dockingSideAtPoint(element, point) {
    if (!element || !point || !isMovableFlowShape(element)) return null;

    const x = Number(element.x) || 0;
    const y = Number(element.y) || 0;
    const width = Number(element.width) || 0;
    const height = Number(element.height) || 0;
    const right = x + width;
    const bottom = y + height;
    const px = Number(point.x) || 0;
    const py = Number(point.y) || 0;

    const candidates = [
      { side: 'LEFT', distance: Math.abs(px - x), ratio: height ? clamp01((py - y) / height) : 0.5 },
      { side: 'RIGHT', distance: Math.abs(px - right), ratio: height ? clamp01((py - y) / height) : 0.5 },
      { side: 'TOP', distance: Math.abs(py - y), ratio: width ? clamp01((px - x) / width) : 0.5 },
      { side: 'BOTTOM', distance: Math.abs(py - bottom), ratio: width ? clamp01((px - x) / width) : 0.5 }
    ];

    candidates.sort((a, b) => a.distance - b.distance);
    return { side: candidates[0].side, ratio: candidates[0].ratio };
  }

  function captureConnectionDocking(connection) {
    if (!connection || !isSequenceFlow(connection)) return null;
    const waypoints = Array.isArray(connection.waypoints) ? connection.waypoints : [];
    if (waypoints.length < 2) return null;

    return {
      source: dockingSideAtPoint(connection.source, waypoints[0]),
      target: dockingSideAtPoint(connection.target, waypoints[waypoints.length - 1])
    };
  }

  function canonicalDockRatio(element, docking) {
    const type = String(element?.businessObject?.$type || '');
    // Gateways and events are not rectangular. A point with an arbitrary ratio
    // on their bounding-box edge would not lie on the visible shape. Preserve
    // the SIDE chosen by the analyst, but dock at that side's canonical vertex.
    if (type.includes('Gateway') || type.includes('Event')) return 0.5;
    return clamp01(docking?.ratio ?? 0.5);
  }

  function pointForDockingSide(element, docking, fallbackSide) {
    if (!element || !isMovableFlowShape(element)) return null;
    const side = docking?.side || fallbackSide || 'RIGHT';
    const ratio = canonicalDockRatio(element, docking);
    const x = Number(element.x) || 0;
    const y = Number(element.y) || 0;
    const width = Number(element.width) || 0;
    const height = Number(element.height) || 0;

    if (side === 'LEFT') return { x, y: y + height * ratio };
    if (side === 'RIGHT') return { x: x + width, y: y + height * ratio };
    if (side === 'TOP') return { x: x + width * ratio, y };
    return { x: x + width * ratio, y: y + height };
  }

  function defaultDockingForConnection(connection) {
    const source = connection?.source;
    const target = connection?.target;
    if (!isMovableFlowShape(source) || !isMovableFlowShape(target)) return null;

    const dx = elementCenterX(target) - elementCenterX(source);
    const dy = elementCenterY(target) - elementCenterY(source);
    if (Math.abs(dx) >= Math.abs(dy)) {
      return dx >= 0
        ? { source: { side: 'RIGHT', ratio: 0.5 }, target: { side: 'LEFT', ratio: 0.5 } }
        : { source: { side: 'LEFT', ratio: 0.5 }, target: { side: 'RIGHT', ratio: 0.5 } };
    }
    return dy >= 0
      ? { source: { side: 'BOTTOM', ratio: 0.5 }, target: { side: 'TOP', ratio: 0.5 } }
      : { source: { side: 'TOP', ratio: 0.5 }, target: { side: 'BOTTOM', ratio: 0.5 } };
  }

  function compactOrthogonalWaypoints(points) {
    const compact = [];
    for (const point of points || []) {
      if (!point) continue;
      const current = { x: Number(point.x) || 0, y: Number(point.y) || 0 };
      const previous = compact[compact.length - 1];
      if (previous && Math.abs(previous.x - current.x) < 0.01 && Math.abs(previous.y - current.y) < 0.01) continue;
      compact.push(current);
    }

    // Remove a middle point when three consecutive points are collinear.
    let changed = true;
    while (changed && compact.length > 2) {
      changed = false;
      for (let i = 1; i < compact.length - 1; i += 1) {
        const a = compact[i - 1];
        const b = compact[i];
        const c = compact[i + 1];
        const sameX = Math.abs(a.x - b.x) < 0.01 && Math.abs(b.x - c.x) < 0.01;
        const sameY = Math.abs(a.y - b.y) < 0.01 && Math.abs(b.y - c.y) < 0.01;
        if (sameX || sameY) {
          compact.splice(i, 1);
          changed = true;
          break;
        }
      }
    }
    return compact;
  }

  function buildOrthogonalWaypoints(start, end, sourceDock, targetDock) {
    const sourceSide = sourceDock?.side || 'RIGHT';
    const targetSide = targetDock?.side || 'LEFT';
    const sourceHorizontal = sourceSide === 'LEFT' || sourceSide === 'RIGHT';
    const targetHorizontal = targetSide === 'LEFT' || targetSide === 'RIGHT';
    const points = [ start ];

    if (sourceHorizontal && targetHorizontal) {
      if (Math.abs(start.y - end.y) < 0.5) {
        points.push(end);
      } else {
        const midX = (start.x + end.x) / 2;
        points.push({ x: midX, y: start.y }, { x: midX, y: end.y }, end);
      }
    } else if (!sourceHorizontal && !targetHorizontal) {
      if (Math.abs(start.x - end.x) < 0.5) {
        points.push(end);
      } else {
        const midY = (start.y + end.y) / 2;
        points.push({ x: start.x, y: midY }, { x: end.x, y: midY }, end);
      }
    } else if (!sourceHorizontal && targetHorizontal) {
      // Typical BPMN branch: leave a gateway at TOP/BOTTOM, then approach the
      // next Task/Gateway from LEFT/RIGHT.
      points.push({ x: start.x, y: end.y }, end);
    } else {
      // Typical BPMN merge: leave a Task/Gateway horizontally and enter the
      // merge gateway from TOP/BOTTOM.
      points.push({ x: end.x, y: start.y }, end);
    }

    return compactOrthogonalWaypoints(points);
  }

  function relayoutForwardSequenceFlow(modeling, connection, dockingSnapshot = null) {
    if (!connection || !isSequenceFlow(connection)) return false;
    const source = connection.source;
    const target = connection.target;
    if (!isMovableFlowShape(source) || !isMovableFlowShape(target)) return false;
    if (elementCenterX(target) <= elementCenterX(source) + 0.5) return false;

    const docking = dockingSnapshot || defaultDockingForConnection(connection);
    if (!docking) return false;

    const start = pointForDockingSide(source, docking.source, 'RIGHT');
    const end = pointForDockingSide(target, docking.target, 'LEFT');
    if (!start || !end) return false;
    const waypoints = buildOrthogonalWaypoints(start, end, docking.source, docking.target);

    // Use freshly calculated waypoints instead of asking the generic layouter
    // to choose new docking sides. This preserves the analyst's semantic
    // choice (LEFT/RIGHT/TOP/BOTTOM) while discarding stale intermediate
    // geometry from before resize/move.
    if (typeof modeling.updateWaypoints === 'function') {
      modeling.updateWaypoints(connection, waypoints);
      return true;
    }

    try {
      if (typeof modeling.layoutConnection === 'function') {
        modeling.layoutConnection(connection, {
          connectionStart: start,
          connectionEnd: end,
          waypoints
        });
        return true;
      }
    } catch (_) {}

    return false;
  }

  function ensureParticipantRightPadding(service, participant, minGap) {
    if (!participant || !isParticipant(participant)) return 0;

    const shapes = service.elementRegistry.filter(element =>
      element !== participant &&
      !isLane(element) &&
      isMovableFlowShape(element) &&
      isDescendantOf(element, participant)
    );
    if (!shapes.length) return 0;

    const rightmost = Math.max(...shapes.map(element => elementRight(element)));
    const currentRight = elementRight(participant);
    const requiredRight = rightmost + minGap;
    const extra = requiredRight - currentRight;
    if (!(extra > 0.01)) return 0;

    const newBounds = {
      x: Number(participant.x) || 0,
      y: Number(participant.y) || 0,
      width: (Number(participant.width) || 0) + extra,
      height: Number(participant.height) || 0
    };

    try {
      // bpmn-js lane resizing understands Participant/Lane hierarchies and
      // expands nested lanes together with the pool. balanced=false means
      // "make space" on the east side without redistributing lane heights.
      if (typeof service.modeling.resizeLane === 'function') {
        service.modeling.resizeLane(participant, newBounds, false);
        return extra;
      }
    } catch (_) {}

    if (typeof service.modeling.resizeShape === 'function') {
      service.modeling.resizeShape(participant, newBounds);
      return extra;
    }

    return 0;
  }


  function isExpandedSubProcessElement(element) {
    if (!isSubProcessLike(element)) return false;

    const di = element?.businessObject?.di;
    if (di && typeof di.isExpanded === 'boolean') return di.isExpanded;

    // Fallback for diagrams where isExpanded is not exposed on the DI object:
    // an expanded subprocess has visible diagram children parented to it.
    return Array.isArray(element?.children) && element.children.some(child => child && !child.labelTarget);
  }

  function shiftForwardAfterExpandedSubProcess(service, subprocess, minGap, template) {
    const parent = subprocess?.parent || null;
    if (!parent) {
      return { moved: 0, movedElements: new Set(), affectedConnections: new Set() };
    }

    const edges = forwardSequenceFlowsForParent(service.elementRegistry, parent, template);
    if (!edges.length) {
      return { moved: 0, movedElements: new Set(), affectedConnections: new Set() };
    }

    // The expanded Sub-process itself stays where it is. Its new right edge is
    // simply treated as the new spacing anchor; every element reachable to the
    // right through forward Sequence Flow is shifted only as much as required.
    const active = collectForwardReachable([subprocess], edges);
    if (active.size <= 1) {
      return { moved: 0, movedElements: new Set(), affectedConnections: new Set() };
    }

    const { shifts, activeEdges } = calculateHorizontalShifts(active, edges, minGap);
    shifts.set(subprocess, 0);
    const moveResult = moveShapesByShift(service.modeling, shifts);

    return {
      moved: moveResult.moved,
      movedElements: moveResult.movedElements,
      affectedConnections: new Set(activeEdges)
    };
  }

  function ensureExpandedSubProcessesRightPadding(service, scope, minGap, template) {
    const subprocesses = service.elementRegistry.filter(element =>
      isExpandedSubProcessElement(element) &&
      isDescendantOf(element, scope)
    )
      // Expand inner subprocesses first. Immediately after an inner container
      // grows, move its downstream siblings to the right. Then an outer
      // subprocess sees the FINAL geometry of the whole inner level when its
      // own right edge is calculated.
      .sort((a, b) => elementDepth(b) - elementDepth(a));

    let resized = 0;
    let totalExtra = 0;
    let shifted = 0;
    const resizedElements = new Set();
    const movedElements = new Set();
    const affectedConnections = new Set();

    for (const subprocess of subprocesses) {
      const descendants = service.elementRegistry.filter(element =>
        element !== subprocess &&
        !isLane(element) &&
        isMovableFlowShape(element) &&
        isDescendantOf(element, subprocess)
      );
      if (!descendants.length) continue;

      const rightmost = Math.max(...descendants.map(element => elementRight(element)));
      const currentRight = elementRight(subprocess);
      const requiredRight = rightmost + minGap;
      const extra = requiredRight - currentRight;
      if (!(extra > 0.01)) continue;

      const newBounds = {
        x: Number(subprocess.x) || 0,
        y: Number(subprocess.y) || 0,
        width: (Number(subprocess.width) || 0) + extra,
        height: Number(subprocess.height) || 0
      };

      if (typeof service.modeling.resizeShape !== 'function') continue;
      service.modeling.resizeShape(subprocess, newBounds);
      resized += 1;
      totalExtra += extra;
      resizedElements.add(subprocess);

      // Growing the right edge must not cover the next process element. Move
      // the ENTIRE downstream chain on this level, exactly like the normal
      // Task-spacing phase does. Branches move together and converging paths
      // use the maximum required shift via calculateHorizontalShifts().
      const downstream = shiftForwardAfterExpandedSubProcess(service, subprocess, minGap, template);
      shifted += downstream.moved;
      for (const element of downstream.movedElements) movedElements.add(element);
      for (const connection of downstream.affectedConnections) affectedConnections.add(connection);
    }

    return { resized, totalExtra, resizedElements, shifted, movedElements, affectedConnections };
  }

  function alignTaskSizesCore(service) {
    const participants = service.elementRegistry.filter(e => isParticipant(e));
    const selected = Array.isArray(service.currentSelection) ? service.currentSelection : [];

    let currentPool = null;
    for (const element of selected) {
      currentPool = participantAncestor(element) || (isParticipant(element) ? element : null);
      if (currentPool) break;
    }
    if (!currentPool && participants.length === 1) currentPool = participants[0];

    let templates = currentPool
      ? findTemplateTasks(service.elementRegistry, currentPool)
      : findTemplateTasks(service.elementRegistry);

    if (templates.length > 1) {
      postStatus(currentPool
        ? 'Выровнять размер задач: в текущем пуле найдено несколько задач «ШАБЛОН». Операция не выполнена.'
        : 'Выровнять размер задач: найдено несколько задач «ШАБЛОН». Операция не выполнена.');
      return;
    }

    if (templates.length === 0 && currentPool) {
      templates = findTemplateTasks(service.elementRegistry);
      if (templates.length > 1) {
        postStatus('Выровнять размер задач: найдено несколько задач «ШАБЛОН». Операция не выполнена.');
        return;
      }
    }

    if (templates.length === 0) {
      postStatus('Выровнять размер задач: элемент «ШАБЛОН» не найден.');
      return;
    }

    const template = templates[0];
    const scope = taskScopeForTemplate(template);
    if (!scope) {
      postStatus('Выровнять размер задач: не удалось определить текущий пул или процесс для «ШАБЛОН».');
      return;
    }

    const width = Number(template.width) || 0;
    const height = Number(template.height) || 0;
    if (!(width > 0 && height > 0)) {
      postStatus('Выровнять размер задач: у «ШАБЛОН» не удалось определить размер.');
      return;
    }

    const minGap = Math.max(0, Math.min(500, Number(settings.alignTaskMinGap) || 0));
    const targets = service.elementRegistry.filter(element =>
      isTaskElement(element) && element !== template && isDescendantOf(element, scope)
    );

    // Snapshot every shape position before the operation. Besides driving the
    // normal flow-chain shift, this lets us move Data Objects, Data Stores and
    // Text Annotations together with the process element they are associated
    // with. The snapshot also prevents double-moving children that already
    // travelled with a moved expanded Sub-process.
    const positionSnapshot = snapshotShapePositions(service.elementRegistry, scope);

    // Capture docking SIDES before any resize/move. The generic bpmn-js
    // connection layouter may otherwise re-dock a branch to another side of a
    // Gateway after geometry changes. We preserve LEFT/RIGHT/TOP/BOTTOM, but
    // deliberately do not preserve the old intermediate waypoint route.
    const dockingSnapshots = new Map();
    for (const connection of service.elementRegistry.filter(e => isSequenceFlow(e))) {
      if (!isDescendantOf(connection.source, scope) || !isDescendantOf(connection.target, scope)) continue;
      dockingSnapshots.set(connection, captureConnectionDocking(connection));
    }

    // Phase 1. Resize every Task to the template. Keep the LEFT edge fixed so
    // an enlarged task grows only to the right and never invades the upstream
    // part of the diagram. Preserve the vertical centre when height changes.
    let changed = 0;
    for (const task of targets) {
      const currentWidth = Number(task.width) || 0;
      const currentHeight = Number(task.height) || 0;
      if (Math.abs(currentWidth - width) < 0.01 && Math.abs(currentHeight - height) < 0.01) continue;

      const newX = Number(task.x) || 0;
      const newY = (Number(task.y) || 0) + (currentHeight - height) / 2;
      service.modeling.resizeShape(task, {
        x: newX,
        y: newY,
        width,
        height
      });
      changed += 1;
    }

    // Phase 2. Recalculate horizontal spacing per flow level. Each parent
    // (Participant/Process/expanded Sub-process) is handled separately. This
    // prevents descendants of a moved Sub-process from being moved twice.
    const rootsByParent = new Map();
    for (const task of targets) {
      const parent = task.parent || null;
      if (!parent) continue;
      const list = rootsByParent.get(parent) || [];
      list.push(task);
      rootsByParent.set(parent, list);
    }

    const parents = Array.from(rootsByParent.keys())
      .sort((a, b) => elementDepth(a) - elementDepth(b));

    let shiftedElements = 0;
    const movedElements = new Set();
    const connectionsToRelayout = new Set();

    for (const parent of parents) {
      const edges = forwardSequenceFlowsForParent(service.elementRegistry, parent, template);
      if (!edges.length) continue;

      // Every Task on this level is a spacing anchor. This makes the command
      // idempotent and also repairs a diagram previously processed by an older
      // plugin version: if a gap is already sufficient nothing moves.
      const active = collectForwardReachable(rootsByParent.get(parent), edges);
      if (!active.size) continue;

      const { shifts, activeEdges } = calculateHorizontalShifts(active, edges, minGap);
      const moveResult = moveShapesByShift(service.modeling, shifts);
      shiftedElements += moveResult.moved;
      for (const element of moveResult.movedElements) movedElements.add(element);
      for (const edge of activeEdges) connectionsToRelayout.add(edge);
    }

    // Phase 3. Stabilize expanded Sub-process geometry together with the
    // downstream process chain and associated visual artifacts.
    //
    // Important: an expanded Sub-process grows to the RIGHT. That new right
    // edge may overlap the next element OUTSIDE the Sub-process. Therefore each
    // time a Sub-process grows we use it as a new spacing anchor and shift the
    // whole forward-reachable chain on the same parent level. Associations then
    // follow their process owners. If that reveals another container overflow,
    // the loop performs one more inside-out expansion pass. All operations are
    // still children of the single atomic crsc.alignTaskSizes command.
    const subprocessResizedElements = new Set();
    const subprocessShiftedElements = new Set();
    const associatedMovedElements = new Set();
    let subprocessTotalExtra = 0;
    let associatedSharedSkipped = 0;

    const stabilizePasses = Math.max(3, Math.min(12,
      service.elementRegistry.filter(e => isExpandedSubProcessElement(e) && isDescendantOf(e, scope)).length + 4
    ));

    for (let pass = 0; pass < stabilizePasses; pass += 1) {
      const expanded = ensureExpandedSubProcessesRightPadding(service, scope, minGap, template);
      subprocessTotalExtra += expanded.totalExtra || 0;

      for (const element of expanded.resizedElements) subprocessResizedElements.add(element);
      for (const element of expanded.movedElements) {
        subprocessShiftedElements.add(element);
        movedElements.add(element);
      }
      for (const connection of expanded.affectedConnections) connectionsToRelayout.add(connection);

      const associated = moveAssociatedVisualBlocks(service, scope, positionSnapshot);
      for (const element of associated.movedElements) associatedMovedElements.add(element);
      associatedSharedSkipped = Math.max(associatedSharedSkipped, associated.sharedSkipped || 0);

      if (!expanded.resized && !expanded.shifted && !associated.moved) break;
    }

    const subprocessExpand = {
      resized: subprocessResizedElements.size,
      totalExtra: subprocessTotalExtra,
      resizedElements: subprocessResizedElements,
      shifted: subprocessShiftedElements.size,
      movedElements: subprocessShiftedElements
    };

    const associatedMove = {
      moved: associatedMovedElements.size,
      movedElements: associatedMovedElements,
      sharedSkipped: associatedSharedSkipped
    };

    // Now that all process shapes have their FINAL positions, include every
    // forward Sequence Flow whose endpoint was resized or moved. This covers:
    // - normal Task resize/spacing;
    // - an expanded Sub-process whose right edge grew;
    // - every downstream element shifted because of that growth.
    for (const connection of service.elementRegistry.filter(e => isSequenceFlow(e))) {
      if (!isDescendantOf(connection.source, scope) || !isDescendantOf(connection.target, scope)) continue;
      if (elementCenterX(connection.target) <= elementCenterX(connection.source) + 0.5) continue;
      if (
        targets.includes(connection.source) ||
        targets.includes(connection.target) ||
        movedElements.has(connection.source) ||
        movedElements.has(connection.target) ||
        subprocessResizedElements.has(connection.source) ||
        subprocessResizedElements.has(connection.target)
      ) {
        connectionsToRelayout.add(connection);
      }
    }

    // Phase 4. If the process no longer fits in its pool, extend the pool and
    // its lanes to the right. The same user-configured gap is used as right
    // padding, keeping the result visually consistent. Associated artifacts and
    // expanded Sub-processes have already reached their final width, so they
    // also participate in the rightmost-boundary check.
    const participant = participantAncestor(template);
    const poolExtra = participant
      ? ensureParticipantRightPadding(service, participant, minGap)
      : 0;

    // Phase 5. Rebuild affected forward Sequence Flow routes from FINAL
    // geometry. This removes stale waypoints left by resize/move operations and
    // keeps horizontal chains straight while preserving element Y positions.
    let relaidConnections = 0;
    for (const connection of connectionsToRelayout) {
      if (relayoutForwardSequenceFlow(service.modeling, connection, dockingSnapshots.get(connection))) relaidConnections += 1;
    }

    const scopeName = participant ? 'текущий пул' : 'процесс';
    if (changed || shiftedElements || associatedMove.moved || subprocessExpand.resized || poolExtra || relaidConnections) {
      const parts = [ `изменено задач — ${changed}` ];
      if (shiftedElements) parts.push(`сдвинуто элементов процесса — ${shiftedElements}`);
      if (associatedMove.moved) parts.push(`сдвинуто связанных элементов — ${associatedMove.moved}`);
      if (associatedMove.sharedSkipped) parts.push(`общих связанных элементов оставлено на месте — ${associatedMove.sharedSkipped}`);
      if (subprocessExpand.resized) parts.push(`расширено подпроцессов — ${subprocessExpand.resized}`);
      if (subprocessExpand.shifted) parts.push(`сдвинуто элементов после подпроцессов — ${subprocessExpand.shifted}`);
      if (relaidConnections) parts.push(`перестроено стрелок — ${relaidConnections}`);
      if (poolExtra) parts.push(`пул расширен на ${Math.round(poolExtra)} px`);
      parts.push(`минимальный зазор — ${Math.round(minGap)} px`);
      parts.push(`размер «ШАБЛОН» — ${Math.round(width)}×${Math.round(height)}`);
      parts.push(`область — ${scopeName}`);
      postStatus(`Выровнять размер задач: ${parts.join('; ')}.`);
    } else {
      postStatus('Выровнять размер задач: изменений нет.');
    }
  }

  function alignTaskSizes() {
    const service = getNumberingService();
    if (!service) {
      postStatus('Не найден активный BPMN-редактор.');
      return;
    }

    try {
      return executeAtomicPluginCommand(service, 'crsc.alignTaskSizes', () => alignTaskSizesCore(service));
    } catch (error) {
      console.error('[Camunda Russian Spell Checker] align task sizes error', error);
      postStatus('Не удалось выровнять размер задач.');
    }
  }

  function numberDiagram() {
    const service = getNumberingService();
    if (!service) {
      postStatus('Не найден активный BPMN-редактор. Откройте BPMN-диаграмму.');
      return;
    }

    try {
      return executeAtomicPluginCommand(service, 'crsc.numberDiagram', () => numberDiagramCore(service));
    } catch (error) {
      console.error('[Camunda Russian Spell Checker] atomic numbering error', error);
      postStatus('Не удалось выполнить автонумерацию.');
    }
  }

  function numberDiagramCore(service) {
    /*
     * In a BPMN Collaboration the visible pool is a bpmn:Participant.
     * Its businessObject.processRef points to the actual bpmn:Process, but
     * diagram elements inside the pool are parented to the Participant.
     * The old implementation only searched for visual bpmn:Process roots,
     * so a process shown inside a pool was reported as "not found".
     *
     * Prefer visible Participants when they exist. This also gives us a
     * natural numbering scope per pool. If there are no participants, keep
     * the original process-root behaviour for ordinary BPMN diagrams.
     */
    const participants = service.elementRegistry.filter(e => isParticipant(e));
    const processRoots = service.elementRegistry.filter(e =>
      e && e.businessObject && e.businessObject.$type === 'bpmn:Process'
    );

    const scopes = participants.length
      ? participants
      : processRoots;

    if (!scopes.length) {
      postStatus('Не найден процесс или pool (Participant) для нумерации.');
      return;
    }

    const changes = [];
    try {
      for (const scope of scopes) {
        numberScope(scope, service, '', changes);
      }

      const suffix = participants.length > 1 ? `, пулов — ${participants.length}` : '';
      postStatus(
        changes.length
          ? `Автонумерация: изменено шагов — ${changes.length}${suffix}`
          : 'Автонумерация: изменений нет'
      );
    } catch (error) {
      console.error('[Camunda Russian Spell Checker] numbering error', error);
      postStatus('Не удалось выполнить автонумерацию.');
    }
  }

  function slugifyTerminologyName(name) {
    const translit = String(name || '').trim().toLocaleLowerCase('ru-RU')
      .replace(/ё/g, 'е')
      .replace(/[^a-zа-я0-9]+/giu, '-')
      .replace(/^-+|-+$/gu, '');
    return translit || `terminology-${Date.now()}`;
  }

  function sendTerminologyOperation(payload) {
    try {
      window.open(`camunda-rsc://terminology/${encodeURIComponent(JSON.stringify(payload))}`, '_blank');
    } catch (_) {
      postStatus('Не удалось выполнить операцию с терминологией.');
    }
  }

  function splitTerminologyTerms(value) {
    return String(value || '').split(/[\n,;]+/u).map(x => x.trim()).filter(Boolean);
  }

  function showTerminologyEditorDialog(item) {
    closeTerminologyEditorDialog();
    const isUserCustom = item?.id === 'user-custom';
    const isEdit = !!item && !isUserCustom ? true : !!item;
    const overlay = document.createElement('div');
    overlay.id = 'crsc-terminology-editor-overlay';
    overlay.className = 'crsc-modal-overlay crsc-modal-overlay-front';
    const modal = document.createElement('div');
    modal.className = 'crsc-modal crsc-terminology-modal';

    const header = document.createElement('div');
    header.className = 'crsc-modal-header';
    const title = document.createElement('div');
    title.className = 'crsc-modal-title';
    title.textContent = isUserCustom ? 'Изменить пользовательские исключения' : (isEdit ? `Изменить терминологию «${item.name}»` : 'Добавить терминологию');
    header.appendChild(title);
    const close = document.createElement('button');
    close.type = 'button'; close.className = 'crsc-modal-close'; close.textContent = '×'; close.title = 'Закрыть';
    close.addEventListener('click', closeTerminologyEditorDialog);
    header.appendChild(close);

    const body = document.createElement('div'); body.className = 'crsc-modal-body';

    let name = null;
    let category = null;
    if (!isUserCustom) {
      const nameLabel = document.createElement('label'); nameLabel.textContent = 'Наименование';
      name = document.createElement('input'); name.type = 'text'; name.placeholder = 'Например, 1С:УХ, SAP'; name.value = item?.name || '';
      nameLabel.appendChild(name);

      const categoryLabel = document.createElement('label'); categoryLabel.textContent = 'Категория';
      category = document.createElement('select'); category.className = 'crsc-select';
      ['Справочник', 'Документы', 'Прочее'].forEach(value => { const o=document.createElement('option'); o.value=value; o.textContent=value; category.appendChild(o); });
      category.value = item?.category || 'Прочее';
      categoryLabel.appendChild(category);
      body.append(nameLabel, categoryLabel);
    } else {
      const nameInfo = document.createElement('div');
      nameInfo.className = 'crsc-modal-info';
      nameInfo.textContent = 'User-custom-terms.json — пользовательские слова и термины, которые не следует считать ошибками.';
      body.appendChild(nameInfo);
    }

    const termsLabel = document.createElement('label'); termsLabel.textContent = 'Список терминов';
    const terms = document.createElement('textarea'); terms.rows = 12; terms.placeholder = 'Один термин на строку. Также можно использовать ; или , как разделители.';
    terms.value = item?.terms ? item.terms.join('\n') : '';
    termsLabel.appendChild(terms);
    const hint = document.createElement('div'); hint.className='crsc-modal-info'; hint.textContent='Для длинных названий лучше использовать один термин на строку.';
    body.append(termsLabel, hint);

    const footer = document.createElement('div'); footer.className='crsc-modal-footer';
    const cancel = document.createElement('button'); cancel.type='button'; cancel.className='crsc-secondary'; cancel.textContent='Отмена'; cancel.addEventListener('click', closeTerminologyEditorDialog);
    const save = document.createElement('button'); save.type='button'; save.className='crsc-primary'; save.textContent= isEdit || isUserCustom ? 'Сохранить' : 'Добавить';
    save.addEventListener('click', () => {
      const cleanTerms = splitTerminologyTerms(terms.value);
      if (!cleanTerms.length) { postStatus('Добавьте хотя бы один термин.'); terms.focus(); return; }
      if (isUserCustom) {
        sendTerminologyOperation({ op: 'update-user-custom', terms: cleanTerms });
        return;
      }
      const cleanName = name.value.trim();
      if (!cleanName) { postStatus('Укажите наименование терминологии.'); name.focus(); return; }
      const payload = {
        op: isEdit ? 'update' : 'add',
        id: item?.id || slugifyTerminologyName(cleanName),
        name: cleanName,
        category: category.value,
        terms: cleanTerms
      };
      sendTerminologyOperation(payload);
    });

    footer.append(cancel, save);
    modal.append(header, body, footer); overlay.appendChild(modal); document.body.appendChild(overlay);
    setTimeout(() => (name || terms).focus(), 0);
  }

  function showAddTerminologyDialog() { showTerminologyEditorDialog(null); }

  function closeTerminologyEditorDialog() {
    const overlay = document.querySelector('#crsc-terminology-editor-overlay') || document.querySelector('#crsc-add-terminology-overlay');
    if (overlay) overlay.remove();
  }

  function showDeleteTerminologyDialog(item) {
    closeDeleteTerminologyDialog();
    const overlay = document.createElement('div');
    overlay.id = 'crsc-terminology-delete-overlay';
    overlay.className = 'crsc-modal-overlay crsc-modal-overlay-front';
    const modal = document.createElement('div'); modal.className = 'crsc-modal crsc-delete-modal';
    const header = document.createElement('div'); header.className='crsc-modal-header';
    const title = document.createElement('div'); title.className='crsc-modal-title'; title.textContent='Удалить терминологию?';
    const close = document.createElement('button'); close.type='button'; close.className='crsc-modal-close'; close.textContent='×'; close.addEventListener('click', closeDeleteTerminologyDialog);
    header.append(title, close);
    const body = document.createElement('div'); body.className='crsc-modal-body';
    const text = document.createElement('div'); text.textContent=`Терминология «${item.name}» и её словарь будут удалены. Это действие нельзя отменить.`;
    body.appendChild(text);
    const footer = document.createElement('div'); footer.className='crsc-modal-footer';
    const cancel=document.createElement('button'); cancel.type='button'; cancel.className='crsc-secondary'; cancel.textContent='Отмена'; cancel.addEventListener('click', closeDeleteTerminologyDialog);
    const remove=document.createElement('button'); remove.type='button'; remove.className='crsc-danger'; remove.textContent='Удалить'; remove.addEventListener('click', () => sendTerminologyOperation({ op: 'delete', id: item.id }));
    footer.append(cancel, remove); modal.append(header, body, footer); overlay.appendChild(modal); document.body.appendChild(overlay);
  }

  function closeDeleteTerminologyDialog() { const overlay=document.querySelector('#crsc-terminology-delete-overlay'); if (overlay) overlay.remove(); }

  function closeAddTerminologyDialog() { closeTerminologyEditorDialog(); }

  function applyTerminologyResult(event) {
    const detail = event?.detail || {};
    closeTerminologyEditorDialog();
    closeDeleteTerminologyDialog();
    if (!detail.ok) { postStatus(detail.message || 'Операция с терминологией не выполнена.'); return; }
    terminologyIndexLoaded = false;
    userCustomLoaded = false;
    erp26Loaded = false;
    const messages = {
      add: `Терминология «${detail.name || ''}» добавлена`,
      update: `Терминология «${detail.name || ''}» изменена`,
      delete: `Терминология «${detail.name || ''}» удалена`,
      'update-user-custom': 'Пользовательские исключения сохранены'
    };
    postStatus(messages[detail.op] || 'Изменения сохранены');
    setTimeout(() => createSettingsDialog(), 80);
  }

  function closeSettingsDialog() {
    const overlay = document.querySelector('#crsc-settings-overlay');
    if (overlay) overlay.remove();
  }

  function createSettingsDialog() {
    closeSettingsDialog();

    const overlay = document.createElement('div');
    overlay.id = 'crsc-settings-overlay';
    overlay.className = 'crsc-modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'crsc-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    const header = document.createElement('div');
    header.className = 'crsc-modal-header';
    header.innerHTML = '<div class="crsc-modal-title">Russian Spell Checker — Настройки</div>';
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'crsc-modal-close';
    close.textContent = '×';
    close.title = 'Закрыть';
    close.addEventListener('click', closeSettingsDialog);
    header.appendChild(close);

    const body = document.createElement('div');
    body.className = 'crsc-modal-body';


    const terminologyTitle = document.createElement('div');
    terminologyTitle.className = 'crsc-section-title';
    terminologyTitle.textContent = 'Терминология';

    const terminologyList = document.createElement('div');
    terminologyList.className = 'crsc-terminology-list';
    const terminologyChecks = new Map();

    const builtIn = [
      { id: 'erp26', name: '1С:ERP 2.6', description: 'Документы и справочники', builtIn: true },
      { id: 'user-custom', name: 'User-custom-terms', description: 'Пользовательские исключения', builtIn: true }
    ];
    const dynamic = terminologyIndex.filter(x => x.id !== 'erp26').map(x => ({
      id: x.id, name: x.name, description: x.category || 'Прочее', builtIn: !!x.builtIn, category: x.category
    }));
    const items = [...builtIn, ...dynamic.filter(x => !builtIn.some(b => b.id === x.id))];

    items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'crsc-terminology-row';
      const left = document.createElement('div'); left.className = 'crsc-terminology-main';
      const cb = document.createElement('input'); cb.type = 'checkbox';
      cb.checked = item.id === 'user-custom' ? true : settings.enabledTerminologies?.[item.id] !== false;
      if (item.id === 'user-custom') cb.disabled = true;
      terminologyChecks.set(item.id, cb);
      const textWrap = document.createElement('span');
      const strong = document.createElement('strong'); strong.textContent = item.name;
      const desc = document.createElement('small'); desc.textContent = item.description ? ` — ${item.description}` : '';
      textWrap.append(strong, desc); left.append(cb, textWrap);
      row.appendChild(left);

      const actions = document.createElement('div'); actions.className = 'crsc-terminology-actions';
      if (item.id === 'user-custom') {
        const edit = document.createElement('button'); edit.type='button'; edit.className='crsc-icon-button'; edit.textContent='✎'; edit.title='Изменить пользовательские исключения';
        edit.addEventListener('click', async () => { await loadUserCustomTerms(); showTerminologyEditorDialog({ id:'user-custom', name:'User-custom-terms', terms:[...userCustomTerms] }); });
        actions.appendChild(edit);
      } else if (!item.builtIn) {
        const edit = document.createElement('button'); edit.type='button'; edit.className='crsc-icon-button'; edit.textContent='✎'; edit.title='Изменить терминологию';
        edit.addEventListener('click', async () => {
          await loadTerminologyIndex();
          await loadAdditionalTerminologies();
          const entry = terminologyTerms.get(item.id) || terminologyIndex.find(x => x.id === item.id);
          showTerminologyEditorDialog({ ...item, ...(entry || {}) });
        });
        const del = document.createElement('button'); del.type='button'; del.className='crsc-icon-button crsc-icon-danger'; del.textContent='×'; del.title='Удалить терминологию';
        del.addEventListener('click', () => showDeleteTerminologyDialog(item));
        actions.append(edit, del);
      }
      row.appendChild(actions);
      terminologyList.appendChild(row);
    });

    const terminologyInfo = document.createElement('div');
    terminologyInfo.className = 'crsc-modal-info';
    terminologyInfo.textContent = 'Системные словари организованы по папкам dictionary/<система>/. Пользовательские исключения хранятся отдельно в User-custom-terms.json. Системные словари нельзя изменять или удалять.';

    const addTerminologyButton = document.createElement('button');
    addTerminologyButton.type = 'button';
    addTerminologyButton.className = 'crsc-secondary crsc-add-terminology';
    addTerminologyButton.textContent = 'Добавить терминологию';
    addTerminologyButton.addEventListener('click', showAddTerminologyDialog);

    const sameNumberLabel = document.createElement('label');
    sameNumberLabel.className = 'crsc-checkbox-row';
    const sameNumber = document.createElement('input');
    sameNumber.type = 'checkbox';
    sameNumber.checked = settings.oneNumberForIdenticalActions === true;
    sameNumberLabel.append(sameNumber, document.createTextNode(' Один номер шага для одинаковых действий'));

    const sameNumberInfo = document.createElement('div');
    sameNumberInfo.className = 'crsc-modal-info';
    sameNumberInfo.textContent = 'При нумерации действия с одинаковым названием на одном уровне получают один и тот же номер. Например: «Открыть документ», «Открыть документ», «Проверить документ» → 01, 01, 02.';

    const alignGapLabel = document.createElement('label');
    alignGapLabel.textContent = 'Минимальный зазор после выравнивания задач, px';
    const alignGap = document.createElement('input');
    alignGap.type = 'number';
    alignGap.min = '0';
    alignGap.max = '500';
    alignGap.step = '5';
    alignGap.value = String(Number.isFinite(Number(settings.alignTaskMinGap)) ? settings.alignTaskMinGap : DEFAULTS.alignTaskMinGap);
    alignGapLabel.appendChild(alignGap);

    const alignGapInfo = document.createElement('div');
    alignGapInfo.className = 'crsc-modal-info';
    alignGapInfo.textContent = 'Используется только командой «Выровнять размер задач». Если между связанными элементами справа не хватает указанного расстояния, вся последующая цепочка сдвигается вправо без изменения Y. Если внутренние элементы перестают помещаться, expanded Sub-process расширяется вправо; после такого расширения вся последующая цепочка за Sub-process также сдвигается вправо, чтобы контейнер её не перекрыл. При необходимости Pool/Lane расширяются вправо с тем же запасом.';

    const quotesLabel = document.createElement('label');
    quotesLabel.className = 'crsc-checkbox-row';
    const quotes = document.createElement('input');
    quotes.type = 'checkbox';
    quotes.checked = settings.autoQuotes !== false;
    quotesLabel.append(quotes, document.createTextNode(' Автоматически заменять кавычки на «ёлочки»'));

    const spacesLabel = document.createElement('label');
    spacesLabel.className = 'crsc-checkbox-row';
    const spaces = document.createElement('input');
    spaces.type = 'checkbox';
    spaces.checked = settings.autoSpaces !== false;
    spacesLabel.append(spaces, document.createTextNode(' Автоматически убирать лишние пробелы'));

    const technicalLabel = document.createElement('label');
    technicalLabel.className = 'crsc-checkbox-row';
    const technical = document.createElement('input');
    technical.type = 'checkbox';
    technical.checked = !!settings.ignoreTechnical;
    technicalLabel.append(technical, document.createTextNode(' Игнорировать технические поля Properties Panel'));

    const ltTitle = document.createElement('div');
    ltTitle.className = 'crsc-section-title';
    ltTitle.textContent = 'LanguageTool';

    const ltEnableLabel = document.createElement('label');
    ltEnableLabel.className = 'crsc-checkbox-row';
    const ltEnable = document.createElement('input');
    ltEnable.type = 'checkbox';
    ltEnable.checked = settings.useLanguageTool === true;
    ltEnableLabel.append(ltEnable, document.createTextNode(' Использовать LanguageTool'));

    const ltHelp = document.createElement('div');
    ltHelp.className = 'crsc-modal-info';
    ltHelp.textContent = 'При отключённом LanguageTool плагин работает только на локальных правилах, терминологиях и BPMN-проверках. По умолчанию отключён.';

    const ltSourceLabel = document.createElement('label');
    ltSourceLabel.textContent = 'Источник проверки';
    const ltSource = document.createElement('select');
    ltSource.className = 'crsc-select';
    const localOpt = document.createElement('option'); localOpt.value = 'local'; localOpt.textContent = 'Локальный сервер';
    const externalOpt = document.createElement('option'); externalOpt.value = 'external'; externalOpt.textContent = 'Внешний сервер';
    ltSource.append(localOpt, externalOpt);
    ltSource.value = settings.languageToolSource === 'local' ? 'local' : 'external';
    ltSourceLabel.appendChild(ltSource);

    const localEndpoint = document.createElement('input');
    localEndpoint.type = 'text';
    localEndpoint.value = settings.localEndpoint || DEFAULTS.localEndpoint;
    localEndpoint.placeholder = DEFAULTS.localEndpoint;

    const externalEndpoint = document.createElement('input');
    externalEndpoint.type = 'text';
    externalEndpoint.value = settings.externalEndpoint || settings.endpoint || DEFAULTS.externalEndpoint;
    externalEndpoint.placeholder = DEFAULTS.externalEndpoint;

    const endpointLabel = document.createElement('label');
    endpointLabel.appendChild(document.createTextNode('Адрес сервера'));
    const endpointRow = document.createElement('div');
    endpointRow.className = 'crsc-endpoint-row';
    const endpointInputWrap = document.createElement('div');
    endpointInputWrap.className = 'crsc-endpoint-input-wrap';
    endpointInputWrap.appendChild(localEndpoint);
    endpointInputWrap.appendChild(externalEndpoint);
    const indicator = document.createElement('span');
    indicator.className = 'crsc-server-indicator crsc-server-unknown';
    indicator.title = 'Состояние сервера не проверено';
    endpointRow.append(endpointInputWrap, indicator);
    endpointLabel.appendChild(endpointRow);

    const testButton = document.createElement('button');
    testButton.type = 'button';
    testButton.className = 'crsc-secondary crsc-test-server';
    testButton.textContent = 'Проверить соединение';

    const updateLtVisibility = () => {
      const enabled = ltEnable.checked;
      const source = ltSource.value;
      ltSourceLabel.style.display = enabled ? '' : 'none';
      endpointLabel.style.display = enabled ? '' : 'none';
      testButton.style.display = enabled ? '' : 'none';
      langLabel.style.display = enabled ? '' : 'none';
      delayLabel.style.display = enabled ? '' : 'none';
      localEndpoint.style.display = enabled && source === 'local' ? '' : 'none';
      externalEndpoint.style.display = enabled && source === 'external' ? '' : 'none';
      indicator.className = `crsc-server-indicator crsc-server-unknown${enabled ? '' : ' crsc-server-disabled'}`;
      indicator.title = enabled ? 'Состояние сервера не проверено' : 'LanguageTool отключён';
    };
    const checkServer = async () => {
      if (!ltEnable.checked) return;
      indicator.className = 'crsc-server-indicator crsc-server-checking';
      indicator.title = 'Проверка доступности сервера…';
      const url = (ltSource.value === 'local' ? localEndpoint.value : externalEndpoint.value).trim();
      try {
        const params = new URLSearchParams();
        params.set('text', 'Проверка');
        params.set('language', lang.value.trim() || DEFAULTS.language);
        params.set('enabledOnly', 'false');
        const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        await response.json();
        indicator.className = 'crsc-server-indicator crsc-server-ok';
        indicator.title = 'Сервер доступен';
      } catch (_) {
        indicator.className = 'crsc-server-indicator crsc-server-error';
        indicator.title = 'Сервер недоступен';
      }
    };
    ltEnable.addEventListener('change', updateLtVisibility);
    ltSource.addEventListener('change', () => { updateLtVisibility(); checkServer(); });
    testButton.addEventListener('click', checkServer);

    const langLabel = document.createElement('label');
    langLabel.textContent = 'Язык проверки';
    const lang = document.createElement('input');
    lang.type = 'text';
    lang.value = settings.language || DEFAULTS.language;
    langLabel.appendChild(lang);

    const delayLabel = document.createElement('label');
    delayLabel.textContent = 'Задержка после ввода, мс';
    const delay = document.createElement('input');
    delay.type = 'number';
    delay.min = '250';
    delay.step = '50';
    delay.value = String(settings.delay || DEFAULTS.delay);
    delayLabel.appendChild(delay);

    const info = document.createElement('div');
    info.className = 'crsc-modal-info';
    info.textContent = 'Словари подключаются из отдельных папок dictionary/<система>/. Базовая терминология 1С:ERP 2.6 основана на предоставленных вами выгрузках.';

    const credits = document.createElement('div');
    credits.className = 'crsc-credits';
    credits.innerHTML = 'Версия <a class="crsc-version-link" href="camunda-rsc://readme" target="_blank" rel="noopener" title="Открыть README.md"><strong>0.6.28</strong></a> &nbsp;·&nbsp; Идея: <a href="internal:username_regular/PVP_IT@210607234">PVP_IT</a> &nbsp;·&nbsp; Реализация: ChatGPT';

    body.append(terminologyTitle, terminologyList, terminologyInfo, addTerminologyButton,
      sameNumberLabel, sameNumberInfo, alignGapLabel, alignGapInfo, quotesLabel, spacesLabel, technicalLabel,
      ltTitle, ltEnableLabel, ltHelp, ltSourceLabel, endpointLabel, testButton,
      langLabel, delayLabel, info, credits);

    const footer = document.createElement('div');
    footer.className = 'crsc-modal-footer';

    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'crsc-secondary';
    cancel.textContent = 'Отмена';
    cancel.addEventListener('click', closeSettingsDialog);

    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'crsc-primary';
    save.textContent = 'Сохранить';
    save.addEventListener('click', () => {
      settings.enabledTerminologies = Object.assign({}, settings.enabledTerminologies || {});
      terminologyChecks.forEach((checkbox, id) => { if (id !== 'user-custom') settings.enabledTerminologies[id] = checkbox.checked; });
      settings.useErp26Terminology = settings.enabledTerminologies.erp26;
      settings.checkErp26Documents = true;
      settings.checkErp26Catalogs = true;
      settings.oneNumberForIdenticalActions = sameNumber.checked;
      settings.alignTaskMinGap = Math.max(0, Math.min(500, Number(alignGap.value) || 0));
      settings.autoQuotes = quotes.checked;
      settings.autoSpaces = spaces.checked;
      settings.ignoreTechnical = technical.checked;
      settings.useLanguageTool = ltEnable.checked;
      settings.languageToolSource = ltSource.value === 'local' ? 'local' : 'external';
      settings.localEndpoint = localEndpoint.value.trim() || DEFAULTS.localEndpoint;
      settings.externalEndpoint = externalEndpoint.value.trim() || DEFAULTS.externalEndpoint;
      settings.endpoint = settings.languageToolSource === 'local' ? settings.localEndpoint : settings.externalEndpoint;
      settings.language = lang.value.trim() || DEFAULTS.language;
      settings.delay = Math.max(250, Number(delay.value) || DEFAULTS.delay);
      saveSettings();
      closeSettingsDialog();
      postStatus('Настройки сохранены');
      scanFields();
      checkAll();
    });

    footer.append(cancel, save);
    modal.append(header, body, footer);
    overlay.appendChild(modal);
    overlay.addEventListener('mousedown', e => {
      if (e.target === overlay) closeSettingsDialog();
    });
    overlay.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeSettingsDialog();
    });
    document.body.appendChild(overlay);
    updateLtVisibility();
    if (ltEnable.checked) setTimeout(() => checkServer(), 0);
    setTimeout(() => ltEnable.focus(), 0);
    return overlay;
  }

  async function showSettings() {
    try { await loadTerminologyIndex(); } catch (_) {}
    createSettingsDialog();
  }

  function showHelp() {
    alert(
      'Camunda Russian Spell Checker v0.6.28\n\n' +
      'Проверяет текст в Properties Panel и при прямом редактировании подписи на canvas.\nЛокальные рекомендации управляются через подключённые терминологии и corrections.json.\n' +
      'Ошибки помечаются красной рамкой. По клику/правому клику показываются варианты замены.\n\n' +
      'LanguageTool является дополнительным движком и по умолчанию отключён. При включении можно выбрать локальный или внешний сервер.'
    );
  }

  function handleMessage(event) {
    if (!event.data || event.data.source !== SOURCE) return;
    switch (event.data.action) {
      case 'toggle': toggle(); break;
      case 'check-selected': checkSelected(); break;
      case 'check-all': checkAll(); break;
      case 'number-steps': numberDiagram(); break;
      case 'align-task-sizes': alignTaskSizes(); break;
      case 'settings': showSettings(); break;
      case 'help': showHelp(); break;
    }
  }

  async function start() {
    window.addEventListener('crsc-terminology-result', applyTerminologyResult);
    ensureStatus();
    registerNumberingModule();
    try { await loadCorrections(); await loadErp26Dictionary(); } catch (_) {} ensureToolbar(); scanFields();
    observer = new MutationObserver(() => scanFields());
    observer.observe(document.body, { childList: true, subtree: true });

    window.addEventListener('message', handleMessage);
    document.addEventListener('scroll', () => {
      if (popup?.classList.contains('crsc-visible') && popupTarget) positionPopup(popupTarget);
    }, true);
    window.addEventListener('resize', () => {
      if (popup?.classList.contains('crsc-visible') && popupTarget) positionPopup(popupTarget);
      positionStatus();
    });
    document.addEventListener('keydown', e => {
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'l') {
        e.preventDefault(); toggle();
      }
    });
    document.documentElement.classList.toggle('crsc-disabled', !settings.enabled);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
