  // ---- BPMN auto numbering -------------------------------------------------
  // Register a lightweight bpmn-js module without requiring a bundled helper.
  // Camunda Modeler plugin helpers use the same window.plugins registration shape.
  let numberingRegistrationDone = false;

  // Group complex plugin operations into a single diagram-js CommandStack
  // logical unit. Commands executed from preExecute inherit the outer command
  // id, so one Ctrl+Z / Ctrl+Shift+Z reverts / reapplies the whole operation.
  function registerAtomicPluginCommands(commandStack) {
    if (!commandStack || commandStack.__crscAtomicCommandsRegistered) return;

    const atomicHandler = {
      preExecute(context) {
        if (context && typeof context.run === 'function') {
          context.result = context.run();
        }
      },
      execute() { return []; },
      revert() { return []; }
    };

    try {
      commandStack.register('crsc.numberDiagram', atomicHandler);
      commandStack.register('crsc.alignTaskSizes', atomicHandler);
      commandStack.__crscAtomicCommandsRegistered = true;
    } catch (error) {
      // Registration may already exist on this editor instance after a plugin
      // reload. Keep the service usable and fall back to normal execution.
      console.warn('[Camunda Russian Spell Checker] atomic command registration failed', error);
    }
  }

  function executeAtomicPluginCommand(service, command, run) {
    const commandStack = service && service.commandStack;
    if (!commandStack || typeof commandStack.execute !== 'function' || !commandStack.__crscAtomicCommandsRegistered) {
      return run();
    }

    const context = { run, result: undefined };
    commandStack.execute(command, context);
    return context.result;
  }

  function registerNumberingModule() {
    if (numberingRegistrationDone) return;
    numberingRegistrationDone = true;

    try {
      window.plugins = window.plugins || [];
      window.plugins.push({
        plugin: {
          __init__: [ 'crscNumberingService' ],
          crscNumberingService: [ 'type', function(eventBus, elementRegistry, modeling, canvas, commandStack) {
            registerAtomicPluginCommands(commandStack);

            const service = {
              elementRegistry,
              modeling,
              canvas,
              commandStack,
              numberDiagram,
              currentSelection: []
            };

            window.__crscNumberingServices = window.__crscNumberingServices || [];
            window.__crscNumberingServices.push(service);

            function isVisible() {
              const container = canvas && canvas.getContainer && canvas.getContainer();
              if (!container) return false;
              const rect = container.getBoundingClientRect();
              return rect.width > 0 && rect.height > 0 && getComputedStyle(container).display !== 'none';
            }

            service.isVisible = isVisible;
            if (eventBus) {
              eventBus.on('selection.changed', function(event) {
                service.currentSelection = Array.isArray(event?.newSelection) ? event.newSelection.slice() : [];
              });
            }

            function cleanup() {
              const list = window.__crscNumberingServices || [];
              const i = list.indexOf(service);
              if (i >= 0) list.splice(i, 1);
            }

            if (eventBus) eventBus.on('diagram.destroy', cleanup);
          } ]
        },
        type: 'bpmn.modeler.additionalModules'
      });
    } catch (_) {}
  }

  function getNumberingService() {
    const list = window.__crscNumberingServices || [];
    const visible = list.filter(x => x && typeof x.isVisible === 'function' && x.isVisible());
    return visible[visible.length - 1] || list[list.length - 1] || null;
  }

  function isNumberedStep(element) {
    const bo = element && element.businessObject;
    if (!bo || !bo.$type) return false;

    // The sizing helper uses a special Task named `ШАБЛОН` as the reference
    // element. It must never participate in automatic step numbering, even
    // if it already has a generated number from an older plugin version.
    const rawName = typeof bo.name === 'string' ? bo.name : '';
    const normalizedName = rawName
      .replace(/^[\s\d. :]+/u, '')
      .replace(/[ \t\u00A0]+/gu, ' ')
      .trim()
      .toLocaleUpperCase('ru-RU');
    if (normalizedName === 'ШАБЛОН') return false;

    const type = bo.$type;
    return type === 'bpmn:Task' ||
      type === 'bpmn:UserTask' ||
      type === 'bpmn:ServiceTask' ||
      type === 'bpmn:SendTask' ||
      type === 'bpmn:ReceiveTask' ||
      type === 'bpmn:ManualTask' ||
      type === 'bpmn:BusinessRuleTask' ||
      type === 'bpmn:ScriptTask' ||
      type === 'bpmn:CallActivity' ||
      type === 'bpmn:SubProcess' ||
      type === 'bpmn:Transaction' ||
      type === 'bpmn:AdHocSubProcess';
  }

  function hasLabel(element) {
    const name = element?.businessObject?.name;
    return typeof name === 'string' && name.trim().length > 0;
  }

  function parseNumberingPrefix(name) {
    const text = String(name || '').trim();

    // Generated step + code of an EXTERNAL (collapsed) process, e.g.
    // `08: 01.05.07 Автоматическое создание перемещения`.
    // After our colon the external code is unambiguous, therefore two or more
    // numeric parts are accepted there.
    const generatedExternal = text.match(/^(\d+(?:\.\d+)*)\s*:\s*(\d+(?:\.\d+){1,})\s+(.+)$/u);
    if (generatedExternal) {
      return {
        generatedNumber: generatedExternal[1],
        externalProcessCode: generatedExternal[2],
        label: (generatedExternal[3] || '').trim(),
        kind: 'generated-external'
      };
    }

    // External process code before the plugin has numbered a collapsed
    // Sub-process. For a bare prefix we intentionally require at least three
    // numeric parts to avoid confusing old generated `08.01.` step prefixes
    // from pre-v0.6.26 diagrams with an external process code.
    const externalOnly = text.match(/^(\d+(?:\.\d+){2,})\s+(.+)$/u);
    if (externalOnly) {
      return {
        generatedNumber: null,
        externalProcessCode: externalOnly[1],
        label: (externalOnly[2] || '').trim(),
        kind: 'external'
      };
    }

    // Current generated step number: `08: ...` or `08.01: ...`.
    const generatedColon = text.match(/^(\d+(?:\.\d+)*)\s*:\s*(.*)$/u);
    if (generatedColon) {
      return {
        generatedNumber: generatedColon[1],
        externalProcessCode: null,
        label: (generatedColon[2] || '').trim(),
        kind: 'generated'
      };
    }

    // Legacy generated number from versions before v0.6.26.
    const generatedLegacyDot = text.match(/^(\d+(?:\.\d+)*)\.\s*(.*)$/u);
    if (generatedLegacyDot) {
      return {
        generatedNumber: generatedLegacyDot[1],
        externalProcessCode: null,
        label: (generatedLegacyDot[2] || '').trim(),
        kind: 'legacy-generated'
      };
    }

    return null;
  }

  function stripStepPrefix(name) {
    let text = String(name || '').trim();

    // Remove one or more generated `NN:` prefixes. This is intentionally
    // repeated so even names produced by older buggy versions are recovered
    // instead of accumulating prefixes on every subsequent numbering run.
    let previous;
    do {
      previous = text;
      text = text.replace(/^\s*\d+(?:\.\d+)*\s*:\s*/u, '').trim();
    } while (text !== previous);

    // Remove a legacy generated dotted step prefix, such as `02.01.` or
    // `01.05.07.01.`. Current versions generate `NN:` / `NN.NN:` instead, but
    // old prefixes are still recognized so existing diagrams are migrated on
    // the next numbering run. External process codes are handled separately
    // and are preserved only for collapsed Sub-process elements.
    return text.replace(/^\s*\d+(?:\.\d+)*\.\s+/u, '').trim();
  }

  function padStep(n) {
    return String(n).padStart(2, '0');
  }


  function stepLabel(prefix, n, original, preserveExternalProcessCode = false) {
    const originalText = String(original || '').trim();
    let clean = stripStepPrefix(originalText);
    let externalProcessCode = null;

    if (preserveExternalProcessCode) {
      // A COLLAPSED Sub-process may carry the code of an external process.
      // Preserve that external code, but never use it as a numbering prefix.
      const parsed = parseNumberingPrefix(originalText);
      if (parsed?.externalProcessCode) {
        externalProcessCode = parsed.externalProcessCode;
        clean = parsed.label || clean;
      }
    }

    if (!clean) return null;
    const number = prefix ? `${prefix}.${padStep(n)}` : padStep(n);
    if (preserveExternalProcessCode && externalProcessCode) {
      return `${number}: ${externalProcessCode} ${clean}`;
    }
    return `${number}: ${clean}`;
  }

  function stripLegacyExpandedSubProcessCode(name) {
    const parsed = parseNumberingPrefix(name);
    if (parsed?.externalProcessCode) return parsed.label || '';
    const clean = stripStepPrefix(name);
    // v0.6.28 and earlier allowed an expanded Sub-process to retain a
    // three-part "methodological" code. Under the current rule expanded
    // Sub-processes belong to this diagram, so migrate that legacy label by
    // removing the old code during the next numbering run.
    return clean.replace(/^\d+(?:\.\d+){2,}\s+/u, '').trim();
  }

  function isFlowNode(element) {
    return !!(element && element.businessObject && typeof element.businessObject.$type === 'string' && element.businessObject.$type.startsWith('bpmn:'));
  }

  function directChildren(elementRegistry, container) {
    const all = elementRegistry.filter(e => e && e.parent === container);
    return all.filter(isFlowNode);
  }

  function sequenceFlowTargets(node) {
    const outgoing = node?.outgoing || node?.businessObject?.outgoing || [];
    return outgoing
      .map(flow => flow && (flow.target || flow.businessObject?.target))
      .filter(Boolean);
  }


  // Build a scope-local graph between numbered activities, walking through
  // gateways/events/other non-numbered nodes. This preserves the BPMN flow
  // order instead of relying on the element's X/Y position.
  function buildStepGraph(nodes) {
    const nodeSet = new Set(nodes);
    const numbered = nodes.filter(isNumberedStep);
    const numberedSet = new Set(numbered);
    const next = new Map(numbered.map(n => [n, new Set()]));
    const prevCount = new Map(numbered.map(n => [n, 0]));

    function walk(startStep, current, visited) {
      if (!current || visited.has(current.id)) return;
      visited.add(current.id);
      if (numberedSet.has(current)) {
        if (current !== startStep && !next.get(startStep).has(current)) {
          next.get(startStep).add(current);
          prevCount.set(current, (prevCount.get(current) || 0) + 1);
        }
        return;
      }
      for (const target of sequenceFlowTargets(current)) {
        if (nodeSet.has(target)) walk(startStep, target, visited);
      }
    }

    for (const step of numbered) {
      for (const target of sequenceFlowTargets(step)) walk(step, target, new Set());
    }

    return { numbered, next, prevCount };
  }

  function fallbackSort(nodes) {
    return nodes.slice().sort((a, b) => {
      const ay = Number(a.y) || 0;
      const by = Number(b.y) || 0;
      if (Math.abs(ay - by) > 10) return ay - by;
      const ax = Number(a.x) || 0;
      const bx = Number(b.x) || 0;
      return ax - bx;
    });
  }

  function orderedSteps(nodes) {
    const { numbered, next, prevCount } = buildStepGraph(nodes);
    if (!numbered.length) return [];

    const rank = new Map();
    const queue = numbered.filter(n => (prevCount.get(n) || 0) === 0);
    const starts = queue.length ? queue : fallbackSort(numbered).slice(0, 1);
    const working = starts.slice();
    const used = new Set();

    while (working.length) {
      const node = working.shift();
      if (used.has(node)) continue;
      used.add(node);
      rank.set(node, rank.size);
      const successors = Array.from(next.get(node) || []).sort((a, b) => {
        const ax = Number(a.x) || 0;
        const bx = Number(b.x) || 0;
        if (ax !== bx) return ax - bx;
        return (Number(a.y) || 0) - (Number(b.y) || 0);
      });
      for (const successor of successors) {
        if (!used.has(successor)) working.push(successor);
      }
    }

    // Add disconnected branches/components deterministically.
    for (const node of fallbackSort(numbered)) {
      if (!used.has(node)) {
        rank.set(node, rank.size);
        used.add(node);
      }
    }

    return numbered.slice().sort((a, b) => rank.get(a) - rank.get(b));
  }



  function isSubProcessLike(element) {
    const type = element?.businessObject?.$type;
    return type === 'bpmn:SubProcess' || type === 'bpmn:Transaction' || type === 'bpmn:AdHocSubProcess';
  }


  function isCollapsedSubProcessElement(element) {
    return isSubProcessLike(element) && !isExpandedSubProcessElement(element);
  }

  function numberScope(container, service, prefix, changes) {
    const children = directChildren(service.elementRegistry, container);
    const ordered = orderedSteps(children).filter(hasLabel);
    const generatedNumbers = new Map();

    // v0.6.29+: every visible step has its own number. Identical labels do not
    // share numbering because each BPMN element is an independent process step.
    ordered.forEach((element, index) => {
      generatedNumbers.set(element.id, index + 1);
    });

    for (const element of ordered) {
      const stepNo = generatedNumbers.get(element.id);
      const preserveExternalProcessCode = isCollapsedSubProcessElement(element);
      const sourceName = isExpandedSubProcessElement(element)
        ? stripLegacyExpandedSubProcessCode(element.businessObject.name)
        : element.businessObject.name;
      const newName = stepLabel(
        prefix,
        stepNo,
        sourceName,
        preserveExternalProcessCode
      );
      if (newName && newName !== element.businessObject.name) {
        const oldName = element.businessObject.name;
        service.modeling.updateLabel(element, newName);
        changes.push({ element, oldName, newName });
      }
    }

    // Only EXPANDED Sub-processes are scopes drawn in the current diagram and
    // therefore receive recursively generated child numbers. A collapsed
    // Sub-process represents an external process/file: its external code may be
    // preserved in the label, but the plugin never numbers its hidden content.
    for (const element of ordered) {
      if (!isExpandedSubProcessElement(element)) continue;
      const stepNo = generatedNumbers.get(element.id);
      const generatedStepNumber = prefix ? `${prefix}.${padStep(stepNo)}` : padStep(stepNo);
      numberScope(element, service, generatedStepNumber, changes);
    }
  }

  function isParticipant(element) {
    return element?.businessObject?.$type === 'bpmn:Participant';
  }

  function isTaskElement(element) {
    const type = element?.businessObject?.$type;
    return type === 'bpmn:Task' ||
      type === 'bpmn:UserTask' ||
      type === 'bpmn:ServiceTask' ||
      type === 'bpmn:SendTask' ||
      type === 'bpmn:ReceiveTask' ||
      type === 'bpmn:ManualTask' ||
      type === 'bpmn:BusinessRuleTask' ||
      type === 'bpmn:ScriptTask';
  }

  function participantAncestor(element) {
    let current = element;
    while (current) {
      if (isParticipant(current)) return current;
      current = current.parent;
    }
    return null;
  }

  function processAncestor(element) {
    let current = element;
    let process = null;
    while (current) {
      if (current?.businessObject?.$type === 'bpmn:Process') process = current;
      current = current.parent;
    }
    return process;
  }

  function isDescendantOf(element, ancestor) {
    let current = element;
    while (current) {
      if (current === ancestor) return true;
      current = current.parent;
    }
    return false;
  }

  function normalizedExactTaskName(element) {
    return String(element?.businessObject?.name || '')
      .replace(/[ \t\u00A0]+/gu, ' ')
      .trim()
      .toLocaleLowerCase('ru-RU');
  }

  function findTemplateTasks(elementRegistry, scope = null) {
    return elementRegistry.filter(element => {
      if (!isTaskElement(element)) return false;
      if (scope && !isDescendantOf(element, scope)) return false;
      return normalizedExactTaskName(element) === 'шаблон';
    });
  }

  function taskScopeForTemplate(template) {
    return participantAncestor(template) || processAncestor(template);
  }

  function isSequenceFlow(connection) {
    return connection?.businessObject?.$type === 'bpmn:SequenceFlow';
  }

  function isAssociationLikeConnection(connection) {
    const type = String(connection?.businessObject?.$type || '');
    return type === 'bpmn:Association' ||
      type === 'bpmn:DataInputAssociation' ||
      type === 'bpmn:DataOutputAssociation';
  }

  function isAuxiliaryAssociatedShape(element) {
    const type = String(element?.businessObject?.$type || '');
    return type === 'bpmn:TextAnnotation' ||
      type === 'bpmn:DataObjectReference' ||
      type === 'bpmn:DataStoreReference' ||
      type === 'bpmn:DataInput' ||
      type === 'bpmn:DataOutput';
  }

  function isMovableFlowShape(element) {
    if (!element || element.labelTarget || element.waypoints) return false;
    return Number.isFinite(Number(element.x)) && Number.isFinite(Number(element.y)) &&
      Number.isFinite(Number(element.width)) && Number.isFinite(Number(element.height));
  }

  function elementCenterX(element) {
    return (Number(element?.x) || 0) + (Number(element?.width) || 0) / 2;
  }

  function elementCenterY(element) {
    return (Number(element?.y) || 0) + (Number(element?.height) || 0) / 2;
  }

  function elementRight(element) {
    return (Number(element?.x) || 0) + (Number(element?.width) || 0);
  }

  function elementDepth(element) {
    let depth = 0;
    let current = element;
    while (current) {
      depth += 1;
      current = current.parent;
    }
    return depth;
  }

  function isLane(element) {
    return element?.businessObject?.$type === 'bpmn:Lane';
  }

  function forwardSequenceFlowsForParent(elementRegistry, parent, template) {
    return elementRegistry.filter(connection => {
      if (!isSequenceFlow(connection)) return false;
      const source = connection.source;
      const target = connection.target;
      if (!isMovableFlowShape(source) || !isMovableFlowShape(target)) return false;
      if (source === template || target === template) return false;
      if (source.parent !== parent || target.parent !== parent) return false;

      // Only left-to-right flows participate in horizontal spacing. Vertical
      // and return flows keep the author's layout and are not used as a reason
      // to shift elements horizontally.
      return elementCenterX(target) > elementCenterX(source) + 0.5;
    });
  }

  function collectForwardReachable(roots, edges) {
    const outgoing = new Map();
    for (const edge of edges) {
      const list = outgoing.get(edge.source) || [];
      list.push(edge.target);
      outgoing.set(edge.source, list);
    }

    const active = new Set();
    const queue = Array.from(roots || []);
    while (queue.length) {
      const current = queue.shift();
      if (!current || active.has(current)) continue;
      active.add(current);
      for (const target of outgoing.get(current) || []) {
        if (!active.has(target)) queue.push(target);
      }
    }
    return active;
  }

  function calculateHorizontalShifts(active, edges, minGap) {
    const originalX = new Map();
    const shifts = new Map();
    for (const element of active) {
      originalX.set(element, Number(element.x) || 0);
      shifts.set(element, 0);
    }

    const activeEdges = edges
      .filter(edge => active.has(edge.source) && active.has(edge.target))
      .sort((a, b) => elementCenterX(a.source) - elementCenterX(b.source) || elementCenterX(a.target) - elementCenterX(b.target));

    // Forward edges strictly increase X, therefore the graph is acyclic for
    // the purpose of this calculation. A few relaxation passes make the code
    // robust even if several branches converge on the same element.
    const maxPasses = Math.max(1, active.size + 2);
    for (let pass = 0; pass < maxPasses; pass += 1) {
      let changed = false;
      for (const edge of activeEdges) {
        const source = edge.source;
        const target = edge.target;
        const sourceShift = shifts.get(source) || 0;
        const sourceX = (originalX.get(source) || 0) + sourceShift;
        const requiredTargetX = sourceX + (Number(source.width) || 0) + minGap;
        const requiredTargetShift = Math.max(0, requiredTargetX - (originalX.get(target) || 0));
        if (requiredTargetShift > (shifts.get(target) || 0) + 0.01) {
          shifts.set(target, requiredTargetShift);
          changed = true;
        }
      }
      if (!changed) break;
    }

    return { shifts, activeEdges };
  }

  function moveShapesByShift(modeling, shifts) {
    const entries = Array.from(shifts.entries())
      .filter(([, dx]) => Number(dx) > 0.01)
      // Move downstream elements first. Connections are re-laid out after all
      // geometry changes, so this ordering primarily avoids transient overlap.
      .sort((a, b) => elementCenterX(b[0]) - elementCenterX(a[0]));

    let moved = 0;
    const movedElements = new Set();
    for (const [element, deltaX] of entries) {
      if (typeof modeling.moveShape !== 'function') continue;
      modeling.moveShape(element, { x: deltaX, y: 0 }, element.parent || null);
      moved += 1;
      movedElements.add(element);
    }
    return { moved, movedElements };
  }

  function snapshotShapePositions(elementRegistry, scope) {
    const snapshot = new Map();
    for (const element of elementRegistry.filter(e =>
      isMovableFlowShape(e) && isDescendantOf(e, scope)
    )) {
      snapshot.set(element, {
        x: Number(element.x) || 0,
        y: Number(element.y) || 0
      });
    }
    return snapshot;
  }

  function shapeDeltaFromSnapshot(element, snapshot) {
    const before = snapshot.get(element);
    if (!before) return { x: 0, y: 0 };
    return {
      x: (Number(element.x) || 0) - before.x,
      y: (Number(element.y) || 0) - before.y
    };
  }

  function sameDelta(a, b, tolerance = 0.5) {
    return Math.abs((a?.x || 0) - (b?.x || 0)) <= tolerance &&
      Math.abs((a?.y || 0) - (b?.y || 0)) <= tolerance;
  }

  function associationGraphForScope(elementRegistry, scope) {
    const connections = elementRegistry.filter(connection => {
      if (!isAssociationLikeConnection(connection)) return false;
      if (!connection.source || !connection.target) return false;
      return isDescendantOf(connection.source, scope) && isDescendantOf(connection.target, scope);
    });

    const adjacency = new Map();
    for (const connection of connections) {
      for (const [from, to] of [[connection.source, connection.target], [connection.target, connection.source]]) {
        const list = adjacency.get(from) || [];
        list.push({ element: to, connection });
        adjacency.set(from, list);
      }
    }

    return { connections, adjacency };
  }

  function associatedProcessOwners(auxiliary, adjacency, scope) {
    const owners = new Set();
    const visitedAux = new Set();
    const queue = [auxiliary];

    while (queue.length) {
      const current = queue.shift();
      if (!current || visitedAux.has(current)) continue;
      visitedAux.add(current);

      for (const link of adjacency.get(current) || []) {
        const other = link.element;
        if (!other || !isMovableFlowShape(other) || !isDescendantOf(other, scope)) continue;

        if (isAuxiliaryAssociatedShape(other)) {
          if (!visitedAux.has(other)) queue.push(other);
          continue;
        }

        // Pool/Lane are layout containers, not semantic owners of an
        // annotation/data object. Everything else is treated as a process
        // shape whose movement can own the visual block.
        if (!isParticipant(other) && !isLane(other)) owners.add(other);
      }
    }

    return owners;
  }

  function moveAssociatedVisualBlocks(service, scope, positionSnapshot) {
    const { connections, adjacency } = associationGraphForScope(service.elementRegistry, scope);
    if (!connections.length) return { moved: 0, movedElements: new Set(), sharedSkipped: 0, affectedConnections: new Set() };

    const auxiliaries = service.elementRegistry.filter(element =>
      isAuxiliaryAssociatedShape(element) &&
      isMovableFlowShape(element) &&
      isDescendantOf(element, scope)
    );

    let moved = 0;
    let sharedSkipped = 0;
    const movedElements = new Set();
    const affectedConnections = new Set();

    for (const auxiliary of auxiliaries) {
      const owners = Array.from(associatedProcessOwners(auxiliary, adjacency, scope));
      if (!owners.length) continue;

      const ownerDeltas = owners.map(owner => shapeDeltaFromSnapshot(owner, positionSnapshot));
      const desired = ownerDeltas[0];
      const compatible = ownerDeltas.every(delta => sameDelta(delta, desired));

      // A shared artifact tied to process elements that moved differently has
      // no unambiguous owner. Keep it where the analyst placed it and only let
      // its dotted links stretch/re-route.
      if (!compatible) {
        sharedSkipped += 1;
        continue;
      }

      const currentDelta = shapeDeltaFromSnapshot(auxiliary, positionSnapshot);
      const residual = {
        x: (desired?.x || 0) - currentDelta.x,
        y: (desired?.y || 0) - currentDelta.y
      };

      if (Math.abs(residual.x) <= 0.01 && Math.abs(residual.y) <= 0.01) continue;
      if (typeof service.modeling.moveShape !== 'function') continue;

      service.modeling.moveShape(auxiliary, residual, auxiliary.parent || null);
      moved += 1;
      movedElements.add(auxiliary);

      for (const link of adjacency.get(auxiliary) || []) {
        if (link.connection) affectedConnections.add(link.connection);
      }
    }

    return { moved, movedElements, sharedSkipped, affectedConnections };
  }

  function clamp01(value) {
    return Math.max(0, Math.min(1, Number(value) || 0));
  }

  function dockingSideAtPoint(element, point) {
    if (!element || !point || !isMovableFlowShape(element)) return null;

    const x = Number(element.x) || 0;
    const y = Number(element.y) || 0;
    const width = Number(element.width) || 0;
    const height = Number(element.height) || 0;
    const right = x + width;
    const bottom = y + height;
    const px = Number(point.x) || 0;
    const py = Number(point.y) || 0;

    const candidates = [
      { side: 'LEFT', distance: Math.abs(px - x), ratio: height ? clamp01((py - y) / height) : 0.5 },
      { side: 'RIGHT', distance: Math.abs(px - right), ratio: height ? clamp01((py - y) / height) : 0.5 },
      { side: 'TOP', distance: Math.abs(py - y), ratio: width ? clamp01((px - x) / width) : 0.5 },
      { side: 'BOTTOM', distance: Math.abs(py - bottom), ratio: width ? clamp01((px - x) / width) : 0.5 }
    ];

    candidates.sort((a, b) => a.distance - b.distance);
    return { side: candidates[0].side, ratio: candidates[0].ratio };
  }

  function captureConnectionDocking(connection) {
    if (!connection || !isSequenceFlow(connection)) return null;
    const waypoints = Array.isArray(connection.waypoints) ? connection.waypoints : [];
    if (waypoints.length < 2) return null;

    return {
      source: dockingSideAtPoint(connection.source, waypoints[0]),
      target: dockingSideAtPoint(connection.target, waypoints[waypoints.length - 1])
    };
  }

  function canonicalDockRatio(element, docking) {
    const type = String(element?.businessObject?.$type || '');
    // Gateways and events are not rectangular. A point with an arbitrary ratio
    // on their bounding-box edge would not lie on the visible shape. Preserve
    // the SIDE chosen by the analyst, but dock at that side's canonical vertex.
    if (type.includes('Gateway') || type.includes('Event')) return 0.5;
    return clamp01(docking?.ratio ?? 0.5);
  }

  function pointForDockingSide(element, docking, fallbackSide) {
    if (!element || !isMovableFlowShape(element)) return null;
    const side = docking?.side || fallbackSide || 'RIGHT';
    const ratio = canonicalDockRatio(element, docking);
    const x = Number(element.x) || 0;
    const y = Number(element.y) || 0;
    const width = Number(element.width) || 0;
    const height = Number(element.height) || 0;

    if (side === 'LEFT') return { x, y: y + height * ratio };
    if (side === 'RIGHT') return { x: x + width, y: y + height * ratio };
    if (side === 'TOP') return { x: x + width * ratio, y };
    return { x: x + width * ratio, y: y + height };
  }

  function defaultDockingForConnection(connection) {
    const source = connection?.source;
    const target = connection?.target;
    if (!isMovableFlowShape(source) || !isMovableFlowShape(target)) return null;

    const dx = elementCenterX(target) - elementCenterX(source);
    const dy = elementCenterY(target) - elementCenterY(source);
    if (Math.abs(dx) >= Math.abs(dy)) {
      return dx >= 0
        ? { source: { side: 'RIGHT', ratio: 0.5 }, target: { side: 'LEFT', ratio: 0.5 } }
        : { source: { side: 'LEFT', ratio: 0.5 }, target: { side: 'RIGHT', ratio: 0.5 } };
    }
    return dy >= 0
      ? { source: { side: 'BOTTOM', ratio: 0.5 }, target: { side: 'TOP', ratio: 0.5 } }
      : { source: { side: 'TOP', ratio: 0.5 }, target: { side: 'BOTTOM', ratio: 0.5 } };
  }

  function compactOrthogonalWaypoints(points) {
    const compact = [];
    for (const point of points || []) {
      if (!point) continue;
      const current = { x: Number(point.x) || 0, y: Number(point.y) || 0 };
      const previous = compact[compact.length - 1];
      if (previous && Math.abs(previous.x - current.x) < 0.01 && Math.abs(previous.y - current.y) < 0.01) continue;
      compact.push(current);
    }

    // Remove a middle point when three consecutive points are collinear.
    let changed = true;
    while (changed && compact.length > 2) {
      changed = false;
      for (let i = 1; i < compact.length - 1; i += 1) {
        const a = compact[i - 1];
        const b = compact[i];
        const c = compact[i + 1];
        const sameX = Math.abs(a.x - b.x) < 0.01 && Math.abs(b.x - c.x) < 0.01;
        const sameY = Math.abs(a.y - b.y) < 0.01 && Math.abs(b.y - c.y) < 0.01;
        if (sameX || sameY) {
          compact.splice(i, 1);
          changed = true;
          break;
        }
      }
    }
    return compact;
  }

  function buildOrthogonalWaypoints(start, end, sourceDock, targetDock) {
    const sourceSide = sourceDock?.side || 'RIGHT';
    const targetSide = targetDock?.side || 'LEFT';
    const sourceHorizontal = sourceSide === 'LEFT' || sourceSide === 'RIGHT';
    const targetHorizontal = targetSide === 'LEFT' || targetSide === 'RIGHT';
    const points = [ start ];

    if (sourceHorizontal && targetHorizontal) {
      if (Math.abs(start.y - end.y) < 0.5) {
        points.push(end);
      } else {
        const midX = (start.x + end.x) / 2;
        points.push({ x: midX, y: start.y }, { x: midX, y: end.y }, end);
      }
    } else if (!sourceHorizontal && !targetHorizontal) {
      if (Math.abs(start.x - end.x) < 0.5) {
        points.push(end);
      } else {
        const midY = (start.y + end.y) / 2;
        points.push({ x: start.x, y: midY }, { x: end.x, y: midY }, end);
      }
    } else if (!sourceHorizontal && targetHorizontal) {
      // Typical BPMN branch: leave a gateway at TOP/BOTTOM, then approach the
      // next Task/Gateway from LEFT/RIGHT.
      points.push({ x: start.x, y: end.y }, end);
    } else {
      // Typical BPMN merge: leave a Task/Gateway horizontally and enter the
      // merge gateway from TOP/BOTTOM.
      points.push({ x: end.x, y: start.y }, end);
    }

    return compactOrthogonalWaypoints(points);
  }

  function relayoutForwardSequenceFlow(modeling, connection, dockingSnapshot = null) {
    if (!connection || !isSequenceFlow(connection)) return false;
    const source = connection.source;
    const target = connection.target;
    if (!isMovableFlowShape(source) || !isMovableFlowShape(target)) return false;
    if (elementCenterX(target) <= elementCenterX(source) + 0.5) return false;

    const docking = dockingSnapshot || defaultDockingForConnection(connection);
    if (!docking) return false;

    const start = pointForDockingSide(source, docking.source, 'RIGHT');
    const end = pointForDockingSide(target, docking.target, 'LEFT');
    if (!start || !end) return false;
    const waypoints = buildOrthogonalWaypoints(start, end, docking.source, docking.target);

    // Use freshly calculated waypoints instead of asking the generic layouter
    // to choose new docking sides. This preserves the analyst's semantic
    // choice (LEFT/RIGHT/TOP/BOTTOM) while discarding stale intermediate
    // geometry from before resize/move.
    if (typeof modeling.updateWaypoints === 'function') {
      modeling.updateWaypoints(connection, waypoints);
      return true;
    }

    try {
      if (typeof modeling.layoutConnection === 'function') {
        modeling.layoutConnection(connection, {
          connectionStart: start,
          connectionEnd: end,
          waypoints
        });
        return true;
      }
    } catch (_) {}

    return false;
  }

  function ensureParticipantRightPadding(service, participant, minGap) {
    if (!participant || !isParticipant(participant)) return 0;

    const shapes = service.elementRegistry.filter(element =>
      element !== participant &&
      !isLane(element) &&
      isMovableFlowShape(element) &&
      isDescendantOf(element, participant)
    );
    if (!shapes.length) return 0;

    const rightmost = Math.max(...shapes.map(element => elementRight(element)));
    const currentRight = elementRight(participant);
    const requiredRight = rightmost + minGap;
    const extra = requiredRight - currentRight;
    if (!(extra > 0.01)) return 0;

    const newBounds = {
      x: Number(participant.x) || 0,
      y: Number(participant.y) || 0,
      width: (Number(participant.width) || 0) + extra,
      height: Number(participant.height) || 0
    };

    try {
      // bpmn-js lane resizing understands Participant/Lane hierarchies and
      // expands nested lanes together with the pool. balanced=false means
      // "make space" on the east side without redistributing lane heights.
      if (typeof service.modeling.resizeLane === 'function') {
        service.modeling.resizeLane(participant, newBounds, false);
        return extra;
      }
    } catch (_) {}

    if (typeof service.modeling.resizeShape === 'function') {
      service.modeling.resizeShape(participant, newBounds);
      return extra;
    }

    return 0;
  }


  function isExpandedSubProcessElement(element) {
    if (!isSubProcessLike(element)) return false;

    const di = element?.businessObject?.di;
    if (di && typeof di.isExpanded === 'boolean') return di.isExpanded;

    // Fallback for diagrams where isExpanded is not exposed on the DI object:
    // an expanded subprocess has visible diagram children parented to it.
    return Array.isArray(element?.children) && element.children.some(child => child && !child.labelTarget);
  }

  function shiftForwardAfterExpandedSubProcess(service, subprocess, minGap, template) {
    const parent = subprocess?.parent || null;
    if (!parent) {
      return { moved: 0, movedElements: new Set(), affectedConnections: new Set() };
    }

    const edges = forwardSequenceFlowsForParent(service.elementRegistry, parent, template);
    if (!edges.length) {
      return { moved: 0, movedElements: new Set(), affectedConnections: new Set() };
    }

    // The expanded Sub-process itself stays where it is. Its new right edge is
    // simply treated as the new spacing anchor; every element reachable to the
    // right through forward Sequence Flow is shifted only as much as required.
    const active = collectForwardReachable([subprocess], edges);
    if (active.size <= 1) {
      return { moved: 0, movedElements: new Set(), affectedConnections: new Set() };
    }

    const { shifts, activeEdges } = calculateHorizontalShifts(active, edges, minGap);
    shifts.set(subprocess, 0);
    const moveResult = moveShapesByShift(service.modeling, shifts);

    return {
      moved: moveResult.moved,
      movedElements: moveResult.movedElements,
      affectedConnections: new Set(activeEdges)
    };
  }

  function ensureExpandedSubProcessesRightPadding(service, scope, minGap, template) {
    const subprocesses = service.elementRegistry.filter(element =>
      isExpandedSubProcessElement(element) &&
      isDescendantOf(element, scope)
    )
      // Expand inner subprocesses first. Immediately after an inner container
      // grows, move its downstream siblings to the right. Then an outer
      // subprocess sees the FINAL geometry of the whole inner level when its
      // own right edge is calculated.
      .sort((a, b) => elementDepth(b) - elementDepth(a));

    let resized = 0;
    let totalExtra = 0;
    let shifted = 0;
    const resizedElements = new Set();
    const movedElements = new Set();
    const affectedConnections = new Set();

    for (const subprocess of subprocesses) {
      const descendants = service.elementRegistry.filter(element =>
        element !== subprocess &&
        !isLane(element) &&
        isMovableFlowShape(element) &&
        isDescendantOf(element, subprocess)
      );
      if (!descendants.length) continue;

      const rightmost = Math.max(...descendants.map(element => elementRight(element)));
      const currentRight = elementRight(subprocess);
      const requiredRight = rightmost + minGap;
      const extra = requiredRight - currentRight;
      if (!(extra > 0.01)) continue;

      const newBounds = {
        x: Number(subprocess.x) || 0,
        y: Number(subprocess.y) || 0,
        width: (Number(subprocess.width) || 0) + extra,
        height: Number(subprocess.height) || 0
      };

      if (typeof service.modeling.resizeShape !== 'function') continue;
      service.modeling.resizeShape(subprocess, newBounds);
      resized += 1;
      totalExtra += extra;
      resizedElements.add(subprocess);

      // Growing the right edge must not cover the next process element. Move
      // the ENTIRE downstream chain on this level, exactly like the normal
      // Task-spacing phase does. Branches move together and converging paths
      // use the maximum required shift via calculateHorizontalShifts().
      const downstream = shiftForwardAfterExpandedSubProcess(service, subprocess, minGap, template);
      shifted += downstream.moved;
      for (const element of downstream.movedElements) movedElements.add(element);
      for (const connection of downstream.affectedConnections) affectedConnections.add(connection);
    }

    return { resized, totalExtra, resizedElements, shifted, movedElements, affectedConnections };
  }

  function alignTaskSizesCore(service) {
    const participants = service.elementRegistry.filter(e => isParticipant(e));
    const selected = Array.isArray(service.currentSelection) ? service.currentSelection : [];

    let currentPool = null;
    for (const element of selected) {
      currentPool = participantAncestor(element) || (isParticipant(element) ? element : null);
      if (currentPool) break;
    }
    if (!currentPool && participants.length === 1) currentPool = participants[0];

    let templates = currentPool
      ? findTemplateTasks(service.elementRegistry, currentPool)
      : findTemplateTasks(service.elementRegistry);

    if (templates.length > 1) {
      postStatus(currentPool
        ? 'Выровнять размер задач: в текущем пуле найдено несколько задач «ШАБЛОН». Операция не выполнена.'
        : 'Выровнять размер задач: найдено несколько задач «ШАБЛОН». Операция не выполнена.');
      return;
    }

    if (templates.length === 0 && currentPool) {
      templates = findTemplateTasks(service.elementRegistry);
      if (templates.length > 1) {
        postStatus('Выровнять размер задач: найдено несколько задач «ШАБЛОН». Операция не выполнена.');
        return;
      }
    }

    if (templates.length === 0) {
      postStatus('Выровнять размер задач: элемент «ШАБЛОН» не найден.');
      return;
    }

    const template = templates[0];
    const scope = taskScopeForTemplate(template);
    if (!scope) {
      postStatus('Выровнять размер задач: не удалось определить текущий пул или процесс для «ШАБЛОН».');
      return;
    }

    const width = Number(template.width) || 0;
    const height = Number(template.height) || 0;
    if (!(width > 0 && height > 0)) {
      postStatus('Выровнять размер задач: у «ШАБЛОН» не удалось определить размер.');
      return;
    }

    const minGap = Math.max(0, Math.min(500, Number(settings.alignTaskMinGap) || 0));
    const targets = service.elementRegistry.filter(element =>
      isTaskElement(element) && element !== template && isDescendantOf(element, scope)
    );

    // Snapshot every shape position before the operation. Besides driving the
    // normal flow-chain shift, this lets us move Data Objects, Data Stores and
    // Text Annotations together with the process element they are associated
    // with. The snapshot also prevents double-moving children that already
    // travelled with a moved expanded Sub-process.
    const positionSnapshot = snapshotShapePositions(service.elementRegistry, scope);

    // Capture docking SIDES before any resize/move. The generic bpmn-js
    // connection layouter may otherwise re-dock a branch to another side of a
    // Gateway after geometry changes. We preserve LEFT/RIGHT/TOP/BOTTOM, but
    // deliberately do not preserve the old intermediate waypoint route.
    const dockingSnapshots = new Map();
    for (const connection of service.elementRegistry.filter(e => isSequenceFlow(e))) {
      if (!isDescendantOf(connection.source, scope) || !isDescendantOf(connection.target, scope)) continue;
      dockingSnapshots.set(connection, captureConnectionDocking(connection));
    }

    // Phase 1. Resize every Task to the template. Keep the LEFT edge fixed so
    // an enlarged task grows only to the right and never invades the upstream
    // part of the diagram. Preserve the vertical centre when height changes.
    let changed = 0;
    for (const task of targets) {
      const currentWidth = Number(task.width) || 0;
      const currentHeight = Number(task.height) || 0;
      if (Math.abs(currentWidth - width) < 0.01 && Math.abs(currentHeight - height) < 0.01) continue;

      const newX = Number(task.x) || 0;
      const newY = (Number(task.y) || 0) + (currentHeight - height) / 2;
      service.modeling.resizeShape(task, {
        x: newX,
        y: newY,
        width,
        height
      });
      changed += 1;
    }

    // Phase 2. Recalculate horizontal spacing per flow level. Each parent
    // (Participant/Process/expanded Sub-process) is handled separately. This
    // prevents descendants of a moved Sub-process from being moved twice.
    const rootsByParent = new Map();
    for (const task of targets) {
      const parent = task.parent || null;
      if (!parent) continue;
      const list = rootsByParent.get(parent) || [];
      list.push(task);
      rootsByParent.set(parent, list);
    }

    const parents = Array.from(rootsByParent.keys())
      .sort((a, b) => elementDepth(a) - elementDepth(b));

    let shiftedElements = 0;
    const movedElements = new Set();
    const connectionsToRelayout = new Set();

    for (const parent of parents) {
      const edges = forwardSequenceFlowsForParent(service.elementRegistry, parent, template);
      if (!edges.length) continue;

      // Every Task on this level is a spacing anchor. This makes the command
      // idempotent and also repairs a diagram previously processed by an older
      // plugin version: if a gap is already sufficient nothing moves.
      const active = collectForwardReachable(rootsByParent.get(parent), edges);
      if (!active.size) continue;

      const { shifts, activeEdges } = calculateHorizontalShifts(active, edges, minGap);
      const moveResult = moveShapesByShift(service.modeling, shifts);
      shiftedElements += moveResult.moved;
      for (const element of moveResult.movedElements) movedElements.add(element);
      for (const edge of activeEdges) connectionsToRelayout.add(edge);
    }

    // Phase 3. Stabilize expanded Sub-process geometry together with the
    // downstream process chain and associated visual artifacts.
    //
    // Important: an expanded Sub-process grows to the RIGHT. That new right
    // edge may overlap the next element OUTSIDE the Sub-process. Therefore each
    // time a Sub-process grows we use it as a new spacing anchor and shift the
    // whole forward-reachable chain on the same parent level. Associations then
    // follow their process owners. If that reveals another container overflow,
    // the loop performs one more inside-out expansion pass. All operations are
    // still children of the single atomic crsc.alignTaskSizes command.
    const subprocessResizedElements = new Set();
    const subprocessShiftedElements = new Set();
    const associatedMovedElements = new Set();
    let subprocessTotalExtra = 0;
    let associatedSharedSkipped = 0;

    const stabilizePasses = Math.max(3, Math.min(12,
      service.elementRegistry.filter(e => isExpandedSubProcessElement(e) && isDescendantOf(e, scope)).length + 4
    ));

    for (let pass = 0; pass < stabilizePasses; pass += 1) {
      const expanded = ensureExpandedSubProcessesRightPadding(service, scope, minGap, template);
      subprocessTotalExtra += expanded.totalExtra || 0;

      for (const element of expanded.resizedElements) subprocessResizedElements.add(element);
      for (const element of expanded.movedElements) {
        subprocessShiftedElements.add(element);
        movedElements.add(element);
      }
      for (const connection of expanded.affectedConnections) connectionsToRelayout.add(connection);

      const associated = moveAssociatedVisualBlocks(service, scope, positionSnapshot);
      for (const element of associated.movedElements) associatedMovedElements.add(element);
      associatedSharedSkipped = Math.max(associatedSharedSkipped, associated.sharedSkipped || 0);

      if (!expanded.resized && !expanded.shifted && !associated.moved) break;
    }

    const subprocessExpand = {
      resized: subprocessResizedElements.size,
      totalExtra: subprocessTotalExtra,
      resizedElements: subprocessResizedElements,
      shifted: subprocessShiftedElements.size,
      movedElements: subprocessShiftedElements
    };

    const associatedMove = {
      moved: associatedMovedElements.size,
      movedElements: associatedMovedElements,
      sharedSkipped: associatedSharedSkipped
    };

    // Now that all process shapes have their FINAL positions, include every
    // forward Sequence Flow whose endpoint was resized or moved. This covers:
    // - normal Task resize/spacing;
    // - an expanded Sub-process whose right edge grew;
    // - every downstream element shifted because of that growth.
    for (const connection of service.elementRegistry.filter(e => isSequenceFlow(e))) {
      if (!isDescendantOf(connection.source, scope) || !isDescendantOf(connection.target, scope)) continue;
      if (elementCenterX(connection.target) <= elementCenterX(connection.source) + 0.5) continue;
      if (
        targets.includes(connection.source) ||
        targets.includes(connection.target) ||
        movedElements.has(connection.source) ||
        movedElements.has(connection.target) ||
        subprocessResizedElements.has(connection.source) ||
        subprocessResizedElements.has(connection.target)
      ) {
        connectionsToRelayout.add(connection);
      }
    }

    // Phase 4. If the process no longer fits in its pool, extend the pool and
    // its lanes to the right. The same user-configured gap is used as right
    // padding, keeping the result visually consistent. Associated artifacts and
    // expanded Sub-processes have already reached their final width, so they
    // also participate in the rightmost-boundary check.
    const participant = participantAncestor(template);
    const poolExtra = participant
      ? ensureParticipantRightPadding(service, participant, minGap)
      : 0;

    // Phase 5. Rebuild affected forward Sequence Flow routes from FINAL
    // geometry. This removes stale waypoints left by resize/move operations and
    // keeps horizontal chains straight while preserving element Y positions.
    let relaidConnections = 0;
    for (const connection of connectionsToRelayout) {
      if (relayoutForwardSequenceFlow(service.modeling, connection, dockingSnapshots.get(connection))) relaidConnections += 1;
    }

    const scopeName = participant ? 'текущий пул' : 'процесс';
    if (changed || shiftedElements || associatedMove.moved || subprocessExpand.resized || poolExtra || relaidConnections) {
      const parts = [ `изменено задач — ${changed}` ];
      if (shiftedElements) parts.push(`сдвинуто элементов процесса — ${shiftedElements}`);
      if (associatedMove.moved) parts.push(`сдвинуто связанных элементов — ${associatedMove.moved}`);
      if (associatedMove.sharedSkipped) parts.push(`общих связанных элементов оставлено на месте — ${associatedMove.sharedSkipped}`);
      if (subprocessExpand.resized) parts.push(`расширено подпроцессов — ${subprocessExpand.resized}`);
      if (subprocessExpand.shifted) parts.push(`сдвинуто элементов после подпроцессов — ${subprocessExpand.shifted}`);
      if (relaidConnections) parts.push(`перестроено стрелок — ${relaidConnections}`);
      if (poolExtra) parts.push(`пул расширен на ${Math.round(poolExtra)} px`);
      parts.push(`минимальный зазор — ${Math.round(minGap)} px`);
      parts.push(`размер «ШАБЛОН» — ${Math.round(width)}×${Math.round(height)}`);
      parts.push(`область — ${scopeName}`);
      postStatus(`Выровнять размер задач: ${parts.join('; ')}.`);
    } else {
      postStatus('Выровнять размер задач: изменений нет.');
    }
  }

  function alignTaskSizes() {
    const service = getNumberingService();
    if (!service) {
      postStatus('Не найден активный BPMN-редактор.');
      return;
    }

    try {
      return executeAtomicPluginCommand(service, 'crsc.alignTaskSizes', () => alignTaskSizesCore(service));
    } catch (error) {
      console.error('[Camunda Russian Spell Checker] align task sizes error', error);
      postStatus('Не удалось выровнять размер задач.');
    }
  }

  function numberDiagram() {
    const service = getNumberingService();
    if (!service) {
      postStatus('Не найден активный BPMN-редактор. Откройте BPMN-диаграмму.');
      return;
    }

    try {
      return executeAtomicPluginCommand(service, 'crsc.numberDiagram', () => numberDiagramCore(service));
    } catch (error) {
      console.error('[Camunda Russian Spell Checker] atomic numbering error', error);
      postStatus('Не удалось выполнить автонумерацию.');
    }
  }

  function numberDiagramCore(service) {
    /*
     * In a BPMN Collaboration the visible pool is a bpmn:Participant.
     * Its businessObject.processRef points to the actual bpmn:Process, but
     * diagram elements inside the pool are parented to the Participant.
     * The old implementation only searched for visual bpmn:Process roots,
     * so a process shown inside a pool was reported as "not found".
     *
     * Prefer visible Participants when they exist. This also gives us a
     * natural numbering scope per pool. If there are no participants, keep
     * the original process-root behaviour for ordinary BPMN diagrams.
     */
    const participants = service.elementRegistry.filter(e => isParticipant(e));
    const processRoots = service.elementRegistry.filter(e =>
      e && e.businessObject && e.businessObject.$type === 'bpmn:Process'
    );

    const scopes = participants.length
      ? participants
      : processRoots;

    if (!scopes.length) {
      postStatus('Не найден процесс или pool (Participant) для нумерации.');
      return;
    }

    const changes = [];
    try {
      for (const scope of scopes) {
        numberScope(scope, service, '', changes);
      }

      const suffix = participants.length > 1 ? `, пулов — ${participants.length}` : '';
      postStatus(
        changes.length
          ? `Автонумерация: изменено шагов — ${changes.length}${suffix}`
          : 'Автонумерация: изменений нет'
      );
    } catch (error) {
      console.error('[Camunda Russian Spell Checker] numbering error', error);
      postStatus('Не удалось выполнить автонумерацию.');
    }
  }

