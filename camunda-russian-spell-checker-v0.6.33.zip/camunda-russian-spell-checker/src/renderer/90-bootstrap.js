  // Pure helpers exposed for local regression tests and diagnostics.
  // They do not modify BPMN state or settings.
  window.__crscTestHooks = Object.assign(window.__crscTestHooks || {}, {
    compileCorrectionRules,
    correctionMatchesForRules,
    parseNumberingPrefix,
    stripStepPrefix,
    stripLegacyExpandedSubProcessCode,
    stepLabel,
    editDistance,
    getErpFuzzyMaxTokenDistance,
    erpTokens,
    normalizeErpDocumentTitle,
    acceptableTerminologyTokenDistance,
    scoreErpDocumentCandidate,
    rankErpDocumentCandidates,
    compileBpmnNamingRules,
    bpmnNamingMatches,
    isBpmnActivityElement,
    matchPriority,
    resolveMatchConflicts,
    filterIgnoredUserTermMatches
  });

  async function start() {
    window.addEventListener('crsc-terminology-result', applyTerminologyResult);
    ensureStatus();
    registerNumberingModule();
    try { await loadCorrections(); await loadErp26Dictionary(); } catch (_) {} ensureToolbar(); scanFields();
    observer = new MutationObserver(() => scanFields());
    observer.observe(document.body, { childList: true, subtree: true });

    window.addEventListener('message', handleMessage);
    document.addEventListener('scroll', () => {
      if (popup?.classList.contains('crsc-visible') && popupTarget) positionPopup(popupTarget);
    }, true);
    window.addEventListener('resize', () => {
      if (popup?.classList.contains('crsc-visible') && popupTarget) positionPopup(popupTarget);
      positionStatus();
    });
    document.addEventListener('keydown', e => {
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'l') {
        e.preventDefault(); toggle();
      }
    });
    document.documentElement.classList.toggle('crsc-disabled', !settings.enabled);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
