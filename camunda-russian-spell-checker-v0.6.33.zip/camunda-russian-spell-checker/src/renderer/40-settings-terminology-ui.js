  function slugifyTerminologyName(name) {
    const translit = String(name || '').trim().toLocaleLowerCase('ru-RU')
      .replace(/ё/g, 'е')
      .replace(/[^a-zа-я0-9]+/giu, '-')
      .replace(/^-+|-+$/gu, '');
    return translit || `terminology-${Date.now()}`;
  }

  function sendTerminologyOperation(payload) {
    try {
      window.open(`camunda-rsc://terminology/${encodeURIComponent(JSON.stringify(payload))}`, '_blank');
    } catch (_) {
      postStatus('Не удалось выполнить операцию с терминологией.');
    }
  }

  function splitTerminologyTerms(value) {
    return String(value || '').split(/[\n,;]+/u).map(x => x.trim()).filter(Boolean);
  }

  function showTerminologyEditorDialog(item) {
    closeTerminologyEditorDialog();
    const isUserCustom = item?.id === 'user-custom';
    const isEdit = !!item && !isUserCustom ? true : !!item;
    const overlay = document.createElement('div');
    overlay.id = 'crsc-terminology-editor-overlay';
    overlay.className = 'crsc-modal-overlay crsc-modal-overlay-front';
    const modal = document.createElement('div');
    modal.className = 'crsc-modal crsc-terminology-modal';

    const header = document.createElement('div');
    header.className = 'crsc-modal-header';
    const title = document.createElement('div');
    title.className = 'crsc-modal-title';
    title.textContent = isUserCustom ? 'Изменить пользовательские исключения' : (isEdit ? `Изменить терминологию «${item.name}»` : 'Добавить терминологию');
    header.appendChild(title);
    const close = document.createElement('button');
    close.type = 'button'; close.className = 'crsc-modal-close'; close.textContent = '×'; close.title = 'Закрыть';
    close.addEventListener('click', closeTerminologyEditorDialog);
    header.appendChild(close);

    const body = document.createElement('div'); body.className = 'crsc-modal-body';

    let name = null;
    let category = null;
    if (!isUserCustom) {
      const nameLabel = document.createElement('label'); nameLabel.textContent = 'Наименование';
      name = document.createElement('input'); name.type = 'text'; name.placeholder = 'Например, 1С:УХ, SAP'; name.value = item?.name || '';
      nameLabel.appendChild(name);

      const categoryLabel = document.createElement('label'); categoryLabel.textContent = 'Категория';
      category = document.createElement('select'); category.className = 'crsc-select';
      ['Справочник', 'Документы', 'Прочее'].forEach(value => { const o=document.createElement('option'); o.value=value; o.textContent=value; category.appendChild(o); });
      category.value = item?.category || 'Прочее';
      categoryLabel.appendChild(category);
      body.append(nameLabel, categoryLabel);
    } else {
      const nameInfo = document.createElement('div');
      nameInfo.className = 'crsc-modal-info';
      nameInfo.textContent = 'User-custom-terms.json — пользовательские слова и термины, которые не следует считать ошибками.';
      body.appendChild(nameInfo);
    }

    const termsLabel = document.createElement('label'); termsLabel.textContent = 'Список терминов';
    const terms = document.createElement('textarea'); terms.rows = 12; terms.placeholder = 'Один термин на строку. Также можно использовать ; или , как разделители.';
    terms.value = item?.terms ? item.terms.join('\n') : '';
    termsLabel.appendChild(terms);
    const hint = document.createElement('div'); hint.className='crsc-modal-info'; hint.textContent='Для длинных названий лучше использовать один термин на строку.';
    body.append(termsLabel, hint);

    const footer = document.createElement('div'); footer.className='crsc-modal-footer';
    const cancel = document.createElement('button'); cancel.type='button'; cancel.className='crsc-secondary'; cancel.textContent='Отмена'; cancel.addEventListener('click', closeTerminologyEditorDialog);
    const save = document.createElement('button'); save.type='button'; save.className='crsc-primary'; save.textContent= isEdit || isUserCustom ? 'Сохранить' : 'Добавить';
    save.addEventListener('click', () => {
      const cleanTerms = splitTerminologyTerms(terms.value);
      if (!isUserCustom && !cleanTerms.length) { postStatus('Добавьте хотя бы один термин.'); terms.focus(); return; }
      if (isUserCustom) {
        sendTerminologyOperation({ op: 'update-user-custom', terms: cleanTerms });
        return;
      }
      const cleanName = name.value.trim();
      if (!cleanName) { postStatus('Укажите наименование терминологии.'); name.focus(); return; }
      const payload = {
        op: isEdit ? 'update' : 'add',
        id: item?.id || slugifyTerminologyName(cleanName),
        name: cleanName,
        category: category.value,
        terms: cleanTerms
      };
      sendTerminologyOperation(payload);
    });

    footer.append(cancel, save);
    modal.append(header, body, footer); overlay.appendChild(modal); document.body.appendChild(overlay);
    setTimeout(() => (name || terms).focus(), 0);
  }

  function showAddTerminologyDialog() { showTerminologyEditorDialog(null); }

  function closeTerminologyEditorDialog() {
    const overlay = document.querySelector('#crsc-terminology-editor-overlay') || document.querySelector('#crsc-add-terminology-overlay');
    if (overlay) overlay.remove();
  }

  function showDeleteTerminologyDialog(item) {
    closeDeleteTerminologyDialog();
    const overlay = document.createElement('div');
    overlay.id = 'crsc-terminology-delete-overlay';
    overlay.className = 'crsc-modal-overlay crsc-modal-overlay-front';
    const modal = document.createElement('div'); modal.className = 'crsc-modal crsc-delete-modal';
    const header = document.createElement('div'); header.className='crsc-modal-header';
    const title = document.createElement('div'); title.className='crsc-modal-title'; title.textContent='Удалить терминологию?';
    const close = document.createElement('button'); close.type='button'; close.className='crsc-modal-close'; close.textContent='×'; close.addEventListener('click', closeDeleteTerminologyDialog);
    header.append(title, close);
    const body = document.createElement('div'); body.className='crsc-modal-body';
    const text = document.createElement('div'); text.textContent=`Терминология «${item.name}» и её словарь будут удалены. Это действие нельзя отменить.`;
    body.appendChild(text);
    const footer = document.createElement('div'); footer.className='crsc-modal-footer';
    const cancel=document.createElement('button'); cancel.type='button'; cancel.className='crsc-secondary'; cancel.textContent='Отмена'; cancel.addEventListener('click', closeDeleteTerminologyDialog);
    const remove=document.createElement('button'); remove.type='button'; remove.className='crsc-danger'; remove.textContent='Удалить'; remove.addEventListener('click', () => sendTerminologyOperation({ op: 'delete', id: item.id }));
    footer.append(cancel, remove); modal.append(header, body, footer); overlay.appendChild(modal); document.body.appendChild(overlay);
  }

  function closeDeleteTerminologyDialog() { const overlay=document.querySelector('#crsc-terminology-delete-overlay'); if (overlay) overlay.remove(); }


  async function applyTerminologyResult(event) {
    const detail = event?.detail || {};
    closeTerminologyEditorDialog();
    closeDeleteTerminologyDialog();
    if (!detail.ok) { postStatus(detail.message || 'Операция с терминологией не выполнена.'); return; }

    invalidateTerminologyCache({ index: true, additional: true, userCustom: true });

    const messages = {
      add: `Терминология «${detail.name || ''}» добавлена`,
      update: `Терминология «${detail.name || ''}» изменена`,
      delete: `Терминология «${detail.name || ''}» удалена`,
      'update-user-custom': 'Пользовательские исключения сохранены'
    };
    postStatus(messages[detail.op] || 'Изменения сохранены');

    // Re-read files before rebuilding Settings so Add/Edit/Delete immediately
    // reflects the actual index and terms instead of stale in-memory data.
    try {
      await loadTerminologyIndex();
      await loadAdditionalTerminologies();
      await loadUserCustomTerms();
    } catch (_) {}
    createSettingsDialog();
  }

  function closeSettingsDialog() {
    const overlay = document.querySelector('#crsc-settings-overlay');
    if (overlay) overlay.remove();
  }

  function createSettingsDialog() {
    closeSettingsDialog();

    const overlay = document.createElement('div');
    overlay.id = 'crsc-settings-overlay';
    overlay.className = 'crsc-modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'crsc-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    const header = document.createElement('div');
    header.className = 'crsc-modal-header';
    header.innerHTML = '<div class="crsc-modal-title">Russian Spell Checker — Настройки</div>';
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'crsc-modal-close';
    close.textContent = '×';
    close.title = 'Закрыть';
    close.addEventListener('click', closeSettingsDialog);
    header.appendChild(close);

    const body = document.createElement('div');
    body.className = 'crsc-modal-body';


    const terminologyTitle = document.createElement('div');
    terminologyTitle.className = 'crsc-section-title';
    terminologyTitle.textContent = 'Терминология';

    const terminologyList = document.createElement('div');
    terminologyList.className = 'crsc-terminology-list';
    const terminologyChecks = new Map();

    const builtIn = [
      { id: 'erp26', name: '1С:ERP 2.6', description: 'Документы и справочники', builtIn: true },
      { id: 'user-custom', name: 'User-custom-terms', description: 'Пользовательские исключения', builtIn: true }
    ];
    const dynamic = terminologyIndex.filter(x => x.id !== 'erp26').map(x => ({
      id: x.id, name: x.name, description: x.category || 'Прочее', builtIn: !!x.builtIn, category: x.category
    }));
    const items = [...builtIn, ...dynamic.filter(x => !builtIn.some(b => b.id === x.id))];

    items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'crsc-terminology-row';
      const left = document.createElement('div'); left.className = 'crsc-terminology-main';
      const cb = document.createElement('input'); cb.type = 'checkbox';
      cb.checked = item.id === 'user-custom' ? true : settings.enabledTerminologies?.[item.id] !== false;
      if (item.id === 'user-custom') cb.disabled = true;
      terminologyChecks.set(item.id, cb);
      const textWrap = document.createElement('span');
      const strong = document.createElement('strong'); strong.textContent = item.name;
      const desc = document.createElement('small');
      if (item.id === 'erp26') {
        const stats = window.__crscErp26Stats;
        if (stats?.loaded) {
          desc.textContent = ` — ${item.description}; загружено: ${stats.documents} документов, ${stats.catalogs} справочников`;
        } else {
          desc.textContent = ` — ${item.description}; ⚠ словарь не загружен`;
        }
      } else {
        desc.textContent = item.description ? ` — ${item.description}` : '';
      }
      textWrap.append(strong, desc); left.append(cb, textWrap);
      row.appendChild(left);

      const actions = document.createElement('div'); actions.className = 'crsc-terminology-actions';
      if (item.id === 'user-custom') {
        const edit = document.createElement('button'); edit.type='button'; edit.className='crsc-icon-button'; edit.textContent='✎'; edit.title='Изменить пользовательские исключения';
        edit.addEventListener('click', async () => { await loadUserCustomTerms(); showTerminologyEditorDialog({ id:'user-custom', name:'User-custom-terms', terms:[...userCustomTerms] }); });
        actions.appendChild(edit);
      } else if (!item.builtIn) {
        const edit = document.createElement('button'); edit.type='button'; edit.className='crsc-icon-button'; edit.textContent='✎'; edit.title='Изменить терминологию';
        edit.addEventListener('click', async () => {
          const entry = await loadTerminologyEntry(item.id);
          showTerminologyEditorDialog({ ...item, ...(entry || {}) });
        });
        const del = document.createElement('button'); del.type='button'; del.className='crsc-icon-button crsc-icon-danger'; del.textContent='×'; del.title='Удалить терминологию';
        del.addEventListener('click', () => showDeleteTerminologyDialog(item));
        actions.append(edit, del);
      }
      row.appendChild(actions);
      terminologyList.appendChild(row);
    });

    const terminologyInfo = document.createElement('div');
    terminologyInfo.className = 'crsc-modal-info';
    terminologyInfo.textContent = 'Системные словари организованы по папкам dictionary/<система>/. Пользовательские исключения хранятся отдельно в User-custom-terms.json. Системные словари нельзя изменять или удалять.';

    const erpFuzzyDistanceLabel = document.createElement('label');
    erpFuzzyDistanceLabel.textContent = 'ERP fuzzy: максимальное расстояние редактирования одного слова';
    const erpFuzzyDistance = document.createElement('input');
    erpFuzzyDistance.type = 'number';
    erpFuzzyDistance.min = '0';
    erpFuzzyDistance.max = '5';
    erpFuzzyDistance.step = '1';
    erpFuzzyDistance.value = String(getErpFuzzyMaxTokenDistance());
    erpFuzzyDistanceLabel.appendChild(erpFuzzyDistance);

    const erpFuzzyDistanceInfo = document.createElement('div');
    erpFuzzyDistanceInfo.className = 'crsc-modal-info';
    erpFuzzyDistanceInfo.textContent = 'Экспериментальный порог ERP-поиска: 0 — только точные названия, 1 — до одной правки в слове, 2 — рекомендуемое текущее значение. Для расстояния больше 1 сохраняется защита по длине и сходству слова, поэтому короткие пары вроде «со»/«ОС» не считаются совпадением. Суммарный лимит названия рассчитывается как N + 1, максимум изменяются два слова.';

    const addTerminologyButton = document.createElement('button');
    addTerminologyButton.type = 'button';
    addTerminologyButton.className = 'crsc-secondary crsc-add-terminology';
    addTerminologyButton.textContent = 'Добавить терминологию';
    addTerminologyButton.addEventListener('click', showAddTerminologyDialog);


    const alignGapLabel = document.createElement('label');
    alignGapLabel.textContent = 'Минимальный зазор после выравнивания задач, px';
    const alignGap = document.createElement('input');
    alignGap.type = 'number';
    alignGap.min = '0';
    alignGap.max = '500';
    alignGap.step = '5';
    alignGap.value = String(Number.isFinite(Number(settings.alignTaskMinGap)) ? settings.alignTaskMinGap : DEFAULTS.alignTaskMinGap);
    alignGapLabel.appendChild(alignGap);

    const alignGapInfo = document.createElement('div');
    alignGapInfo.className = 'crsc-modal-info';
    alignGapInfo.textContent = 'Используется только командой «Выровнять размер задач». Если между связанными элементами справа не хватает указанного расстояния, вся последующая цепочка сдвигается вправо без изменения Y. Если внутренние элементы перестают помещаться, expanded Sub-process расширяется вправо; после такого расширения вся последующая цепочка за Sub-process также сдвигается вправо, чтобы контейнер её не перекрыл. При необходимости Pool/Lane расширяются вправо с тем же запасом.';

    const quotesLabel = document.createElement('label');
    quotesLabel.className = 'crsc-checkbox-row';
    const quotes = document.createElement('input');
    quotes.type = 'checkbox';
    quotes.checked = settings.autoQuotes !== false;
    quotesLabel.append(quotes, document.createTextNode(' Автоматически заменять кавычки на «ёлочки»'));

    const spacesLabel = document.createElement('label');
    spacesLabel.className = 'crsc-checkbox-row';
    const spaces = document.createElement('input');
    spaces.type = 'checkbox';
    spaces.checked = settings.autoSpaces !== false;
    spacesLabel.append(spaces, document.createTextNode(' Автоматически убирать лишние пробелы'));

    const technicalLabel = document.createElement('label');
    technicalLabel.className = 'crsc-checkbox-row';
    const technical = document.createElement('input');
    technical.type = 'checkbox';
    technical.checked = !!settings.ignoreTechnical;
    technicalLabel.append(technical, document.createTextNode(' Игнорировать технические поля Properties Panel'));

    const ltTitle = document.createElement('div');
    ltTitle.className = 'crsc-section-title';
    ltTitle.textContent = 'LanguageTool';

    const ltEnableLabel = document.createElement('label');
    ltEnableLabel.className = 'crsc-checkbox-row';
    const ltEnable = document.createElement('input');
    ltEnable.type = 'checkbox';
    ltEnable.checked = settings.useLanguageTool === true;
    ltEnableLabel.append(ltEnable, document.createTextNode(' Использовать LanguageTool'));

    const ltHelp = document.createElement('div');
    ltHelp.className = 'crsc-modal-info';
    ltHelp.textContent = 'При отключённом LanguageTool плагин работает только на локальных правилах, терминологиях и BPMN-проверках. По умолчанию отключён.';

    const ltSourceLabel = document.createElement('label');
    ltSourceLabel.textContent = 'Источник проверки';
    const ltSource = document.createElement('select');
    ltSource.className = 'crsc-select';
    const localOpt = document.createElement('option'); localOpt.value = 'local'; localOpt.textContent = 'Локальный сервер';
    const externalOpt = document.createElement('option'); externalOpt.value = 'external'; externalOpt.textContent = 'Внешний сервер';
    ltSource.append(localOpt, externalOpt);
    ltSource.value = settings.languageToolSource === 'local' ? 'local' : 'external';
    ltSourceLabel.appendChild(ltSource);

    const localEndpoint = document.createElement('input');
    localEndpoint.type = 'text';
    localEndpoint.value = settings.localEndpoint || DEFAULTS.localEndpoint;
    localEndpoint.placeholder = DEFAULTS.localEndpoint;

    const externalEndpoint = document.createElement('input');
    externalEndpoint.type = 'text';
    externalEndpoint.value = settings.externalEndpoint || settings.endpoint || DEFAULTS.externalEndpoint;
    externalEndpoint.placeholder = DEFAULTS.externalEndpoint;

    const endpointLabel = document.createElement('label');
    endpointLabel.appendChild(document.createTextNode('Адрес сервера'));
    const endpointRow = document.createElement('div');
    endpointRow.className = 'crsc-endpoint-row';
    const endpointInputWrap = document.createElement('div');
    endpointInputWrap.className = 'crsc-endpoint-input-wrap';
    endpointInputWrap.appendChild(localEndpoint);
    endpointInputWrap.appendChild(externalEndpoint);
    const indicator = document.createElement('span');
    indicator.className = 'crsc-server-indicator crsc-server-unknown';
    indicator.title = 'Состояние сервера не проверено';
    endpointRow.append(endpointInputWrap, indicator);
    endpointLabel.appendChild(endpointRow);

    const testButton = document.createElement('button');
    testButton.type = 'button';
    testButton.className = 'crsc-secondary crsc-test-server';
    testButton.textContent = 'Проверить соединение';

    const updateLtVisibility = () => {
      const enabled = ltEnable.checked;
      const source = ltSource.value;
      ltSourceLabel.style.display = enabled ? '' : 'none';
      endpointLabel.style.display = enabled ? '' : 'none';
      testButton.style.display = enabled ? '' : 'none';
      langLabel.style.display = enabled ? '' : 'none';
      delayLabel.style.display = enabled ? '' : 'none';
      localEndpoint.style.display = enabled && source === 'local' ? '' : 'none';
      externalEndpoint.style.display = enabled && source === 'external' ? '' : 'none';
      indicator.className = `crsc-server-indicator crsc-server-unknown${enabled ? '' : ' crsc-server-disabled'}`;
      indicator.title = enabled ? 'Состояние сервера не проверено' : 'LanguageTool отключён';
    };
    const checkServer = async () => {
      if (!ltEnable.checked) return;
      indicator.className = 'crsc-server-indicator crsc-server-checking';
      indicator.title = 'Проверка доступности сервера…';
      const url = (ltSource.value === 'local' ? localEndpoint.value : externalEndpoint.value).trim();
      try {
        const params = new URLSearchParams();
        params.set('text', 'Проверка');
        params.set('language', lang.value.trim() || DEFAULTS.language);
        params.set('enabledOnly', 'false');
        const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        await response.json();
        indicator.className = 'crsc-server-indicator crsc-server-ok';
        indicator.title = 'Сервер доступен';
      } catch (_) {
        indicator.className = 'crsc-server-indicator crsc-server-error';
        indicator.title = 'Сервер недоступен';
      }
    };
    ltEnable.addEventListener('change', updateLtVisibility);
    ltSource.addEventListener('change', () => { updateLtVisibility(); checkServer(); });
    testButton.addEventListener('click', checkServer);

    const langLabel = document.createElement('label');
    langLabel.textContent = 'Язык проверки';
    const lang = document.createElement('input');
    lang.type = 'text';
    lang.value = settings.language || DEFAULTS.language;
    langLabel.appendChild(lang);

    const delayLabel = document.createElement('label');
    delayLabel.textContent = 'Задержка после ввода, мс';
    const delay = document.createElement('input');
    delay.type = 'number';
    delay.min = '250';
    delay.step = '50';
    delay.value = String(settings.delay || DEFAULTS.delay);
    delayLabel.appendChild(delay);

    const info = document.createElement('div');
    info.className = 'crsc-modal-info';
    info.textContent = 'Словари подключаются из отдельных папок dictionary/<система>/. Базовая терминология 1С:ERP 2.6 основана на предоставленных вами выгрузках.';

    const credits = document.createElement('div');
    credits.className = 'crsc-credits';
    credits.innerHTML = 'Версия <a class="crsc-version-link" href="camunda-rsc://readme" target="_blank" rel="noopener" title="Открыть README.md"><strong>0.6.33</strong></a> &nbsp;·&nbsp; Идея: <a href="internal:username_regular/PVP_IT@210607234">PVP_IT</a> &nbsp;·&nbsp; Реализация: ChatGPT';

    body.append(terminologyTitle, terminologyList, terminologyInfo,
      erpFuzzyDistanceLabel, erpFuzzyDistanceInfo, addTerminologyButton,
      alignGapLabel, alignGapInfo, quotesLabel, spacesLabel, technicalLabel,
      ltTitle, ltEnableLabel, ltHelp, ltSourceLabel, endpointLabel, testButton,
      langLabel, delayLabel, info, credits);

    const footer = document.createElement('div');
    footer.className = 'crsc-modal-footer';

    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'crsc-secondary';
    cancel.textContent = 'Отмена';
    cancel.addEventListener('click', closeSettingsDialog);

    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'crsc-primary';
    save.textContent = 'Сохранить';
    save.addEventListener('click', () => {
      settings.enabledTerminologies = Object.assign({}, settings.enabledTerminologies || {});
      terminologyChecks.forEach((checkbox, id) => { if (id !== 'user-custom') settings.enabledTerminologies[id] = checkbox.checked; });
      settings.checkErp26Documents = true;
      settings.checkErp26Catalogs = true;
      settings.erpFuzzyMaxTokenDistance = getErpFuzzyMaxTokenDistance(erpFuzzyDistance.value);
      settings.alignTaskMinGap = Math.max(0, Math.min(500, Number(alignGap.value) || 0));
      settings.autoQuotes = quotes.checked;
      settings.autoSpaces = spaces.checked;
      settings.ignoreTechnical = technical.checked;
      settings.useLanguageTool = ltEnable.checked;
      settings.languageToolSource = ltSource.value === 'local' ? 'local' : 'external';
      settings.localEndpoint = localEndpoint.value.trim() || DEFAULTS.localEndpoint;
      settings.externalEndpoint = externalEndpoint.value.trim() || DEFAULTS.externalEndpoint;
      settings.endpoint = settings.languageToolSource === 'local' ? settings.localEndpoint : settings.externalEndpoint;
      settings.language = lang.value.trim() || DEFAULTS.language;
      settings.delay = Math.max(250, Number(delay.value) || DEFAULTS.delay);
      // Enabled terminology checkboxes change the effective in-memory set.
      // Do not refetch terminology files on every keystroke; invalidate only
      // when settings actually change.
      invalidateTerminologyCache({ additional: true });
      saveSettings();
      closeSettingsDialog();
      postStatus('Настройки сохранены');
      scanFields();
      checkAll();
    });

    footer.append(cancel, save);
    modal.append(header, body, footer);
    overlay.appendChild(modal);
    overlay.addEventListener('mousedown', e => {
      if (e.target === overlay) closeSettingsDialog();
    });
    overlay.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeSettingsDialog();
    });
    document.body.appendChild(overlay);
    updateLtVisibility();
    if (ltEnable.checked) setTimeout(() => checkServer(), 0);
    setTimeout(() => ltEnable.focus(), 0);
    return overlay;
  }

  async function showSettings() {
    try { await loadTerminologyIndex(); } catch (_) {}
    createSettingsDialog();
  }

  function showHelp() {
    alert(
      'Camunda Russian Spell Checker v0.6.33\n\n' +
      'Проверяет текст в Properties Panel и при прямом редактировании подписи на canvas.\nЛокальные рекомендации управляются через подключённые терминологии и corrections.json.\n' +
      'Ошибки помечаются красной рамкой. По клику/правому клику показываются варианты замены.\n\n' +
      'LanguageTool является дополнительным движком и по умолчанию отключён. При включении можно выбрать локальный или внешний сервер.'
    );
  }

  function handleMessage(event) {
    if (!event.data || event.data.source !== SOURCE) return;
    switch (event.data.action) {
      case 'toggle': toggle(); break;
      case 'check-selected': checkSelected(); break;
      case 'check-all': checkAll(); break;
      case 'number-steps': numberDiagram(); break;
      case 'align-task-sizes': alignTaskSizes(); break;
      case 'settings': showSettings(); break;
      case 'help': showHelp(); break;
    }
  }

