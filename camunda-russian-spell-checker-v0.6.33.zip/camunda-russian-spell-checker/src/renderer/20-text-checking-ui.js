  const states = new WeakMap();
  const timers = new WeakMap();
  let popup = null;
  let popupTarget = null;
  let observer = null;

  function loadSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE) || '{}');
      const merged = Object.assign({}, DEFAULTS, saved, {
        enabledTerminologies: Object.assign({}, DEFAULTS.enabledTerminologies, saved.enabledTerminologies || {}, {
          erp26: saved.enabledTerminologies?.erp26 ?? (saved.useErp26Terminology !== false)
        }),
        dictionary: Array.isArray(saved.dictionary) ? saved.dictionary : DEFAULTS.dictionary.slice()
      });
      // Legacy settings are migration inputs only. Runtime behavior has one
      // source of truth: enabledTerminologies.erp26.
      delete merged.useErp26Terminology;
      // v0.6.29+: every BPMN step always has its own number. Ignore and remove
      // the legacy setting saved by older releases.
      delete merged.oneNumberForIdenticalActions;
      return merged;
    } catch (_) {
      return Object.assign({}, DEFAULTS, {
        dictionary: DEFAULTS.dictionary.slice()
      });
    }
  }

  function saveSettings() { localStorage.setItem(STORAGE, JSON.stringify(settings)); }

  function positionStatus() {
    const bar = document.querySelector('#crsc-toolbar');
    const el = document.querySelector('#crsc-status');
    if (!bar || !el) return;

    // Keep the status notification directly to the right of the toolbar.
    // If there is not enough room, place it to the left instead.
    const gap = 8;
    const rect = bar.getBoundingClientRect();
    const width = el.offsetWidth || 220;
    const height = el.offsetHeight || 30;
    let left = rect.right + gap;
    if (left + width > window.innerWidth - 8) {
      left = rect.left - width - gap;
    }
    left = Math.max(8, Math.min(left, window.innerWidth - width - 8));

    // Align approximately to the vertical center of the toolbar.
    let top = rect.top + (rect.height - height) / 2;
    top = Math.max(8, Math.min(top, window.innerHeight - height - 8));

    el.style.left = `${Math.round(left)}px`;
    el.style.top = `${Math.round(top)}px`;
    el.style.right = 'auto';
    el.style.bottom = 'auto';
  }

  function postStatus(text) {
    ensureStatus();
    const el = document.querySelector('#crsc-status');
    if (!el) return;
    const message = String(text || '').trim();
    el.textContent = message;
    el.classList.toggle('crsc-hidden', !message);
    if (!message) return;
    positionStatus();
    clearTimeout(postStatus.timer);
    postStatus.timer = setTimeout(() => { el.textContent = ''; el.classList.add('crsc-hidden'); }, 3500);
  }

  function panelRoot() {
    return document.querySelector('.bio-properties-panel') ||
      document.querySelector('.bio-properties-panel-container') ||
      document.querySelector('[class*="properties-panel"]');
  }

  function isInEditableCanvas(field) {
    return !!field.closest('.djs-direct-editing, .djs-direct-editing-content, .djs-overlay-container');
  }

  function isTechnicalField(field) {
    if (!settings.ignoreTechnical) return false;
    if (isInEditableCanvas(field)) return false;
    const text = [
      field.getAttribute('name'), field.getAttribute('id'), field.getAttribute('placeholder'),
      field.getAttribute('aria-label'),
      field.closest('.bio-properties-panel-group-entry, .bio-properties-panel-entry')?.textContent || ''
    ].join(' ').toLowerCase();
    const technical = [
      'job type','element id','message id','process id','version tag',
      'input mapping','output mapping','expression','feel','condition expression',
      'script format','script type','implementation','binding','task definition','connector id'
    ];
    return technical.some(x => text.includes(x)) || /(^|\s)id(\s|$)/i.test(text);
  }

  function textOfField(field) {
    if (field.isContentEditable) return field.innerText || field.textContent || '';
    return field.value || '';
  }

  function selectionOffsets(field) {
    if (!field.isContentEditable) {
      return { start: field.selectionStart ?? 0, end: field.selectionEnd ?? 0 };
    }
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount || !field.contains(sel.anchorNode)) return { start: textOfField(field).length, end: textOfField(field).length };
    const range = sel.getRangeAt(0);
    const pre = range.cloneRange();
    pre.selectNodeContents(field);
    pre.setEnd(range.startContainer, range.startOffset);
    const start = pre.toString().length;
    const preEnd = range.cloneRange();
    preEnd.selectNodeContents(field);
    preEnd.setEnd(range.endContainer, range.endOffset);
    return { start, end: preEnd.toString().length };
  }

  function restoreSelectionOffsets(field, start, end) {
    if (!field.isContentEditable) {
      try { field.setSelectionRange(start, end); } catch (_) {}
      return;
    }
    const sel = window.getSelection();
    if (!sel) return;
    const walker = document.createTreeWalker(field, NodeFilter.SHOW_TEXT);
    let node;
    let pos = 0;
    let startNode = null, endNode = null, startOffset = 0, endOffset = 0;
    while ((node = walker.nextNode())) {
      const next = pos + node.nodeValue.length;
      if (!startNode && start <= next) { startNode = node; startOffset = Math.max(0, start - pos); }
      if (!endNode && end <= next) { endNode = node; endOffset = Math.max(0, end - pos); break; }
      pos = next;
    }
    if (!startNode) { startNode = field; startOffset = field.childNodes.length; }
    if (!endNode) { endNode = startNode; endOffset = startOffset; }
    const range = document.createRange();
    range.setStart(startNode, Math.min(startOffset, startNode.nodeType === 3 ? startNode.nodeValue.length : startNode.childNodes.length));
    range.setEnd(endNode, Math.min(endOffset, endNode.nodeType === 3 ? endNode.nodeValue.length : endNode.childNodes.length));
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function setText(field, value, preserveSelection = true, selectionOverride = null) {
    const selection = selectionOverride || (preserveSelection ? selectionOffsets(field) : null);
    field.focus();
    if (field.isContentEditable) {
      field.textContent = value;
      field.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: null }));
      if (selection) restoreSelectionOffsets(field, selection.start, selection.end);
      return;
    }
    const proto = field instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(field, value);
    else field.value = value;
    field.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    field.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    if (selection) {
      try { field.setSelectionRange(selection.start, selection.end); } catch (_) {}
    }
  }

  function normalizeQuotes(text) {
    // Только парные кавычки. Незакрытую кавычку не трогаем, чтобы не мешать вводу.
    let result = String(text || '');
    result = result.replace(/"([^"\r\n]{1,1000})"/g, (_, inner) => `«${String(inner).trim()}»`);
    result = result.replace(/[“„]([^”\r\n]{1,1000})”/g, (_, inner) => `«${String(inner).trim()}»`);
    result = result.replace(/«([^»\r\n]{1,1000})»/g, (_, inner) => `«${String(inner).trim()}»`);
    // Убираем пробелы непосредственно внутри кавычек независимо от их типа.
    result = result.replace(/«[ \t\u00A0]+/gu, '«');
    result = result.replace(/[ \t\u00A0]+»/gu, '»');
    return result;
  }

  function normalizeSpaces(text) {
    // Полная нормализация для ручной проверки/потери фокуса:
    // один пробел между словами, без пробелов в начале/конце.
    return String(text || '')
      .replace(/[ \t\u00A0]+/gu, ' ')
      .replace(/[ \t]+\n/gu, '\n')
      .replace(/\n[ \t]+/gu, '\n')
      .trim();
  }

  function normalizeSpacesWhileTyping(text) {
    // Во время ввода не трогаем пробелы в конце строки: пользователь мог
    // только что поставить пробел и ещё не начал следующее слово.
    // Схлопываем только лишние пробелы между уже введёнными фрагментами,
    // то есть перед ними справа уже должен находиться непробельный символ.
    // Пример: "Создать  документ" -> "Создать документ", но
    // "Создать  " остаётся как есть до ввода следующего слова.
    return String(text || '')
      .replace(/[ \t\u00A0]{2,}(?=\S)/gu, ' ');
  }

  function mapTypingSelection(originalText, normalizedText, position) {
    const text = String(originalText || '');
    const pos = Math.max(0, Math.min(Number(position) || 0, text.length));

    // Build an exact caret mapping instead of normalizing only the prefix.
    // When a run of spaces is collapsed (e.g. "Создать  документ" ->
    // "Создать документ"), every caret position inside that collapsed run
    // maps to the single remaining space. This prevents the caret from
    // jumping one character into the next word.
    let i = 0;
    let out = 0;
    while (i < text.length) {
      const ch = text[i];
      if (/^[ \t\u00A0]$/u.test(ch)) {
        let j = i + 1;
        while (j < text.length && /^[ \t\u00A0]$/u.test(text[j])) j++;
        const runLength = j - i;
        const followedByNonSpace = j < text.length && !/^[ \t\u00A0]$/u.test(text[j]);
        const normalizedRunLength = followedByNonSpace ? 1 : runLength;

        if (pos >= i && pos <= j) {
          // If the caret is in a collapsible run, place it after the single
          // retained space (or at the end of the trailing run).
          return out + normalizedRunLength;
        }

        out += normalizedRunLength;
        i = j;
        continue;
      }

      if (pos === i) return out;
      out += 1;
      i += 1;
    }

    // If position is at/past the end.
    return normalizedText.length;
  }

  function selectionAfterSpaceNormalization(field, originalText, normalizedText) {
    const selection = selectionOffsets(field);
    return {
      start: mapTypingSelection(originalText, normalizedText, selection.start),
      end: mapTypingSelection(originalText, normalizedText, selection.end)
    };
  }

  const quoteNormalizingFields = new WeakSet();
  const spaceNormalizingFields = new WeakSet();

  function mapCaretThroughDiff(originalText, normalizedText, position) {
    const a = String(originalText || '');
    const b = String(normalizedText || '');
    const pos = Math.max(0, Math.min(Number(position) || 0, a.length));
    if (a === b) return pos;

    // Fast path: unchanged prefix/suffix. This covers the common BPMN case
    // where a user inserts a forbidden space next to a quote or at a word
    // boundary. The caret stays at the logical insertion point instead of
    // being restored by the old character index.
    let prefix = 0;
    const maxPrefix = Math.min(a.length, b.length);
    while (prefix < maxPrefix && a[prefix] === b[prefix]) prefix++;
    let suffix = 0;
    while (suffix < a.length - prefix && suffix < b.length - prefix &&
           a[a.length - 1 - suffix] === b[b.length - 1 - suffix]) suffix++;

    const oldChangedEnd = a.length - suffix;
    const newChangedEnd = b.length - suffix;
    if (pos <= prefix) return pos;
    if (pos >= oldChangedEnd) return newChangedEnd + (pos - oldChangedEnd);

    // For a caret inside a changed region, use a small edit-distance alignment
    // so deletions (such as the extra space in `« text`) map to the nearest
    // logical position in the normalized text. BPMN labels are short, so the
    // bounded matrix is inexpensive and avoids cursor jumps.
    const oldPart = a.slice(prefix, oldChangedEnd);
    const newPart = b.slice(prefix, newChangedEnd);
    const n = oldPart.length, m = newPart.length;
    if (n > 400 || m > 400) {
      return prefix;
    }

    const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = 0; i <= n; i++) dp[i][0] = i;
    for (let j = 0; j <= m; j++) dp[0][j] = j;
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        const cost = oldPart[i - 1] === newPart[j - 1] ? 0 : 1;
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost
        );
      }
    }

    const targetI = Math.max(0, Math.min(n, pos - prefix));
    let i = n, j = m;
    const boundaryMap = new Array(n + 1);
    boundaryMap[n] = m;
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0) {
        const cost = oldPart[i - 1] === newPart[j - 1] ? 0 : 1;
        if (dp[i][j] === dp[i - 1][j - 1] + cost) {
          if (boundaryMap[i - 1] == null) boundaryMap[i - 1] = j - 1;
          i--; j--; continue;
        }
      }
      if (i > 0 && dp[i][j] === dp[i - 1][j] + 1) {
        if (boundaryMap[i - 1] == null) boundaryMap[i - 1] = j;
        i--; continue;
      }
      if (j > 0) {
        j--;
        continue;
      }
      break;
    }

    let mapped = boundaryMap[targetI];
    if (mapped == null) {
      mapped = targetI;
      for (let k = targetI - 1; k >= 0; k--) {
        if (boundaryMap[k] != null) { mapped = boundaryMap[k]; break; }
      }
    }
    return prefix + Math.max(0, Math.min(m, mapped));
  }

  function selectionAfterQuoteNormalization(field, originalText, normalizedText) {
    const selection = selectionOffsets(field);
    return {
      start: mapCaretThroughDiff(originalText, normalizedText, selection.start),
      end: mapCaretThroughDiff(originalText, normalizedText, selection.end)
    };
  }

  function autoNormalizeQuotes(field, preserveSelection = true) {
    if (!settings.autoQuotes || quoteNormalizingFields.has(field)) return false;
    const current = textOfField(field);
    const normalized = normalizeQuotes(current);
    if (normalized === current) return false;
    quoteNormalizingFields.add(field);
    try {
      const selection = preserveSelection ? selectionAfterQuoteNormalization(field, current, normalized) : null;
      setText(field, normalized, !!selection, selection);
    } finally {
      quoteNormalizingFields.delete(field);
    }
    return true;
  }

  function autoNormalizeSpaces(field, whileTyping = false) {
    if (!settings.autoSpaces || spaceNormalizingFields.has(field)) return false;
    const current = textOfField(field);
    const normalized = whileTyping ? normalizeSpacesWhileTyping(current) : normalizeSpaces(current);
    if (normalized === current) return false;
    spaceNormalizingFields.add(field);
    try {
      const selection = whileTyping ? selectionAfterSpaceNormalization(field, current, normalized) : null;
      setText(field, normalized, !whileTyping, selection);
    } finally {
      spaceNormalizingFields.delete(field);
    }
    return true;
  }

  function autoNormalizeText(field, whileTyping = false) {
    if (!settings.enabled) return false;
    const spacesChanged = autoNormalizeSpaces(field, whileTyping);
    const quotesChanged = autoNormalizeQuotes(field, whileTyping);
    return spacesChanged || quotesChanged;
  }

  function normalizeBeforeCheck(field) {
    if (!settings.enabled) return false;
    if (!settings.autoSpaces && !settings.autoQuotes) return false;
    const spacesChanged = settings.autoSpaces ? autoNormalizeSpaces(field, false) : false;
    const quotesChanged = settings.autoQuotes ? autoNormalizeQuotes(field) : false;
    return spacesChanged || quotesChanged;
  }

  function isTextInput(field) {
    if (field.disabled || field.readOnly) return false;
    if (field.isContentEditable) return true;
    if (field.tagName === 'TEXTAREA') return true;
    if (field.tagName !== 'INPUT') return false;
    return ['text', 'search', 'url', ''].includes((field.type || 'text').toLowerCase());
  }

  function discoverFields() {
    const fields = [];
    const panel = panelRoot();
    if (panel) fields.push(...panel.querySelectorAll('input, textarea, [contenteditable="true"]'));

    // bpmn-js direct editing overlay used when editing a label directly on the canvas.
    fields.push(...document.querySelectorAll(
      '.djs-direct-editing input, .djs-direct-editing textarea, .djs-direct-editing [contenteditable="true"], ' +
      'input.djs-direct-editing-content, textarea.djs-direct-editing-content, [contenteditable="true"].djs-direct-editing-content'
    ));

    return Array.from(new Set(fields)).filter(field => isTextInput(field) && !isTechnicalField(field));
  }

  function debounceCheck(field) {
    clearTimeout(timers.get(field));
    const timer = setTimeout(() => checkField(field), Number(settings.delay) || 700);
    timers.set(field, timer);
  }

  function correctionMatchesForRules(text, rules) {
    const result = [];
    for (const rule of rules || []) {
      rule.pattern.lastIndex = 0;
      let match;
      while ((match = rule.pattern.exec(text))) {
        // A canonical spelling must never be reported as an error merely
        // because it is also listed among accepted variants (e.g. Power BI).
        if (match[0] === rule.replacement) {
          if (match[0].length === 0) rule.pattern.lastIndex++;
          continue;
        }
        const start = match.index;
        const end = start + match[0].length;
        const overlapsHigherPriority = result.some(existing =>
          start < existing.offset + existing.length && existing.offset < end
        );
        if (overlapsHigherPriority) continue;

        result.push({
          offset: match.index,
          length: match[0].length,
          message: rule.message,
          replacements: [{ value: rule.replacement }],
          rule: { issueType: 'misspelling', category: { id: 'CASING' } },
          _localCorrection: true,
          _correctionId: rule.id,
          _category: rule.category
        });
        if (match[0].length === 0) rule.pattern.lastIndex++;
      }
    }
    return result;
  }

  function localCorrectionMatches(text) {
    return correctionMatchesForRules(text, correctionRules);
  }

  const MATCH_PRIORITY = Object.freeze({
    TERMINOLOGY: 10,
    CORRECTION: 20,
    BPMN: 30,
    LANGUAGETOOL: 100
  });

  function matchPriority(match) {
    if (match?._erp26 || match?._terminology) return MATCH_PRIORITY.TERMINOLOGY;
    if (match?._bpmnNaming) return MATCH_PRIORITY.BPMN;
    if (match?._localCorrection) return MATCH_PRIORITY.CORRECTION;
    return MATCH_PRIORITY.LANGUAGETOOL;
  }

  function resolveMatchConflicts(matches) {
    const ranked = (matches || []).map((match, order) => ({ match, order }))
      .sort((a, b) =>
        (matchPriority(a.match) - matchPriority(b.match)) ||
        (a.match.offset - b.match.offset) ||
        (b.match.length - a.match.length) ||
        (a.order - b.order)
      );
    const accepted = [];
    for (const item of ranked) {
      const match = item.match;
      const start = Number(match?.offset) || 0;
      const end = start + Math.max(0, Number(match?.length) || 0);
      const overlapsHigherPriority = accepted.some(existing => {
        const existingStart = Number(existing.offset) || 0;
        const existingEnd = existingStart + Math.max(0, Number(existing.length) || 0);
        return start < existingEnd && existingStart < end;
      });
      if (!overlapsHigherPriority) accepted.push(match);
    }
    return accepted.sort((a, b) => (a.offset - b.offset) || (matchPriority(a) - matchPriority(b)));
  }

  function mergeMatches(localMatches, languageToolMatches, text) {
    return resolveMatchConflicts([...(localMatches || []), ...(languageToolMatches || [])]);
  }

  function isCanvasTextContext(field) {
    return !!field && isInEditableCanvas(field);
  }

  function isBpmnActivityElement(element) {
    const bo = element?.businessObject;
    if (!bo) return false;
    try {
      if (typeof bo.$instanceOf === 'function') return bo.$instanceOf('bpmn:Activity');
    } catch (_) {}
    const type = String(bo.$type || '');
    return type === 'bpmn:SubProcess' || type === 'bpmn:CallActivity' || /Task$/u.test(type);
  }

  function currentBpmnElementForField(field) {
    if (!isCanvasTextContext(field)) return null;
    const service = getNumberingService();
    const selected = Array.isArray(service?.currentSelection) ? service.currentSelection : [];
    return selected.length === 1 ? selected[0] : null;
  }

  function isBpmnNamingContext(context = {}) {
    const field = context.field;
    if (!isCanvasTextContext(field)) return false;
    const element = context.element || currentBpmnElementForField(field);
    return isBpmnActivityElement(element);
  }

  function ignoredUserTermRanges(text, terms = userCustomTerms) {
    const source = String(text || '');
    const lower = source.toLocaleLowerCase('ru-RU');
    const ranges = [];
    for (const rawTerm of terms || []) {
      const term = String(rawTerm || '').trim();
      if (!term) continue;
      const needle = term.toLocaleLowerCase('ru-RU');
      let from = 0;
      while (from <= lower.length - needle.length) {
        const index = lower.indexOf(needle, from);
        if (index < 0) break;
        ranges.push({ start: index, end: index + term.length });
        from = index + Math.max(1, needle.length);
      }
    }
    return ranges;
  }

  function filterIgnoredUserTermMatches(matches, text, terms = userCustomTerms) {
    if (!Array.isArray(matches) || !matches.length || !Array.isArray(terms) || !terms.length) return matches || [];
    const ranges = ignoredUserTermRanges(text, terms);
    if (!ranges.length) return matches;
    return matches.filter(match => {
      const start = Number(match?.offset) || 0;
      const end = start + Math.max(0, Number(match?.length) || 0);
      return !ranges.some(range => start >= range.start && end <= range.end);
    });
  }

  async function getMatches(text, context = {}) {
    await loadCorrections();
    await loadTerminologyIndex();
    await loadErp26Dictionary();
    await loadAdditionalTerminologies();
    await loadUserCustomTerms();
    if (isBpmnNamingContext(context)) await loadBpmnNamingRules();

    let localMatches = [
      ...erp26Matches(text),
      ...additionalTerminologyMatches(text),
      ...localCorrectionMatches(text),
      ...(isBpmnNamingContext(context) ? bpmnNamingMatches(text) : [])
    ];
    localMatches = filterIgnoredUserTermMatches(localMatches, text);
    localMatches = resolveMatchConflicts(localMatches);

    if (!settings.useLanguageTool) return localMatches;
    try {
      let languageToolMatches = filterMatches(await checkLanguageTool(text), text);
      languageToolMatches = filterIgnoredUserTermMatches(languageToolMatches, text);
      return mergeMatches(localMatches, languageToolMatches, text);
    } catch (error) {
      if (localMatches.length) return localMatches;
      throw error;
    }
  }

  async function checkField(field, force) {
    if (!settings.enabled) return;
    const text = textOfField(field).trim();
    if (!text || text.length < 2) {
      clearError(field);
      hidePopupFor(field);
      return;
    }
    if (text.length > 60000) return;

    const requestText = text;
    states.set(field, { text: requestText, checking: true });
    if (force) showWorking(field);

    try {
      const matches = await getMatches(requestText, { field });
      if (textOfField(field).trim() !== requestText) return;
      states.set(field, { text: requestText, matches, checking: false });
      setError(field, matches.length > 0);
      if (matches.length) showMatches(field, matches, requestText);
      else if (popupTarget === field) hidePopupFor(field);
    } catch (error) {
      states.set(field, { text: requestText, matches: [], checking: false, error });
      setError(field, false);
      if (force && settings.useLanguageTool) postStatus('Не удалось подключиться к LanguageTool');
      if (force) hidePopupFor(field);
    }
  }

  async function checkAll() {
    if (!settings.enabled) { postStatus('Проверка выключена. Включите её кнопкой А×.'); return; }
    const fields = discoverFields();
    if (!fields.length) {
      postStatus('Нет видимых текстовых полей для проверки.');
      return;
    }
    let errors = 0;
    postStatus('Проверка видимых полей…');
    for (const field of fields) {
      try {
        normalizeBeforeCheck(field);
        const text = textOfField(field).trim();
        if (!text) continue;
        const matches = await getMatches(text, { field });
        states.set(field, { text, matches, checking: false });
        setError(field, matches.length > 0);
        errors += matches.length;
      } catch (_) {}
    }
    postStatus(errors ? `Найдено ошибок/замечаний: ${errors}` : 'Ошибок не найдено');
  }

  function effectiveDictionary() {
    const terms = new Set((settings.dictionary || []).map(String));
    for (const term of userCustomTerms || []) terms.add(String(term));
    for (const entry of terminologyTerms.values()) {
      if (terminologyEnabled(entry.id)) {
        for (const term of entry.terms || []) terms.add(String(term));
      }
    }
    return Array.from(terms);
  }

  function languageToolEndpoint() {
    if (settings.languageToolSource === 'local') return settings.localEndpoint || DEFAULTS.localEndpoint;
    return settings.externalEndpoint || settings.endpoint || DEFAULTS.externalEndpoint;
  }

  async function checkLanguageTool(text) {
    if (!settings.useLanguageTool) return [];
    const params = new URLSearchParams();
    params.set('text', text);
    params.set('language', settings.language || 'ru-RU');
    params.set('enabledOnly', 'false');
    const dictionary = effectiveDictionary();
    if (dictionary.length) params.set('ignore', dictionary.join(', '));

    const response = await fetch(languageToolEndpoint(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    return Array.isArray(json.matches) ? json.matches : [];
  }

  function filterMatches(matches, text) {
    const dict = new Set(effectiveDictionary().map(x => x.toLowerCase()));
    return matches.filter(m => {
      const bad = text.slice(m.offset, m.offset + m.length);
      if (!bad || dict.has(bad.toLowerCase())) return false;
      const replacements = Array.from(new Set((m.replacements || []).map(r => (r.value || '').trim()).filter(Boolean)));
      const issueType = m.rule?.issueType || '';
      const category = m.rule?.category?.id || '';
      if (!replacements.length) return false;
      return issueType !== 'style' || category === 'CASING';
    });
  }

  function createPopup() {
    if (popup) return popup;
    popup = document.createElement('div');
    popup.id = 'crsc-popup';
    popup.addEventListener('mousedown', e => e.preventDefault());
    document.body.appendChild(popup);
    return popup;
  }

  function positionPopup(field) {
    const rect = field.getBoundingClientRect();
    const p = createPopup();
    const width = Math.min(390, Math.max(280, window.innerWidth - 16));
    const maxLeft = Math.max(8, window.innerWidth - width - 8);
    p.style.width = `${Math.min(390, width)}px`;
    p.style.left = `${Math.min(Math.max(8, rect.left), maxLeft)}px`;
    const height = p.offsetHeight || 120;
    const below = rect.bottom + 6;
    const top = below + height < window.innerHeight ? below : rect.top - height - 6;
    p.style.top = `${Math.max(8, top)}px`;
  }

  function showWorking(field) {
    popupTarget = field;
    const p = createPopup();
    p.innerHTML = '<div class="crsc-title">Проверка…</div>';
    p.classList.add('crsc-visible');
    positionPopup(field);
  }

  function showMatches(field, matches, text) {
    popupTarget = field;
    const p = createPopup();
    p.innerHTML = '';

    const title = document.createElement('div');
    title.className = 'crsc-title';
    title.textContent = `Найдено: ${matches.length}`;
    p.appendChild(title);

    matches.slice(0, 10).forEach(m => {
      const row = document.createElement('div');
      row.className = 'crsc-match';

      const bad = text.slice(m.offset, m.offset + m.length);
      const msg = document.createElement('div');
      msg.className = 'crsc-message';
      msg.innerHTML = '';
      const wrong = document.createElement('span');
      wrong.className = 'crsc-wrong';
      wrong.textContent = bad;
      msg.appendChild(wrong);
      const explanation = document.createElement('span');
      explanation.textContent = ` — ${m.message || 'возможная ошибка'}`;
      msg.appendChild(explanation);
      row.appendChild(msg);

      const reps = document.createElement('div');
      reps.className = 'crsc-replacements';
      (m.replacements || []).slice(0, 6).forEach(rep => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'crsc-replace';
        b.textContent = rep.value;
        b.title = 'Заменить';
        b.addEventListener('click', () => applyReplacement(field, m, rep.value));
        reps.appendChild(b);
      });
      row.appendChild(reps);

      const ignore = document.createElement('button');
      ignore.type = 'button';
      ignore.className = 'crsc-ignore';
      ignore.textContent = 'Игнорировать слово';
      ignore.addEventListener('click', () => addToDictionary(bad, field));
      row.appendChild(ignore);

      p.appendChild(row);
    });

    if (matches.length > 10) {
      const more = document.createElement('div');
      more.className = 'crsc-more';
      more.textContent = `и ещё ${matches.length - 10}…`;
      p.appendChild(more);
    }

    p.classList.add('crsc-visible');
    positionPopup(field);
  }

  function applyReplacement(field, match, replacement) {
    const current = textOfField(field);
    // Ignore stale popup entries if the field changed.
    if (match.offset < 0 || match.offset + match.length > current.length) return;
    const before = current.slice(0, match.offset);
    const after = current.slice(match.offset + match.length);
    setText(field, before + replacement + after);
    clearError(field);
    hidePopupFor(field);
    debounceCheck(field);
  }

  function addToDictionary(word, field) {
    const clean = String(word || '').trim();
    if (!clean) return;
    loadUserCustomTerms().then(() => {
      userCustomTerms = Array.from(new Set([...(userCustomTerms || []), clean]));
      sendTerminologyOperation({ op: 'update-user-custom', terms: userCustomTerms });
    });
    postStatus(`Добавлено в пользовательские исключения: ${clean}`);
    checkField(field, true);
  }

  function setError(field, hasError) {
    field.classList.toggle('crsc-field-error', hasError);
    field.classList.toggle('crsc-field-ok', !hasError && !!textOfField(field).trim());
    if (hasError) field.setAttribute('data-crsc-error', 'true');
    else field.removeAttribute('data-crsc-error');
  }

  function clearError(field) {
    field.classList.remove('crsc-field-error', 'crsc-field-ok');
    field.removeAttribute('data-crsc-error');
    states.delete(field);
  }

  function hidePopupFor(field) {
    if (!popup || (field && popupTarget !== field)) return;
    popup.classList.remove('crsc-visible');
    popupTarget = null;
  }

  function bindField(field) {
    if (field.dataset.crscBound === '1') return;
    field.dataset.crscBound = '1';

    field.addEventListener('input', () => {
      // Кавычки можно нормализовать сразу. Пробелы во время ввода схлопываем
      // без удаления одиночного пробела в конце, чтобы курсор не перескакивал.
      autoNormalizeText(field, true);
      clearError(field);
      hidePopupFor(field);
      debounceCheck(field);
    });

    field.addEventListener('focus', () => {
      const state = states.get(field);
      if (state?.matches?.length) showMatches(field, state.matches, state.text);
      else debounceCheck(field);
    });

    field.addEventListener('contextmenu', () => {
      const state = states.get(field);
      if (state?.matches?.length) {
        setTimeout(() => showMatches(field, state.matches, state.text), 0);
      }
    });

    field.addEventListener('blur', () => {
      if (settings.enabled && (settings.autoSpaces || settings.autoQuotes)) normalizeBeforeCheck(field);
      setTimeout(() => hidePopupFor(field), 220);
    });
    field.addEventListener('keydown', e => {
      if (e.key === 'Escape') hidePopupFor(field);
    });
  }

  function scanFields() {
    discoverFields().forEach(bindField);
  }

  function checkSelected() {
    if (!settings.enabled) { postStatus('Проверка выключена. Включите её кнопкой А×.'); return; }
    const fields = discoverFields();
    const focused = document.activeElement;
    if (focused && fields.includes(focused)) {
      normalizeBeforeCheck(focused);
      checkField(focused, true);
      return;
    }
    if (fields.length) {
      normalizeBeforeCheck(fields[0]);
      checkField(fields[0], true);
    } else postStatus('Выберите элемент BPMN или начните редактирование подписи на canvas.');
  }

  function toggle() {
    settings.enabled = !settings.enabled;
    saveSettings();
    updateToolbar();
    document.documentElement.classList.toggle('crsc-disabled', !settings.enabled);
    if (!settings.enabled) {
      discoverFields().forEach(clearError);
      hidePopupFor();
    }
    postStatus(settings.enabled ? 'Проверка орфографии включена' : 'Проверка орфографии выключена');
  }

  function updateToolbar() {
    const btn = document.querySelector('#crsc-toggle');
    if (btn) {
      btn.classList.toggle('crsc-on', !!settings.enabled);
      btn.classList.toggle('crsc-off', !settings.enabled);
      btn.textContent = settings.enabled ? 'А✓' : 'А×';
    }
  }

  function ensureToolbar() {
    if (document.querySelector('#crsc-toolbar')) return;
    const bar = document.createElement('div');
    bar.id = 'crsc-toolbar';
    const btn = document.createElement('button');
    btn.type = 'button'; btn.id = 'crsc-toggle'; btn.title = 'Включить/выключить (Ctrl+Shift+L)';
    btn.addEventListener('click', toggle);
    const check = document.createElement('button');
    check.type = 'button'; check.id = 'crsc-check'; check.textContent = 'Проверить';
    check.title = 'Проверить текущее поле'; check.addEventListener('click', checkSelected);
    const all = document.createElement('button');
    all.type = 'button'; all.id = 'crsc-all'; all.textContent = 'Все';
    all.title = 'Проверить все видимые поля'; all.addEventListener('click', checkAll);
    const numberBtn = document.createElement('button');
    numberBtn.type = 'button'; numberBtn.id = 'crsc-number'; numberBtn.textContent = 'Нумеровать';
    numberBtn.title = 'Автоматически пронумеровать шаги BPMN'; numberBtn.addEventListener('click', numberDiagram);
    const alignBtn = document.createElement('button');
    alignBtn.type = 'button'; alignBtn.id = 'crsc-resize'; alignBtn.textContent = '↔';
    alignBtn.title = 'Выровнять размер задач'; alignBtn.addEventListener('click', alignTaskSizes);
    const settingsBtn = document.createElement('button');
    settingsBtn.type = 'button'; settingsBtn.id = 'crsc-settings'; settingsBtn.textContent = '⚙';
    settingsBtn.title = 'Настройки'; settingsBtn.addEventListener('click', showSettings);
    bar.append(btn, check, all, numberBtn, alignBtn, settingsBtn);
    document.body.appendChild(bar);
    updateToolbar();
  }

  function ensureStatus() {
    if (document.querySelector('#crsc-status')) return;
    const el = document.createElement('div'); el.id = 'crsc-status'; el.classList.add('crsc-hidden'); document.body.appendChild(el);
  }

