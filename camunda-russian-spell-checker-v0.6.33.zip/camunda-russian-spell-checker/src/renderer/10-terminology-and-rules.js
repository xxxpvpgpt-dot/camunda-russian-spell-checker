  async function loadCorrections() {
    if (correctionsLoaded) return correctionRules;

    const candidates = [];
    try {
      const pluginDir = typeof getPluginsDirectory === 'function' ? getPluginsDirectory() : getPluginsDirectory;
      if (pluginDir) candidates.push(String(pluginDir).replace(/\/$/, '') + '/camunda-russian-spell-checker/corrections.json');
    } catch (_) {}
    candidates.push('./corrections.json');

    for (const url of candidates) {
      try {
        const response = await fetch(url);
        if (!response.ok) continue;
        const json = await response.json();
        correctionRules = compileCorrectionRules(json && Array.isArray(json.rules) ? json.rules : []);
        correctionsLoaded = true;
        return correctionRules;
      } catch (_) {}
    }

    // Минимальный резервный набор, если corrections.json временно недоступен.
    correctionRules = compileCorrectionRules([
      { id: '1c-ut-basic', category: '1С', variants: ['1CУТ', '1СУТ', '1C УТ', '1С УТ'], replacement: '1С:УТ', message: 'Рекомендуемое написание продукта 1С:Управление торговлей' },
      { id: '1c-erp-basic', category: '1С', variants: ['1C ERP', '1С ERP', '1C:ERP'], replacement: '1С:ERP', message: 'Рекомендуемое написание продукта 1С:ERP' },
      { id: '1c-ukh-basic', category: '1С', variants: ['1C УХ', '1С УХ', '1C:УХ'], replacement: '1С:УХ', message: 'Рекомендуемое написание продукта 1С:Управление холдингом' }
    ]);
    correctionsLoaded = true;
    return correctionRules;
  }

  async function loadTerminologyIndex() {
    if (terminologyIndexLoaded) return terminologyIndex;
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');

    for (const base of Array.from(new Set(bases))) {
      try {
        const response = await fetch(base + 'index.json', { cache: 'no-store' });
        if (!response.ok) continue;
        const json = await response.json();
        if (Array.isArray(json?.terminologies)) {
          terminologyIndex = json.terminologies.filter(x => x && x.id && x.name && x.folder);
          break;
        }
      } catch (_) {}
    }

    // Compatibility fallback for versions where the index is unavailable.
    if (!terminologyIndex.some(x => x.id === 'erp26')) {
      terminologyIndex.unshift({
        id: 'erp26', name: '1С:ERP 2.6', folder: 'erp26', builtIn: true,
        category: 'системная', files: ['erp26-documents.json', 'erp26-catalogs.json']
      });
    }

    terminologyIndexLoaded = true;
    return terminologyIndex;
  }

  function terminologyEnabled(id) {
    if (id === 'erp26') return settings.enabledTerminologies?.erp26 !== false;
    return settings.enabledTerminologies?.[id] !== false;
  }

  async function loadErp26Dictionary() {
    if (erp26Loaded) return;

    // Important: spellchecker.js is loaded by Camunda as a plugin resource.
    // Relative fetch('./dictionary/...') resolves against the Modeler page,
    // not necessarily against the plugin folder. Use the captured script URL
    // first, then a few compatibility fallbacks.
    const baseCandidates = [];
    if (PLUGIN_BASE_URL) baseCandidates.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);

    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) baseCandidates.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}

    baseCandidates.push('./dictionary/');
    baseCandidates.push('../dictionary/');


    const erp26BaseCandidates = baseCandidates.map(base => base.endsWith('/') ? base + 'erp26/' : base + '/erp26/');
    async function loadFileFromBases(bases, fileName) {
      const tried = new Set();
      for (const base of bases) {
        if (!base || tried.has(base)) continue;
        tried.add(base);
        try {
          const response = await fetch(base + fileName, { cache: 'no-store' });
          if (!response.ok) continue;
          const json = await response.json();
          if (Array.isArray(json?.objects)) return json.objects;
        } catch (_) {}
      }
      return [];
    }
    erp26Documents = await loadFileFromBases(erp26BaseCandidates, 'erp26-documents.json');
    erp26Catalogs = await loadFileFromBases(erp26BaseCandidates, 'erp26-catalogs.json');
    await loadTerminologyIndex();
    await loadAdditionalTerminologies();
    buildErp26Index();
    erp26Loaded = true;

    // Expose a tiny diagnostic for the settings dialog / troubleshooting.
    window.__crscErp26Stats = {
      documents: erp26Documents.length,
      catalogs: erp26Catalogs.length,
      total: erp26Documents.length + erp26Catalogs.length,
      loaded: erp26Documents.length > 0 || erp26Catalogs.length > 0
    };
  }

  async function loadAdditionalTerminologies(force = false) {
    if (terminologyTermsLoaded && !force) return terminologyTerms;
    terminologyTerms = new Map();
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');

    const unique = Array.from(new Map(terminologyIndex.map(x => [x.id, x])).values());
    for (const entry of unique) {
      if (entry.id === 'erp26' || !terminologyEnabled(entry.id)) continue;
      for (const base of Array.from(new Set(bases))) {
        try {
          const response = await fetch(base + `${entry.folder}/terminology.json`, { cache: 'no-store' });
          if (!response.ok) continue;
          const json = await response.json();
          const terms = Array.isArray(json?.terms) ? json.terms.filter(Boolean).map(String) : [];
          terminologyTerms.set(entry.id, {
            ...entry,
            category: json.category || entry.category || 'прочее',
            terms
          });
          break;
        } catch (_) {}
      }
    }
    terminologyTermsLoaded = true;
    return terminologyTerms;
  }

  function invalidateTerminologyCache(options = {}) {
    if (options.index) terminologyIndexLoaded = false;
    if (options.additional !== false) {
      terminologyTermsLoaded = false;
      terminologyTerms = new Map();
    }
    if (options.userCustom) {
      userCustomLoaded = false;
      userCustomTerms = [];
    }
    if (options.erp) erp26Loaded = false;
  }

  async function loadTerminologyEntry(id) {
    await loadTerminologyIndex();
    const entry = terminologyIndex.find(x => x && x.id === id);
    if (!entry || entry.id === 'erp26') return entry || null;

    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');

    for (const base of Array.from(new Set(bases))) {
      try {
        const response = await fetch(base + `${entry.folder}/terminology.json`, { cache: 'no-store' });
        if (!response.ok) continue;
        const json = await response.json();
        return {
          ...entry,
          category: json.category || entry.category || 'Прочее',
          terms: Array.isArray(json?.terms) ? json.terms.filter(Boolean).map(String) : []
        };
      } catch (_) {}
    }
    return { ...entry, terms: [] };
  }

  async function loadUserCustomTerms() {
    if (userCustomLoaded) return userCustomTerms;
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(new URL('./dictionary/', PLUGIN_BASE_URL).href);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script && script.src) bases.push(new URL('./dictionary/', script.src).href);
    } catch (_) {}
    bases.push('./dictionary/');
    bases.push('../dictionary/');
    for (const base of bases) {
      try {
        const response = await fetch(base + 'User-custom-terms.json', { cache: 'no-store' });
        if (!response.ok) continue;
        const json = await response.json();
        if (Array.isArray(json?.terms)) { userCustomTerms = json.terms.filter(Boolean).map(String); break; }
      } catch (_) {}
    }
    userCustomLoaded = true;
    return userCustomTerms;
  }


  function erpTokens(value) {
    return String(value || '')
      .toLocaleLowerCase('ru-RU')
      .replace(/[«»"“”„’'()\[\]{}:;,!?]/gu, ' ')
      .split(/\s+/u)
      .filter(Boolean);
  }

  function editDistance(a, b) {
    const x = String(a), y = String(b);
    if (x === y) return 0;
    if (!x.length) return y.length;
    if (!y.length) return x.length;
    const prev = Array.from({ length: y.length + 1 }, (_, i) => i);
    for (let i = 1; i <= x.length; i++) {
      const cur = [i];
      for (let j = 1; j <= y.length; j++) {
        cur[j] = Math.min(
          cur[j - 1] + 1,
          prev[j] + 1,
          prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1)
        );
      }
      for (let j = 0; j <= y.length; j++) prev[j] = cur[j];
    }
    return prev[y.length];
  }

  function buildErp26Index() {
    erp26Index = new Map();
    erp26DocumentBuckets = new Map();
    for (const obj of [...erp26Documents.map(x => ({ ...x, objectType: 'Документ' })), ...erp26Catalogs.map(x => ({ ...x, objectType: 'Справочник' }))]) {
      const tokens = erpTokens(obj.name);
      if (tokens.length < 2) continue;
      const enriched = { ...obj, tokens };
      const key = tokens[0];
      if (!erp26Index.has(key)) erp26Index.set(key, []);
      erp26Index.get(key).push(enriched);
      if (obj.objectType === 'Документ') {
        if (!erp26DocumentBuckets.has(tokens.length)) erp26DocumentBuckets.set(tokens.length, []);
        erp26DocumentBuckets.get(tokens.length).push(enriched);
      }
    }
  }

  function normalizeErpDocumentTitle(value) {
    return String(value || '')
      .replace(/[\u00A0\t\r\n]+/gu, ' ')
      .replace(/ +/gu, ' ')
      .trim()
      .toLocaleLowerCase('ru-RU');
  }

  // Return all balanced «...» spans. Nested guillemets are supported,
  // e.g. «Заказ на перемещение ... «Солнцерево»».
  function guillemetSpans(text) {
    const source = String(text || '');
    const stack = [];
    const spans = [];
    for (let i = 0; i < source.length; i++) {
      if (source[i] === '«') {
        stack.push(i);
      } else if (source[i] === '»' && stack.length) {
        const start = stack.pop();
        if (i > start + 1) {
          spans.push({ start, end: i + 1, contentStart: start + 1, contentEnd: i });
        }
      }
    }
    return spans.sort((a, b) => a.start - b.start || b.end - a.end);
  }

  function getErpFuzzyMaxTokenDistance(value = settings.erpFuzzyMaxTokenDistance) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return DEFAULTS.erpFuzzyMaxTokenDistance;
    return Math.max(0, Math.min(5, Math.round(numeric)));
  }

  function erp26CandidatesByFirstToken(firstToken, objectType, maxTokenDistance = getErpFuzzyMaxTokenDistance()) {
    const first = String(firstToken || '').toLocaleLowerCase('ru-RU');
    if (!first) return [];
    const exact = (erp26Index.get(first) || []).filter(candidate => candidate.objectType === objectType);
    if (exact.length) return exact;

    const result = [];
    for (const [key, candidates] of erp26Index.entries()) {
      const distance = editDistance(first, key);
      if (!acceptableTerminologyTokenDistance(first, key, distance, maxTokenDistance)) continue;
      for (const candidate of candidates) {
        if (candidate.objectType === objectType) result.push(candidate);
      }
    }
    return result;
  }

  function erp26DocumentCandidates(content) {
    const tokens = erpTokens(content);
    if (tokens.length < 2 || !settings.checkErp26Documents) return [];
    // Documents are matched by the COMPLETE quoted phrase. Do not pre-filter
    // by the first token: a typo in the first word must not disable ERP lookup.
    return (erp26DocumentBuckets.get(tokens.length) || []).slice();
  }

  function acceptableTerminologyTokenDistance(actualToken, candidateToken, distance, maxTokenDistance = getErpFuzzyMaxTokenDistance()) {
    const limit = getErpFuzzyMaxTokenDistance(maxTokenDistance);
    if (distance < 0 || distance > limit) return false;
    if (distance <= 1) return true;

    // When the experimental limit is raised, keep a safety barrier for distance > 1.
    // This allows long inflected/typo variants while short pairs like «со»/«ОС»
    // remain rejected even at a permissive setting.
    const actual = String(actualToken || '');
    const candidate = String(candidateToken || '');
    const maxLength = Math.max(actual.length, candidate.length, 1);
    const minLength = Math.min(actual.length, candidate.length);
    const similarity = 1 - (distance / maxLength);
    return maxLength >= 7 && minLength >= 5 && similarity >= 0.72;
  }

  function scoreErpDocumentCandidate(actualTokens, candidateTokens, maxTokenDistance = getErpFuzzyMaxTokenDistance()) {
    if (!Array.isArray(actualTokens) || !Array.isArray(candidateTokens) ||
        actualTokens.length !== candidateTokens.length || actualTokens.length < 2) return null;

    const distances = actualTokens.map((value, idx) => editDistance(value, candidateTokens[idx]));
    if (distances.every(d => d === 0)) {
      return { exact: true, total: 0, changed: 0, exactTokens: actualTokens.length, similarity: 1 };
    }

    const limit = getErpFuzzyMaxTokenDistance(maxTokenDistance);
    if (distances.some((distance, idx) =>
      !acceptableTerminologyTokenDistance(actualTokens[idx], candidateTokens[idx], distance, limit)
    )) return null;

    const total = distances.reduce((sum, d) => sum + d, 0);
    const changed = distances.filter(d => d !== 0).length;
    const exactTokens = actualTokens.length - changed;

    // The setting controls one word. Keep the whole name conservative: no more
    // than two changed words and a total edit budget of N + 1. Default N=2
    // therefore preserves the v0.6.31 total budget of 3.
    const maxTotalDistance = Math.max(1, limit + 1);
    if (total < 1 || total > maxTotalDistance || changed > 2) return null;

    // For longer names, keep at least half the words exact. Two-word ERP names
    // are common and may legitimately have one changed form in each token.
    if (actualTokens.length > 2 && exactTokens < Math.ceil(actualTokens.length / 2)) return null;

    let chars = 0;
    let edits = 0;
    for (let i = 0; i < actualTokens.length; i++) {
      chars += Math.max(actualTokens[i].length, candidateTokens[i].length, 1);
      edits += distances[i];
    }
    const similarity = chars ? 1 - (edits / chars) : 0;
    return { exact: false, total, changed, exactTokens, similarity };
  }

  function rankErpDocumentCandidates(content, candidates, maxTokenDistance = getErpFuzzyMaxTokenDistance()) {
    const actualTokens = erpTokens(content);
    if (actualTokens.length < 2) return [];
    const normalized = normalizeErpDocumentTitle(content);
    const ranked = [];

    for (const candidate of candidates || []) {
      if (!candidate || !candidate.name) continue;
      if (normalizeErpDocumentTitle(candidate.name) === normalized) return [];
      const candidateTokens = Array.isArray(candidate.tokens) ? candidate.tokens : erpTokens(candidate.name);
      const score = scoreErpDocumentCandidate(actualTokens, candidateTokens, maxTokenDistance);
      if (!score || score.exact) continue;
      ranked.push({ candidate, ...score });
    }

    ranked.sort((a, b) =>
      (a.total - b.total) ||
      (b.exactTokens - a.exactTokens) ||
      (b.similarity - a.similarity) ||
      String(a.candidate.name).localeCompare(String(b.candidate.name), 'ru-RU')
    );
    if (!ranked.length) return [];

    const best = ranked[0];
    // Show several variants only when they are genuinely tied with the best
    // candidate. Do not flood the popup with merely possible ERP objects.
    return ranked.filter(item =>
      item.total === best.total &&
      item.exactTokens === best.exactTokens &&
      Math.abs(item.similarity - best.similarity) <= 0.02
    ).slice(0, 3);
  }

  function exactErp26DocumentInQuote(content) {
    const normalized = normalizeErpDocumentTitle(content);
    if (!normalized) return null;

    const candidates = erp26DocumentCandidates(content);
    if (!candidates.length) return null;

    // Only a FULL match of the complete text inside «...» counts as an
    // exact ERP document name. Extra words mean this is no longer an exact
    // object name and must not suppress the whole-phrase fuzzy logic.
    const exact = candidates.find(candidate => normalizeErpDocumentTitle(candidate.name) === normalized);
    return exact ? { candidate: exact, mode: 'exact' } : null;
  }

  function fuzzyQuotedDocumentMatches(content, absoluteOffset) {
    const ranked = rankErpDocumentCandidates(content, erp26DocumentCandidates(content));
    if (!ranked.length) return [];

    const candidates = ranked.map(item => item.candidate);
    const replacements = Array.from(new Set(candidates.map(candidate => candidate.name)))
      .map(value => ({ value }));
    const message = candidates.length === 1
      ? `Похоже на документ 1С: «${candidates[0].name}». Рекомендуется точное название объекта.`
      : `Похоже на документ 1С. Найдено несколько равноценных вариантов терминологии.`;

    return [{
      offset: absoluteOffset,
      length: String(content || '').length,
      message,
      replacements,
      rule: { issueType: 'misspelling', category: { id: 'ERP26_DOCUMENT' } },
      _localCorrection: true,
      _erp26: true,
      _erpObjectType: 'Документ',
      _erpInternalName: candidates.map(candidate => candidate.internalName).filter(Boolean).join('|'),
      _category: '1С:ERP 2.6'
    }];
  }

  function erp26DocumentMatchesInQuotes(text) {
    if (!terminologyEnabled('erp26') || !settings.checkErp26Documents) return [];
    const source = String(text || '');
    const spans = guillemetSpans(source);
    const matches = [];
    const seen = new Set();

    for (const span of spans) {
      const content = source.slice(span.contentStart, span.contentEnd);
      const recognized = exactErp26DocumentInQuote(content);
      if (recognized) continue;

      const fuzzy = fuzzyQuotedDocumentMatches(content, span.contentStart);
      for (const match of fuzzy) {
        const signature = `${match.offset}:${match.length}:${match._erpInternalName}`;
        if (seen.has(signature)) continue;
        seen.add(signature);
        matches.push(match);
      }
    }

    return matches.sort((a, b) => a.offset - b.offset);
  }

  function erp26CatalogMatches(text) {
    if (!terminologyEnabled('erp26') || !settings.checkErp26Catalogs) return [];
    const source = String(text || '');
    const words = [];
    const re = /[\p{L}\p{N}][\p{L}\p{N}_-]*/gu;
    let m;
    while ((m = re.exec(source))) words.push({ value: m[0], index: m.index });
    const matches = [];
    const seen = new Set();

    // Catalogs keep the previous token-window behavior. Document matching is
    // deliberately handled separately and only for the complete quoted phrase.
    for (let i = 0; i < words.length; i++) {
      const key = words[i].value.toLocaleLowerCase('ru-RU');
      const maxTokenDistance = getErpFuzzyMaxTokenDistance();
      const candidates = erp26CandidatesByFirstToken(key, 'Справочник', maxTokenDistance);
      if (!candidates.length) continue;
      for (const candidate of candidates) {
        const n = candidate.tokens.length;
        if (i + n > words.length) continue;
        const windowWords = words.slice(i, i + n);
        const actualTokens = windowWords.map(w => w.value.toLocaleLowerCase('ru-RU'));
        if (actualTokens.every((v, idx) => v === candidate.tokens[idx])) continue;
        const tokenDistances = actualTokens.map((v, idx) => editDistance(v, candidate.tokens[idx]));
        const total = tokenDistances.reduce((sum, d) => sum + d, 0);
        const changed = tokenDistances.filter(d => d !== 0).length;
        if (changed !== 1 || total < 1 || total > maxTokenDistance) continue;
        if (tokenDistances.some((distance, idx) =>
          !acceptableTerminologyTokenDistance(actualTokens[idx], candidate.tokens[idx], distance, maxTokenDistance)
        )) continue;

        const start = windowWords[0].index;
        const end = windowWords[windowWords.length - 1].index + windowWords[windowWords.length - 1].value.length;
        const length = end - start;
        const signature = `${start}:${length}:${candidate.internalName}`;
        if (seen.has(signature)) continue;
        seen.add(signature);
        matches.push({
          offset: start,
          length,
          message: `Похоже на справочник 1С: «${candidate.name}». Рекомендуется точное название объекта.`,
          replacements: [{ value: candidate.name }],
          rule: { issueType: 'misspelling', category: { id: 'ERP26_CATALOG' } },
          _localCorrection: true,
          _erp26: true,
          _erpObjectType: candidate.objectType,
          _erpInternalName: candidate.internalName,
          _category: '1С:ERP 2.6'
        });
      }
    }
    return matches.sort((a, b) => a.offset - b.offset);
  }

  function additionalTerminologyMatches(text) {
    const source = String(text || '');
    const results = [];
    const spans = guillemetSpans(source);
    const all = Array.from(terminologyTerms.values()).filter(x => terminologyEnabled(x.id));

    // Documents: validate the complete quoted name and use the same tolerant
    // whole-phrase comparison as ERP 2.6 documents.
    for (const entry of all.filter(x => String(x.category).toLocaleLowerCase('ru-RU') === 'документы')) {
      const docs = entry.terms;
      for (const span of spans) {
        const content = source.slice(span.contentStart, span.contentEnd);
        const normalized = normalizeErpDocumentTitle(content);
        if (!normalized) continue;
        if (docs.some(t => normalizeErpDocumentTitle(t) === normalized)) continue;
        let best = null;
        const actualTokens = erpTokens(content);
        for (const title of docs) {
          const candidateTokens = erpTokens(title);
          if (candidateTokens.length !== actualTokens.length || !candidateTokens.length) continue;
          const ds = actualTokens.map((v, i) => editDistance(v, candidateTokens[i]));
          const total = ds.reduce((a,b) => a+b, 0);
          const changed = ds.filter(d => d !== 0).length;
          const exact = actualTokens.length - changed;
          const acceptable = candidateTokens.length === 2
            ? changed === 1 && total === 1
            : changed >= 1 && changed <= 2 && total <= 2 && exact >= Math.ceil(candidateTokens.length / 2);
          if (!acceptable) continue;
          const score = exact * 100 - total * 10;
          if (!best || score > best.score) best = { title, score };
        }
        if (best) {
          results.push({
            offset: span.contentStart,
            length: content.length,
            message: `Похоже на термин из набора «${entry.name}»: «${best.title}». Рекомендуется точное название.`,
            replacements: [{ value: best.title }],
            rule: { issueType: 'misspelling', category: { id: 'CUSTOM_TERMINOLOGY_DOCUMENT' } },
            _localCorrection: true, _terminology: true,
            _terminologyId: entry.id, _category: entry.name
          });
        }
      }
    }

    return results;
  }

  function erp26Matches(text) {
    if (!terminologyEnabled('erp26')) return [];
    return [
      ...erp26DocumentMatchesInQuotes(text),
      ...erp26CatalogMatches(text)
    ].sort((a, b) => a.offset - b.offset);
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function compileCorrectionRules(rules) {
    return rules
      .filter(rule => rule && rule.replacement && Array.isArray(rule.variants) && rule.variants.length)
      .flatMap(rule => rule.variants.map(variant => {
        const flags = rule.caseSensitive ? 'gu' : 'giu';
        const pattern = new RegExp('(?<![\\p{L}\\p{N}_])' + escapeRegExp(variant) + '(?![\\p{L}\\p{N}_])', flags);
        return {
          id: rule.id || variant,
          category: rule.category || 'Прочее',
          pattern,
          variantLength: String(variant).length,
          replacement: rule.replacement,
          message: rule.message || 'Рекомендуемое написание',
          priority: Number(rule.priority) || 100
        };
      }))
      .sort((a, b) => (a.priority - b.priority) || (b.variantLength - a.variantLength));
  }

  // BPMN Naming Assistant rules are stored in bpmn-naming.json. Keeping the
  // rule list outside JS avoids two sources of truth and makes terminology-like
  // experiments possible without touching the renderer logic.
  function compileBpmnNamingRules(config) {
    const map = new Map();
    const rules = Array.isArray(config?.rules) ? config.rules : [];
    for (const item of rules) {
      const from = String(item?.from || '').trim().toLocaleLowerCase('ru-RU');
      const to = String(item?.to || '').trim();
      if (!from || !to) continue;
      map.set(from, {
        from,
        to,
        message: String(item?.message || '').trim()
      });
    }
    return map;
  }

  async function loadBpmnNamingRules(force = false) {
    if (bpmnNamingLoaded && !force) return bpmnNamingRules;
    const bases = [];
    if (PLUGIN_BASE_URL) bases.push(PLUGIN_BASE_URL);
    try {
      const script = Array.from(document.scripts || []).find(s => /spellchecker\.js(?:[?#]|$)/u.test(s.src || ''));
      if (script?.src) bases.push(new URL('./', script.src).href);
    } catch (_) {}
    bases.push('./');
    bases.push('../');

    bpmnNamingRules = new Map();
    for (const base of Array.from(new Set(bases))) {
      try {
        const response = await fetch(base + 'bpmn-naming.json', { cache: 'no-store' });
        if (!response.ok) continue;
        bpmnNamingRules = compileBpmnNamingRules(await response.json());
        break;
      } catch (_) {}
    }
    bpmnNamingLoaded = true;
    return bpmnNamingRules;
  }

  function bpmnNamingMatches(text, rules = bpmnNamingRules) {
    const source = String(text || '');
    const match = source.match(/^\s*([А-Яа-яЁёA-Za-z-]+)(?=\s|$)/u);
    if (!match) return [];
    const verb = match[1].toLocaleLowerCase('ru-RU');
    const rule = rules instanceof Map ? rules.get(verb) : null;
    if (!rule) return [];
    const original = match[1];
    const replacementCased = /^[А-ЯЁ]/u.test(original) ? rule.to : rule.to.toLocaleLowerCase('ru-RU');
    if (original === replacementCased) return [];
    return [{
      offset: match.index || 0,
      length: original.length,
      message: rule.message || `Для названия действия BPMN рекомендуется более конкретная форма: «${replacementCased}».`,
      replacements: [{ value: replacementCased }],
      rule: { issueType: 'style', category: { id: 'BPMN_NAMING' } },
      _localCorrection: true,
      _bpmnNaming: true,
      _category: 'BPMN'
    }];
  }

