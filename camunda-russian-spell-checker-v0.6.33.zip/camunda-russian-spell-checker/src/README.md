# Renderer source layout

`spellchecker.js` остаётся единым runtime bundle, потому что Camunda Modeler загружает client plugin как один renderer script. Чтобы не вводить новый runtime-loader и не рисковать совместимостью, исходный код разделён на функциональные модули в `src/renderer/`, а затем детерминированно собирается в `spellchecker.js`.

Порядок модулей задаётся числовым префиксом имени файла:

- `00-runtime-core.js` — bootstrap IIFE, constants и shared state;
- `10-terminology-and-rules.js` — corrections, ERP/user terminology и BPMN naming rules;
- `20-text-checking-ui.js` — normalisation, checking pipeline, LanguageTool и popup/toolbar;
- `30-numbering-layout.js` — atomic commands, numbering и layout;
- `40-settings-terminology-ui.js` — terminology editor и Settings UI;
- `90-bootstrap.js` — test hooks и startup.

Сборка:

```text
node tools/build-renderer.js
```

После изменения любого файла `src/renderer/*.js` необходимо пересобрать `spellchecker.js` и запустить regression tests.

Это первый этап декомпозиции: runtime по-прежнему использует общий lexical scope, но исходник уже разделён по зонам ответственности. Следующий этап — уменьшать shared state и выносить чистые алгоритмы в изолированные модули с явными входами/выходами.
