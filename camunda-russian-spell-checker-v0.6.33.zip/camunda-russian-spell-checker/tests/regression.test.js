'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'spellchecker.js'), 'utf8');
const corrections = JSON.parse(fs.readFileSync(path.join(root, 'corrections.json'), 'utf8'));
const erpDocuments = JSON.parse(fs.readFileSync(path.join(root, 'dictionary', 'erp26', 'erp26-documents.json'), 'utf8')).objects;
const bpmnNamingConfig = JSON.parse(fs.readFileSync(path.join(root, 'bpmn-naming.json'), 'utf8'));
const rendererSourceDir = path.join(root, 'src', 'renderer');
const rendererParts = fs.readdirSync(rendererSourceDir).filter(name => /^\d{2}-.*\.js$/u.test(name)).sort();
const rebuiltRenderer = rendererParts.map(name => fs.readFileSync(path.join(rendererSourceDir, name), 'utf8')).join('');
assert.strictEqual(rebuiltRenderer, source, 'spellchecker.js must match the deterministic renderer source bundle');


const context = {
  console,
  URL,
  URLSearchParams,
  setTimeout: () => 0,
  clearTimeout: () => {},
  localStorage: { getItem: () => null, setItem: () => {} },
  window: { addEventListener: () => {}, __crscTestHooks: {} },
  document: {
    currentScript: { src: 'file:///camunda-russian-spell-checker/spellchecker.js' },
    scripts: [],
    readyState: 'loading',
    addEventListener: () => {},
    querySelector: () => null,
    querySelectorAll: () => [],
    documentElement: { classList: { toggle: () => {} } }
  },
  MutationObserver: function() {},
  fetch: async () => { throw new Error('fetch disabled in regression tests'); }
};
context.globalThis = context;
vm.createContext(context);
vm.runInContext(source, context, { filename: 'spellchecker.js' });
const h = context.window.__crscTestHooks;

function correctionMatches(text) {
  const compiled = h.compileCorrectionRules(corrections.rules);
  return h.correctionMatchesForRules(text, compiled);
}

// Corrections: preserve product suffix after Latin C and never flag canonical spelling.
{
  const matches = correctionMatches('1C:ЗУП');
  assert(matches.some(m => m.replacements[0].value === '1С:ЗУП'), '1C:ЗУП must become 1С:ЗУП');
  assert(!matches.some(m => m.replacements[0].value === '1С:ERP'), '1C:ЗУП must never become 1С:ERP');
}
{
  const matches = correctionMatches('1C ERP УХ');
  assert.deepStrictEqual(
    [...new Set(matches.map(m => m.replacements[0].value))],
    ['1С:ERP УХ'],
    'specific 1C ERP УХ rule must win over generic 1C ERP prefix rule'
  );
}
assert.strictEqual(correctionMatches('Power BI').length, 0, 'canonical Power BI must not be flagged');
assert(correctionMatches('PowerBI').some(m => m.replacements[0].value === 'Power BI'), 'PowerBI must suggest Power BI');
assert.strictEqual(correctionMatches('Qlik Sense').length, 0, 'canonical Qlik Sense must not be flagged');
assert.strictEqual(correctionMatches('Camunda Modeler').length, 0, 'canonical Camunda Modeler must not be flagged');


// ERP terminology: compare the whole quoted document name, including typos in the first word.
{
  const docs = [
    { internalName: 'ЗаказПоставщику', name: 'Заказ поставщику' },
    { internalName: 'ЗаказКлиента', name: 'Заказ клиента' },
    { internalName: 'ЗаказНаПеремещение', name: 'Заказ на перемещение' },
    { internalName: 'ПеремещениеОС', name: 'Перемещение ОС' }
  ];
  const names = value => h.rankErpDocumentCandidates(value, docs).map(x => x.candidate.name);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('Заказ поставщику'))), [], 'canonical ERP document must not be flagged');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('Зоказ поставщику'))), ['Заказ поставщику'], 'first-word typo must resolve through ERP terminology');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('Заказ поставщеку'))), ['Заказ поставщику'], 'second-word typo must resolve through ERP terminology');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('Заказ поставщикам'))), ['Заказ поставщику'], 'inflected long ERP token must resolve to the normative document name');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('Зоказ поставщеку'))), ['Заказ поставщику'], 'one typo in each word must still resolve through ERP terminology');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('Заказ на перемещенее'))), ['Заказ на перемещение'], 'multiword ERP title must be matched as a whole phrase');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(names('перемещение со'))), [], 'ERP fuzzy lookup must not restore the old Перемещение ОС false positive');

  // v0.6.32: the per-word edit-distance ceiling is configurable.
  const namesWithDistance = (value, distance) => h.rankErpDocumentCandidates(value, docs, distance).map(x => x.candidate.name);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(namesWithDistance('Заказ поставщикам', 1))), [], 'distance=1 must reject a two-edit word');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(namesWithDistance('Заказ поставщикам', 2))), ['Заказ поставщику'], 'distance=2 must accept the current inflection case');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(namesWithDistance('Заказ поставщиками', 2))), [], 'distance=2 must reject a three-edit word');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(namesWithDistance('Заказ поставщиками', 3))), ['Заказ поставщику'], 'distance=3 must allow experimentation with a three-edit long word');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(namesWithDistance('перемещение со', 5))), [], 'raising the distance must not disable the short-token safety barrier');
}

// Integration regression against the bundled ERP 2.6 document dictionary.
{
  const bundled = value => h.rankErpDocumentCandidates(value, erpDocuments).map(x => x.candidate.name);
  assert(erpDocuments.some(x => x.internalName === 'ЗаказПоставщику' && x.name === 'Заказ поставщику'), 'bundled ERP dictionary must contain Заказ поставщику');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(bundled('Зоказ поставщику'))), ['Заказ поставщику'], 'bundled terminology must beat generic spell checking for the reported case');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(bundled('Заказ поставщикам'))), ['Заказ поставщику'], 'bundled terminology must normalize grammatical inflection to the ERP document name');
}


// BPMN Naming Assistant: bpmn-naming.json is the single source of rules.
{
  const rules = h.compileBpmnNamingRules(bpmnNamingConfig);
  assert(rules instanceof Map || typeof rules.get === 'function', 'BPMN naming rules must compile to a lookup map');
  assert.strictEqual(rules.get('открывать').to, 'Открыть', 'bpmn-naming.json must provide the runtime replacement');
  const matches = h.bpmnNamingMatches('Открывать документ', rules);
  assert.strictEqual(matches.length, 1, 'configured BPMN naming rule must produce one recommendation');
  assert.strictEqual(matches[0].replacements[0].value, 'Открыть', 'BPMN naming replacement must come from JSON');
  assert.strictEqual(h.bpmnNamingMatches('Открыть документ', rules).length, 0, 'canonical perfective form must not be flagged');
  assert.strictEqual(h.isBpmnActivityElement({ businessObject: { $type: 'bpmn:Task' } }), true, 'Task must be treated as BPMN Activity');
  assert.strictEqual(h.isBpmnActivityElement({ businessObject: { $type: 'bpmn:SubProcess' } }), true, 'SubProcess must be treated as BPMN Activity');
  assert.strictEqual(h.isBpmnActivityElement({ businessObject: { $type: 'bpmn:ExclusiveGateway' } }), false, 'Gateway must not receive action naming rules');
  assert.strictEqual(h.isBpmnActivityElement({ businessObject: { $type: 'bpmn:StartEvent' } }), false, 'Event must not receive action naming rules');
}

// Explicit precedence: terminology > local corrections > BPMN > LanguageTool.
{
  const erp = { offset: 1, length: 16, _erp26: true };
  const correction = { offset: 1, length: 5, _localCorrection: true };
  const bpmn = { offset: 1, length: 5, _localCorrection: true, _bpmnNaming: true };
  const lt = { offset: 1, length: 5 };
  const unrelatedLt = { offset: 30, length: 4 };
  const resolved = h.resolveMatchConflicts([lt, correction, bpmn, erp, unrelatedLt]);
  assert.strictEqual(resolved.length, 2, 'overlapping lower-priority matches must be suppressed');
  assert.strictEqual(resolved[0], erp, 'ERP terminology must win an overlapping range');
  assert.strictEqual(resolved[1], unrelatedLt, 'non-overlapping LanguageTool match must remain');
}

// Unified numbering format and expanded/collapsed subprocess semantics.
assert.strictEqual(h.stepLabel('', 1, 'Создать заявку', false), '01: Создать заявку');
assert.strictEqual(h.stepLabel('08', 1, 'Проверить данные', false), '08.01: Проверить данные');
assert.strictEqual(
  h.stepLabel('', 8, '01.05.07 Автоматическое создание перемещения товаров', true),
  '08: 01.05.07 Автоматическое создание перемещения товаров'
);
assert.strictEqual(
  h.stepLabel('08', 1, '01.05.07 Автоматическое создание перемещения товаров', true),
  '08.01: 01.05.07 Автоматическое создание перемещения товаров'
);
assert.strictEqual(
  h.stripLegacyExpandedSubProcessCode('08: 01.05.07 Автоматическое создание перемещения товаров'),
  'Автоматическое создание перемещения товаров'
);
assert.strictEqual(h.stripStepPrefix('01.05.07 Процесс'), '01.05.07 Процесс', 'bare external code must not be partially stripped');

// User custom terms suppress local matches too, not only LanguageTool matches.
{
  const fake = [{ offset: 0, length: 8 }, { offset: 9, length: 4 }];
  const filtered = h.filterIgnoredUserTermMatches(fake, 'Power BI test', ['Power BI']);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(filtered)), [{ offset: 9, length: 4 }]);
}

// Source-level regressions for policy decisions that depend on BPMN element state.
assert(!source.includes('settings.oneNumberForIdenticalActions'), 'legacy identical-action numbering must not affect runtime');
assert(source.includes('delete merged.oneNumberForIdenticalActions'), 'legacy saved setting must be ignored/removed');
assert(source.includes('if (!isExpandedSubProcessElement(element)) continue;'), 'only expanded subprocesses may be recursively numbered');
assert(source.includes('if (!settings.enabled) return false;'), 'disabled checker must stop automatic text normalization');
assert(!source.includes('settings.useErp26Terminology'), 'legacy ERP toggle must not control runtime matching');
assert(source.includes('saved.useErp26Terminology'), 'legacy ERP toggle may remain only as a settings migration input');
assert(source.includes('erpFuzzyMaxTokenDistance: 2'), 'ERP fuzzy edit distance must have a default setting');
assert(source.includes('ERP fuzzy: максимальное расстояние редактирования одного слова'), 'ERP fuzzy edit distance must be exposed in Settings UI');
assert(source.includes('settings.erpFuzzyMaxTokenDistance = getErpFuzzyMaxTokenDistance(erpFuzzyDistance.value)'), 'Settings UI must persist ERP fuzzy edit distance');
assert(!source.includes('BPMN_VERB_RECOMMENDATIONS'), 'BPMN Naming rules must not be duplicated in JS');
assert(source.includes('loadBpmnNamingRules'), 'BPMN Naming rules must be loaded from bpmn-naming.json');
assert(source.includes('isBpmnActivityElement'), 'BPMN Naming must be restricted to Activity elements');
assert(source.includes('terminologyTermsLoaded'), 'additional terminology files must use an in-memory cache');
assert(source.includes('invalidateTerminologyCache'), 'terminology cache must have explicit invalidation');

console.log('CRSC v0.6.33 regression tests: OK');
