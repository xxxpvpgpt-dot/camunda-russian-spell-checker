'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const sourceDir = path.join(root, 'src', 'renderer');
const output = path.join(root, 'spellchecker.js');

const parts = fs.readdirSync(sourceDir)
  .filter(name => /^\d{2}-.*\.js$/u.test(name))
  .sort();

if (!parts.length) throw new Error('Renderer source fragments not found.');

const bundle = parts
  .map(name => fs.readFileSync(path.join(sourceDir, name), 'utf8'))
  .join('');

fs.writeFileSync(output, bundle, 'utf8');
console.log(`Built spellchecker.js from ${parts.length} renderer modules.`);
